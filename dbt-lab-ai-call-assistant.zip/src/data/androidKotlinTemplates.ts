import appGradleCode from "../../android/app/build.gradle.kts?raw";
import manifestCode from "../../android/app/src/main/AndroidManifest.xml?raw";
import callModelsCode from "../../android/app/src/main/java/com/dbtlab/callassistant/telecom/CallModels.kt?raw";
import simDetectorCode from "../../android/app/src/main/java/com/dbtlab/callassistant/telecom/SimSubscriptionDetector.kt?raw";
import dialerRoleCode from "../../android/app/src/main/java/com/dbtlab/callassistant/telecom/DialerRoleHelper.kt?raw";
import inCallServiceCode from "../../android/app/src/main/java/com/dbtlab/callassistant/telecom/DbtInCallService.kt?raw";
import contactsResolverCode from "../../android/app/src/main/java/com/dbtlab/callassistant/data/ContactsResolver.kt?raw";
import callHistoryRepoCode from "../../android/app/src/main/java/com/dbtlab/callassistant/data/CallHistoryRepository.kt?raw";
import simPrefsCode from "../../android/app/src/main/java/com/dbtlab/callassistant/data/SimPreferencesStore.kt?raw";
import voiceEngineCode from "../../android/app/src/main/java/com/dbtlab/callassistant/voice/BengaliVoiceAssistantEngine.kt?raw";
import permissionManagerCode from "../../android/app/src/main/java/com/dbtlab/callassistant/permissions/PermissionManager.kt?raw";
import incomingCallScreenCode from "../../android/app/src/main/java/com/dbtlab/callassistant/ui/IncomingCallScreen.kt?raw";
import incomingCallActivityCode from "../../android/app/src/main/java/com/dbtlab/callassistant/ui/IncomingCallActivity.kt?raw";
import mainActivityCode from "../../android/app/src/main/java/com/dbtlab/callassistant/MainActivity.kt?raw";
import recordingManagerCode from "../../android/app/src/main/java/com/dbtlab/callassistant/recording/DbtCallRecordingManager.kt?raw";
import autoAnswerPrefsCode from "../../android/app/src/main/java/com/dbtlab/callassistant/data/AutoAnswerPreferencesStore.kt?raw";
import autoAnswerGuardCode from "../../android/app/src/main/java/com/dbtlab/callassistant/telecom/AutoAnswerGuard.kt?raw";
import autoAnswerTestCode from "../../android/app/src/test/java/com/dbtlab/callassistant/AutoAnswerVerificationTest.kt?raw";
import gradlePropertiesCode from "../../android/gradle.properties?raw";
import gradleWrapperCode from "../../android/gradle/wrapper/gradle-wrapper.properties?raw";
import themesXmlCode from "../../android/app/src/main/res/values/themes.xml?raw";
import stringsXmlCode from "../../android/app/src/main/res/values/strings.xml?raw";
import androidReadmeCode from "../../android/README.md?raw";

export interface KotlinSourceFile {
  id: string;
  fileName: string;
  packagePath: string;
  language: "kotlin" | "xml" | "gradle" | "properties" | "markdown";
  summaryBn: string;
  code: string;
}

export const ANDROID_KOTLIN_FILES: KotlinSourceFile[] = [
  {
    id: "manifest",
    fileName: "AndroidManifest.xml",
    packagePath: "android/app/src/main/AndroidManifest.xml",
    language: "xml",
    summaryBn: "ROLE_DIALER Intent Filter, IncomingCallActivity, DbtInCallService এবং সকল অনুমতির ডিক্লারেশন।",
    code: manifestCode,
  },
  {
    id: "incall",
    fileName: "DbtInCallService.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/telecom/DbtInCallService.kt",
    language: "kotlin",
    summaryBn: "Android Telecom InCallService: কল স্টেট ট্র্যাকিং, Answer/Reject ও IncomingCallActivity চালু করা।",
    code: inCallServiceCode,
  },
  {
    id: "incoming_screen",
    fileName: "IncomingCallScreen.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/ui/IncomingCallScreen.kt",
    language: "kotlin",
    summaryBn: "Jetpack Compose Dark Navy Incoming Call UI: Caller Number/Name, Answer, Reject এবং AI Assistant বাটন।",
    code: incomingCallScreenCode,
  },
  {
    id: "incoming_activity",
    fileName: "IncomingCallActivity.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/ui/IncomingCallActivity.kt",
    language: "kotlin",
    summaryBn: "Full-Screen Incoming Call Activity এবং বাংলা মহিলা AI Voice Assistant ইন্টিগ্রেশন।",
    code: incomingCallActivityCode,
  },
  {
    id: "jio_sim",
    fileName: "SimSubscriptionDetector.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/telecom/SimSubscriptionDetector.kt",
    language: "kotlin",
    summaryBn: "SubscriptionManager ও PhoneAccountHandle দিয়ে Jio SIM এবং SIM Slot শনাক্তকরণ।",
    code: simDetectorCode,
  },
  {
    id: "role_helper",
    fileName: "DialerRoleHelper.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/telecom/DialerRoleHelper.kt",
    language: "kotlin",
    summaryBn: "RoleManager.ROLE_DIALER ব্যবহার করে অ্যাপকে Default Phone App সেট করার লজিক।",
    code: dialerRoleCode,
  },
  {
    id: "main_activity",
    fileName: "MainActivity.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/MainActivity.kt",
    language: "kotlin",
    summaryBn: "Default Phone App সেটআপ, Runtime Permissions, বাস্তব CallLog এবং Public API সীমাবদ্ধতা UI।",
    code: mainActivityCode,
  },
  {
    id: "voice_engine",
    fileName: "BengaliVoiceAssistantEngine.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/voice/BengaliVoiceAssistantEngine.kt",
    language: "kotlin",
    summaryBn: "Android TextToSpeech (বাংলা মহিলা কণ্ঠ), SpeechRecognizer ও নিরাপদ সার্ভার Gemini ক্লায়েন্ট।",
    code: voiceEngineCode,
  },
  {
    id: "contacts",
    fileName: "ContactsResolver.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/data/ContactsResolver.kt",
    language: "kotlin",
    summaryBn: "READ_CONTACTS অনুমতি সাপেক্ষে PhoneLookup দিয়ে কলারের নাম অনুসন্ধান।",
    code: contactsResolverCode,
  },
  {
    id: "call_history",
    fileName: "CallHistoryRepository.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/data/CallHistoryRepository.kt",
    language: "kotlin",
    summaryBn: "READ_CALL_LOG অনুমতি সাপেক্ষে ডিভাইসের প্রকৃত CallLog.Calls ও Dual SIM মেট্রিকস পঠন।",
    code: callHistoryRepoCode,
  },
  {
    id: "sim_prefs",
    fileName: "SimPreferencesStore.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/data/SimPreferencesStore.kt",
    language: "kotlin",
    summaryBn: "Settings-এ Preferred SIM (Auto / SIM 1 / SIM 2) নিরাপদভাবে সংরক্ষণ।",
    code: simPrefsCode,
  },
  {
    id: "permissions",
    fileName: "PermissionManager.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/permissions/PermissionManager.kt",
    language: "kotlin",
    summaryBn: "Microphone, Phone State, Contacts, Call Log ও Notification অনুমতি ব্যবস্থাপনা।",
    code: permissionManagerCode,
  },
  {
    id: "call_models",
    fileName: "CallModels.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/telecom/CallModels.kt",
    language: "kotlin",
    summaryBn: "CallState মডেল এবং Public Android API দিয়ে যা অসম্ভব তা স্পষ্টভাবে চিহ্নিত করার কনফিগ।",
    code: callModelsCode,
  },
  {
    id: "recording_manager",
    fileName: "DbtCallRecordingManager.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/recording/DbtCallRecordingManager.kt",
    language: "kotlin",
    summaryBn: "সম্মতি-ভিত্তিক রেকর্ডিং ও Android 9+ SIM Call সীমাবদ্ধতা রিপোর্টিং।",
    code: recordingManagerCode,
  },
  {
    id: "auto_answer_guard",
    fileName: "AutoAnswerGuard.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/telecom/AutoAnswerGuard.kt",
    language: "kotlin",
    summaryBn: "Emergency Call সুরক্ষা, Jio SIM ফিল্টার, AI Audio সক্ষমতা যাচাই ও বাস্তব Self-Test রানার।",
    code: autoAnswerGuardCode,
  },
  {
    id: "auto_answer_prefs",
    fileName: "AutoAnswerPreferencesStore.kt",
    packagePath: "android/app/src/main/java/com/dbtlab/callassistant/data/AutoAnswerPreferencesStore.kt",
    language: "kotlin",
    summaryBn: "Automatic Call Receive ON/OFF, Delay (3/5/10s) এবং Jio SIM Only সেটিংস সংরক্ষণ।",
    code: autoAnswerPrefsCode,
  },
  {
    id: "auto_answer_test",
    fileName: "AutoAnswerVerificationTest.kt",
    packagePath: "android/app/src/test/java/com/dbtlab/callassistant/AutoAnswerVerificationTest.kt",
    language: "kotlin",
    summaryBn: "JUnit4 ইউনিট টেস্ট: Auto Answer ON/OFF, ৫ সেকেন্ড Delay, Stop বাতিল, Jio SIM ও Emergency সুরক্ষা।",
    code: autoAnswerTestCode,
  },
  {
    id: "app_gradle",
    fileName: "app/build.gradle.kts",
    packagePath: "android/app/build.gradle.kts",
    language: "gradle",
    summaryBn: "Jetpack Compose, Material3, BACKEND_BASE_URL ও JUnit টেস্ট ডিপেন্ডেন্সি।",
    code: appGradleCode,
  },
  {
    id: "gradle_props",
    fileName: "gradle.properties",
    packagePath: "android/gradle.properties",
    language: "properties",
    summaryBn: "AndroidX, Kotlin Official Style এবং Gradle JVM মেমোরি সেটিংস।",
    code: gradlePropertiesCode,
  },
  {
    id: "gradle_wrapper",
    fileName: "gradle-wrapper.properties",
    packagePath: "android/gradle/wrapper/gradle-wrapper.properties",
    language: "properties",
    summaryBn: "Gradle 8.9 ডিস্ট্রিবিউশন কনফিগারেশন (Android Studio Sync-এর জন্য)।",
    code: gradleWrapperCode,
  },
  {
    id: "themes_xml",
    fileName: "res/values/themes.xml",
    packagePath: "android/app/src/main/res/values/themes.xml",
    language: "xml",
    summaryBn: "Dark Navy Blue & Black Android System Bar ও Window Theme রিসোর্স।",
    code: themesXmlCode,
  },
  {
    id: "strings_xml",
    fileName: "res/values/strings.xml",
    packagePath: "android/app/src/main/res/values/strings.xml",
    language: "xml",
    summaryBn: "অ্যাপের নাম ও Incoming Call Notification Channel স্ট্রিং রিসোর্স।",
    code: stringsXmlCode,
  },
  {
    id: "android_readme",
    fileName: "android/README.md",
    packagePath: "android/README.md",
    language: "markdown",
    summaryBn: "Android Studio-তে প্রজেক্ট Open, Test ও Debug/Release APK Build করার ধাপ।",
    code: androidReadmeCode,
  },
];
