import { CallDirection, CallStatus } from "../types.ts";
import type { CallRecord, ContactItem, UserSettings, VoicePersona } from "../types.ts";

export const BENGALI_FEMALE_VOICES: VoicePersona[] = [
  {
    id: "ananya",
    nameBn: "অনন্যা (Ananya)",
    nameEn: "Ananya — Warm & Polite",
    roleBn: "সহানুভূতিশীল ও ভদ্র বাংলা মহিলা কণ্ঠ (প্রধান)",
    roleEn: "Default warm, respectful Bengali female assistant",
    geminiVoiceName: "Kore",
    speechStyle:
      "Warm, natural, polite Bengali female voice assistant speaking clear standard Bengali with gentle cadence.",
    sampleGreetingBn:
      "নমস্কার, আমি অনন্যা, ডিবিটি ল্যাব এআই কল অ্যাসিস্ট্যান্ট বলছি। আজ আপনাকে কীভাবে সাহায্য করতে পারি?",
  },
  {
    id: "brishti",
    nameBn: "বৃষ্টি (Brishti)",
    nameEn: "Brishti — Crisp Receptionist",
    roleBn: "স্পষ্ট ও পেশাদার কল স্ক্রিনিং কণ্ঠ",
    roleEn: "Crisp, articulate call screening receptionist voice",
    geminiVoiceName: "Zephyr",
    speechStyle:
      "Clear, articulate, professional Bengali female receptionist voice with calm authority.",
    sampleGreetingBn:
      "হ্যালো, আমি বৃষ্টি, ডিবিটি ল্যাব এআই কল অ্যাসিস্ট্যান্ট। অনুগ্রহ করে আপনার নাম এবং কলের কারণ জানাবেন।",
  },
  {
    id: "tithi",
    nameBn: "তিথি (Tithi)",
    nameEn: "Tithi — Calm Executive",
    roleBn: "শান্ত, ধীরস্থির ও সহায়ক বাংলা কণ্ঠ",
    roleEn: "Calm, measured Bengali executive assistant voice",
    geminiVoiceName: "Kore",
    speechStyle:
      "Calm, composed, reassuring Bengali female executive assistant with soft articulation.",
    sampleGreetingBn:
      "শুভ দিন, আমি তিথি, আপনার ডিবিটি ল্যাব এআই ভয়েস অ্যাসিস্ট্যান্ট। অনুমতির পরই আমি কল পরিচালনা করব।",
  },
];

export const DEFAULT_USER_SETTINGS: UserSettings = {
  userName: "আরিফ রহমান",
  userPhone: "+880 1711-004820",
  preferredLanguage: "bilingual",
  selectedVoiceId: "ananya",
  speakingRate: 1.0,
  autoSpeakResponses: true,
  requireCallApproval: true,
  aiCallScreeningEnabled: true,
  futureOutgoingAiBridgeEnabled: false,
  saveTranscripts: true,
  customGreetingBn:
    "নমস্কার, আমি ডিবিটি ল্যাব এআই কল অ্যাসিস্ট্যান্ট বলছি। ব্যবহারকারীর অনুমতির ভিত্তিতে আপনার কলটি গ্রহণ করছি। অনুগ্রহ করে আপনার নাম ও কলের উদ্দেশ্য বলুন।",
};

export const INITIAL_CONTACTS: ContactItem[] = [
  { id: "c1", name: "রহিম (Rahim)", phoneNumber: "+880 1712-345678", relationBn: "সহকর্মী" },
  { id: "c2", name: "মা (Mom)", phoneNumber: "+880 1819-220144", relationBn: "পরিবার" },
  { id: "c3", name: "ডা. তানিয়া (Dr. Tania)", phoneNumber: "+880 1911-883410", relationBn: "চিকিৎসক" },
  { id: "c4", name: "অফিস রিসেপশন (Office)", phoneNumber: "+880 2-8834921", relationBn: "কর্মস্থল" },
];

export const INITIAL_CALL_HISTORY: CallRecord[] = [
  {
    id: "sample-call-1",
    callerName: "কুরিয়ার ডেলিভারি (Steadfast)",
    phoneNumber: "+880 1611-904321",
    direction: CallDirection.INCOMING,
    status: CallStatus.AI_SCREENED,
    timestamp: "আজ · ১০:১৫ AM",
    durationSec: 46,
    aiScreened: true,
    category: "Delivery",
    urgency: "Normal",
    summaryBn:
      "ডেলিভারি প্রতিনিধি একটি পার্সেল নিয়ে বাসার গেটে অপেক্ষা করছেন এবং ক্যাশ অন ডেলিভারি ১,২৫০ টাকা নিশ্চিত করতে বলেছেন।",
    summaryEn:
      "Courier agent waiting at the gate with a parcel requesting 1,250 BDT cash-on-delivery confirmation.",
    actionItems: ["গেট থেকে পার্সেল সংগ্রহ করুন (COD: ৳১,২৫০)"],
    isSampleDemo: true,
    transcript: [
      {
        id: "t1",
        speaker: "AI Assistant",
        text: "নমস্কার, আমি ডিবিটি ল্যাব এআই কল অ্যাসিস্ট্যান্ট বলছি। অনুগ্রহ করে আপনার নাম এবং কলের উদ্দেশ্য জানাবেন।",
        timestamp: "10:15:04",
      },
      {
        id: "t2",
        speaker: "Caller",
        text: "আমি স্টেডফাস্ট কুরিয়ার থেকে বলছি, আরিফ স্যারের একটা পার্সেল আছে, গেটের সামনে আছি।",
        timestamp: "10:15:16",
      },
      {
        id: "t3",
        speaker: "AI Assistant",
        text: "ধন্যবাদ। কোনো ক্যাশ অন ডেলিভারি বা বিশেষ নির্দেশনা থাকলে জানাতে পারেন, আমি এখনই স্যারকে সারাংশ পাঠিয়ে দিচ্ছি।",
        timestamp: "10:15:28",
      },
    ],
  },
  {
    id: "sample-call-2",
    callerName: "ডা. তানিয়া (Dr. Tania)",
    phoneNumber: "+880 1911-883410",
    direction: CallDirection.OUTGOING,
    status: CallStatus.COMPLETED,
    timestamp: "গতকাল · ০৫:৪০ PM",
    durationSec: 128,
    aiScreened: false,
    category: "Medical",
    urgency: "High",
    summaryBn: "ব্যবহারকারীর অনুমতিতে আউটগোয়িং কল সম্পন্ন হয়েছে; আগামীকাল বিকাল ৪টায় অ্যাপয়েন্টমেন্ট নিশ্চিত করা হয়েছে।",
    summaryEn: "User-approved outgoing call completed; appointment confirmed for tomorrow at 4:00 PM.",
    actionItems: ["আগামীকাল বিকাল ৪:০০ টায় রিপোর্ট নিয়ে চেম্বারে উপস্থিত থাকুন"],
    isSampleDemo: true,
    transcript: [],
  },
];

export interface IncomingScenarioPreset {
  id: string;
  callerName: string;
  phoneNumber: string;
  tagBn: string;
  sampleCallerReplies: string[];
}

export const INCOMING_SCENARIO_PRESETS: IncomingScenarioPreset[] = [
  {
    id: "delivery",
    callerName: "এক্সপ্রেস কুরিয়ার",
    phoneNumber: "+880 1799-441208",
    tagBn: "পার্সেল ডেলিভারি",
    sampleCallerReplies: [
      "আমি এক্সপ্রেস ডেলিভারি থেকে বলছি, আপনার একটা বইয়ের পার্সেল নিয়ে নিচে দাঁড়িয়ে আছি।",
      "জ্বী, পেমেন্ট করা আছে, শুধু রিসিভ করতে বলবেন।",
    ],
  },
  {
    id: "client",
    callerName: "মিস্টার কারিম (Client)",
    phoneNumber: "+880 1844-719033",
    tagBn: "জরুরি অফিস কল",
    sampleCallerReplies: [
      "Hello, this is Karim calling about today's 3 PM project review meeting.",
      "Please ask him to join 10 minutes early if possible. Thank you.",
    ],
  },
  {
    id: "spam",
    callerName: "অজানা প্রমোশনাল নম্বর",
    phoneNumber: "+880 1500-991122",
    tagBn: "সম্ভাব্য স্প্যাম/মার্কেটিং",
    sampleCallerReplies: [
      "হ্যালো স্যার, আমাদের নতুন ক্রেডিট কার্ড অফার চলছে, মাত্র ৫ মিনিট সময় দেবেন?",
      "ওকে, তাহলে পরে ফোন করব।",
    ],
  },
];
