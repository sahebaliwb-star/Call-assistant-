import type { CallRecordingItem } from "../types.ts";

const DB_NAME = "dbt_lab_call_recordings_v1";
const DB_VERSION = 1;
const STORE_NAME = "recordings";

interface StoredRecordingRecord extends CallRecordingItem {
  audioBlob: Blob;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB is not supported in this browser."));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("Failed to open recordings database."));
  });
}

export async function saveRecording(
  meta: CallRecordingItem,
  audioBlob: Blob
): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const record: StoredRecordingRecord = { ...meta, audioBlob };
    store.put(record);
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error || new Error("Failed to save recording."));
    };
  });
}

export async function listRecordings(): Promise<CallRecordingItem[]> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const req = store.getAll();
    req.onsuccess = () => {
      db.close();
      const rows = (req.result as StoredRecordingRecord[]) || [];
      const items: CallRecordingItem[] = rows
        .map(({ audioBlob: _blob, ...meta }) => meta)
        .sort((a, b) => b.createdAtIso.localeCompare(a.createdAtIso));
      resolve(items);
    };
    req.onerror = () => {
      db.close();
      reject(req.error || new Error("Failed to read recordings."));
    };
  });
}

export async function getRecordingBlob(id: string): Promise<Blob | null> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const req = store.get(id);
    req.onsuccess = () => {
      db.close();
      const row = req.result as StoredRecordingRecord | undefined;
      resolve(row?.audioBlob || null);
    };
    req.onerror = () => {
      db.close();
      reject(req.error || new Error("Failed to load audio blob."));
    };
  });
}

export async function deleteRecording(id: string): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    store.delete(id);
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error || new Error("Failed to delete recording."));
    };
  });
}

export async function clearAllRecordings(): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    store.clear();
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error || new Error("Failed to clear recordings."));
    };
  });
}
