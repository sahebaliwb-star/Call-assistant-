export type PlaybackStatus = "idle" | "playing" | "paused";

export interface BrowserVoiceInfo {
  available: boolean;
  hasGoogleBengali: boolean;
  selectedVoiceName: string | null;
  selectedVoiceLang: string | null;
  totalBengaliVoices: number;
}

class VoiceAudioController {
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private currentAudio: HTMLAudioElement | null = null;
  private ringtoneInterval: number | null = null;
  private dataArray: Uint8Array<ArrayBuffer> | null = null;
  private mediaSourceMap = new WeakMap<HTMLAudioElement, MediaElementAudioSourceNode>();
  private activeEngine: "none" | "gemini-wav" | "web-speech" = "none";
  private status: PlaybackStatus = "idle";
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private onEndCallback: (() => void) | null = null;
  private onStatusChangeCallback: ((status: PlaybackStatus) => void) | null = null;

  private ensureContext(): AudioContext {
    if (!this.audioCtx) {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new Ctx();
      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 128;
      this.dataArray = new Uint8Array(new ArrayBuffer(this.analyser.frequencyBinCount));
    }
    if (this.audioCtx.state === "suspended") {
      void this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  private setStatus(next: PlaybackStatus): void {
    this.status = next;
    this.onStatusChangeCallback?.(next);
  }

  public getStatus(): PlaybackStatus {
    return this.status;
  }

  public getActiveEngine(): "none" | "gemini-wav" | "web-speech" {
    return this.activeEngine;
  }

  public getOutputLevel(): number {
    if (this.status === "paused") return 0.04;
    if (this.activeEngine === "web-speech" && this.status === "playing") {
      return 0.34;
    }
    if (!this.analyser || !this.dataArray) return 0;
    this.analyser.getByteFrequencyData(this.dataArray);
    let sum = 0;
    for (let i = 0; i < this.dataArray.length; i++) {
      sum += this.dataArray[i];
    }
    return Math.min(1, sum / (this.dataArray.length * 140));
  }

  public getBrowserBengaliVoiceInfo(): BrowserVoiceInfo {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      return {
        available: false,
        hasGoogleBengali: false,
        selectedVoiceName: null,
        selectedVoiceLang: null,
        totalBengaliVoices: 0,
      };
    }
    const voices = window.speechSynthesis.getVoices();
    const bnVoices = voices.filter((v) => v.lang.toLowerCase().startsWith("bn"));
    const googleFemale = bnVoices.find(
      (v) =>
        /google/i.test(v.name) &&
        (/female|bangla|bengali|বাংলা|bn-bd|bn-in/i.test(v.name) || v.lang.toLowerCase().startsWith("bn"))
    );
    const femaleNamed = bnVoices.find((v) =>
      /female|tanisha|kalpana|priya|aditi|nandini|sushmita|bn-bd-x-ban/i.test(v.name)
    );
    const chosen = googleFemale || femaleNamed || bnVoices[0] || null;

    return {
      available: bnVoices.length > 0,
      hasGoogleBengali: Boolean(googleFemale),
      selectedVoiceName: chosen ? chosen.name : null,
      selectedVoiceLang: chosen ? chosen.lang : null,
      totalBengaliVoices: bnVoices.length,
    };
  }

  public pauseSpeaking(): void {
    if (this.status !== "playing") return;
    if (this.activeEngine === "gemini-wav" && this.currentAudio) {
      this.currentAudio.pause();
      this.setStatus("paused");
    } else if (
      this.activeEngine === "web-speech" &&
      typeof window !== "undefined" &&
      "speechSynthesis" in window
    ) {
      window.speechSynthesis.pause();
      this.setStatus("paused");
    }
  }

  public resumeSpeaking(): void {
    if (this.status !== "paused") return;
    if (this.activeEngine === "gemini-wav" && this.currentAudio) {
      void this.currentAudio.play();
      this.setStatus("playing");
    } else if (
      this.activeEngine === "web-speech" &&
      typeof window !== "undefined" &&
      "speechSynthesis" in window
    ) {
      window.speechSynthesis.resume();
      this.setStatus("playing");
    }
  }

  public stopSpeaking(): void {
    if (this.currentAudio) {
      this.currentAudio.onended = null;
      this.currentAudio.onerror = null;
      this.currentAudio.pause();
      this.currentAudio.currentTime = 0;
      this.currentAudio = null;
    }
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      if (this.currentUtterance) {
        this.currentUtterance.onend = null;
        this.currentUtterance.onerror = null;
        this.currentUtterance = null;
      }
      window.speechSynthesis.cancel();
    }
    this.activeEngine = "none";
    this.onEndCallback = null;
    this.setStatus("idle");
  }

  public async playBase64Wav(
    audioBase64: string,
    playbackRate = 1.0,
    onStart?: () => void,
    onEnd?: () => void,
    onStatusChange?: (status: PlaybackStatus) => void
  ): Promise<void> {
    this.stopSpeaking();
    this.onStatusChangeCallback = onStatusChange ?? null;
    this.onEndCallback = onEnd ?? null;

    const ctx = this.ensureContext();
    const audio = new Audio(`data:audio/wav;base64,${audioBase64}`);
    audio.playbackRate = Math.min(1.4, Math.max(0.75, playbackRate));
    this.currentAudio = audio;
    this.activeEngine = "gemini-wav";

    if (this.analyser && !this.mediaSourceMap.has(audio)) {
      const src = ctx.createMediaElementSource(audio);
      src.connect(this.analyser);
      this.analyser.connect(ctx.destination);
      this.mediaSourceMap.set(audio, src);
    }

    return new Promise((resolve, reject) => {
      audio.onplay = () => {
        this.setStatus("playing");
        onStart?.();
      };
      audio.onended = () => {
        if (this.currentAudio === audio) this.currentAudio = null;
        this.activeEngine = "none";
        this.setStatus("idle");
        this.onEndCallback?.();
        this.onEndCallback = null;
        resolve();
      };
      audio.onerror = () => {
        if (this.currentAudio === audio) this.currentAudio = null;
        this.activeEngine = "none";
        this.setStatus("idle");
        this.onEndCallback?.();
        this.onEndCallback = null;
        reject(new Error("Audio playback failed."));
      };
      audio.play().catch((err) => {
        this.activeEngine = "none";
        this.setStatus("idle");
        this.onEndCallback?.();
        this.onEndCallback = null;
        reject(err);
      });
    });
  }

  public speakViaBrowserSpeech(
    text: string,
    rate = 1.0,
    onStart?: () => void,
    onEnd?: () => void,
    onStatusChange?: (status: PlaybackStatus) => void
  ): { started: boolean; voiceName: string | null } {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      return { started: false, voiceName: null };
    }
    this.stopSpeaking();
    this.onStatusChangeCallback = onStatusChange ?? null;
    this.onEndCallback = onEnd ?? null;

    const voices = window.speechSynthesis.getVoices();
    const bnVoices = voices.filter((v) => v.lang.toLowerCase().startsWith("bn"));
    const googleFemale = bnVoices.find((v) => /google/i.test(v.name));
    const femaleNamed = bnVoices.find((v) =>
      /female|tanisha|kalpana|priya|aditi|nandini|sushmita|bn-bd-x-ban/i.test(v.name)
    );
    const chosenVoice = googleFemale || femaleNamed || bnVoices[0] || null;

    if (!chosenVoice) {
      return { started: false, voiceName: null };
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = chosenVoice;
    utterance.lang = chosenVoice.lang;
    utterance.rate = Math.min(1.4, Math.max(0.75, rate));
    utterance.pitch = 1.08;
    this.currentUtterance = utterance;
    this.activeEngine = "web-speech";

    utterance.onstart = () => {
      this.setStatus("playing");
      onStart?.();
    };
    utterance.onend = () => {
      this.currentUtterance = null;
      this.activeEngine = "none";
      this.setStatus("idle");
      this.onEndCallback?.();
      this.onEndCallback = null;
    };
    utterance.onerror = () => {
      this.currentUtterance = null;
      this.activeEngine = "none";
      this.setStatus("idle");
      this.onEndCallback?.();
      this.onEndCallback = null;
    };

    window.speechSynthesis.speak(utterance);
    return { started: true, voiceName: chosenVoice.name };
  }

  // Backward-compatible wrapper used by CallsView
  public speakViaBrowserFallback(
    text: string,
    rate = 1.0,
    onStart?: () => void,
    onEnd?: () => void
  ): boolean {
    const res = this.speakViaBrowserSpeech(text, rate, onStart, onEnd);
    return res.started;
  }

  public startRingtone(): void {
    this.stopRingtone();
    const ctx = this.ensureContext();
    const pulse = () => {
      const now = ctx.currentTime;
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      osc1.type = "sine";
      osc2.type = "sine";
      osc1.frequency.setValueAtTime(440, now);
      osc2.frequency.setValueAtTime(480, now);
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.06, now + 0.08);
      gain.gain.setValueAtTime(0.06, now + 0.85);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.05);
      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);
      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 1.1);
      osc2.stop(now + 1.1);
    };
    pulse();
    this.ringtoneInterval = window.setInterval(pulse, 2400);
  }

  public stopRingtone(): void {
    if (this.ringtoneInterval !== null) {
      window.clearInterval(this.ringtoneInterval);
      this.ringtoneInterval = null;
    }
  }
}

export const voiceAudio = new VoiceAudioController();
