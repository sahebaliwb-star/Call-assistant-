export enum AppTab {
  DASHBOARD = "dashboard",
  VOICE = "voice",
  CALLS = "calls",
  SETTINGS = "settings",
  ANDROID_SDK = "android-sdk",
}

export enum CallDirection {
  INCOMING = "incoming",
  OUTGOING = "outgoing",
}

export enum CallStatus {
  AI_SCREENED = "ai_screened",
  COMPLETED = "completed",
  DECLINED = "declined",
  MISSED = "missed",
}

export interface VoicePersona {
  id: string;
  nameBn: string;
  nameEn: string;
  roleBn: string;
  roleEn: string;
  geminiVoiceName: "Kore" | "Zephyr";
  speechStyle: string;
  sampleGreetingBn: string;
}

export interface TranscriptTurn {
  id: string;
  speaker: "AI Assistant" | "Caller" | "User";
  text: string;
  timestamp: string;
}

export interface CallRecord {
  id: string;
  callerName: string;
  phoneNumber: string;
  direction: CallDirection;
  status: CallStatus;
  timestamp: string;
  durationSec: number;
  aiScreened: boolean;
  category: string;
  urgency: string;
  summaryBn: string;
  summaryEn: string;
  actionItems: string[];
  transcript: TranscriptTurn[];
  isSampleDemo?: boolean;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  timestamp: string;
  language?: "bn" | "en";
  commandType?: string;
  targetName?: string;
  targetNumber?: string;
  suggestedFollowUps?: string[];
  audioBase64?: string;
}

export interface UserSettings {
  userName: string;
  userPhone: string;
  preferredLanguage: "bn" | "en" | "bilingual";
  selectedVoiceId: string;
  speakingRate: number;
  autoSpeakResponses: boolean;
  requireCallApproval: boolean;
  aiCallScreeningEnabled: boolean;
  futureOutgoingAiBridgeEnabled: boolean;
  saveTranscripts: boolean;
  customGreetingBn: string;
}

export interface ContactItem {
  id: string;
  name: string;
  phoneNumber: string;
  relationBn: string;
}

export interface PendingCallIntent {
  name: string;
  phoneNumber: string;
  topic?: string;
  source: "voice_command" | "dialer";
}

export interface CallRecordingItem {
  id: string;
  callerName: string;
  phoneNumber: string;
  direction: CallDirection;
  dateStr: string;
  timeStr: string;
  createdAtIso: string;
  durationSec: number;
  mimeType: string;
  sizeBytes: number;
  userConsented: boolean;
  otherPartyNotified: boolean;
  sourceNote: string;
}
