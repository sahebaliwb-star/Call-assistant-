import { useCallback, useEffect, useMemo, useState } from "react";
import {
  LayoutGrid,
  Mic,
  PhoneCall,
  Settings,
  Code2,
} from "lucide-react";
import { AppTab } from "./types.ts";
import type {
  CallRecord,
  CallRecordingItem,
  ChatMessage,
  PendingCallIntent,
  UserSettings,
  VoicePersona,
} from "./types.ts";
import { clearAllRecordings, listRecordings } from "./utils/recordingStore.ts";
import {
  BENGALI_FEMALE_VOICES,
  DEFAULT_USER_SETTINGS,
  INITIAL_CALL_HISTORY,
  INITIAL_CONTACTS,
} from "./data/presets.ts";
import { voiceAudio } from "./utils/audioEngine.ts";
import { DashboardView } from "./components/DashboardView.tsx";
import { VoiceAssistantView } from "./components/VoiceAssistantView.tsx";
import { CallsView } from "./components/CallsView.tsx";
import { SettingsView } from "./components/SettingsView.tsx";
import { AndroidSdkView } from "./components/AndroidSdkView.tsx";

const STORAGE_SETTINGS_KEY = "dbt_lab_settings_v1";
const STORAGE_CALLS_KEY = "dbt_lab_calls_v1";
const STORAGE_CHAT_KEY = "dbt_lab_chat_v1";

function loadStored<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.DASHBOARD);
  const [settings, setSettings] = useState<UserSettings>(() =>
    loadStored<UserSettings>(STORAGE_SETTINGS_KEY, DEFAULT_USER_SETTINGS)
  );
  const [calls, setCalls] = useState<CallRecord[]>(() =>
    loadStored<CallRecord[]>(STORAGE_CALLS_KEY, INITIAL_CALL_HISTORY)
  );
  const [messages, setMessages] = useState<ChatMessage[]>(() =>
    loadStored<ChatMessage[]>(STORAGE_CHAT_KEY, [])
  );
  const [recordings, setRecordings] = useState<CallRecordingItem[]>([]);

  const [geminiReady, setGeminiReady] = useState<boolean | null>(null);
  const [micPermission, setMicPermission] = useState<
    "granted" | "denied" | "prompt" | "unsupported"
  >("prompt");
  const [isSpeakingPreview, setIsSpeakingPreview] = useState(false);
  const [pendingCallIntent, setPendingCallIntent] = useState<PendingCallIntent | null>(null);
  const [autoTriggerIncoming, setAutoTriggerIncoming] = useState(false);

  const activeVoice = useMemo<VoicePersona>(
    () =>
      BENGALI_FEMALE_VOICES.find((v) => v.id === settings.selectedVoiceId) ||
      BENGALI_FEMALE_VOICES[0],
    [settings.selectedVoiceId]
  );

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_SETTINGS_KEY, JSON.stringify(settings));
    } catch {
      // ignore storage quota errors
    }
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_CALLS_KEY, JSON.stringify(calls));
    } catch {
      // ignore
    }
  }, [calls]);

  useEffect(() => {
    try {
      const compact = messages.map(({ audioBase64: _ignored, ...rest }) => rest);
      localStorage.setItem(STORAGE_CHAT_KEY, JSON.stringify(compact));
    } catch {
      // ignore
    }
  }, [messages]);

  // Verify live backend health & microphone permission state
  useEffect(() => {
    fetch("/api/health")
      .then((r) => r.json())
      .then((d: { geminiConfigured?: boolean }) => {
        setGeminiReady(Boolean(d.geminiConfigured));
      })
      .catch(() => setGeminiReady(false));

    if (typeof navigator !== "undefined" && navigator.permissions?.query) {
      navigator.permissions
        .query({ name: "microphone" as PermissionName })
        .then((status) => {
          setMicPermission(status.state);
          status.onchange = () => setMicPermission(status.state);
        })
        .catch(() => setMicPermission("prompt"));
    } else if (!navigator.mediaDevices?.getUserMedia) {
      setMicPermission("unsupported");
    }

    void listRecordings()
      .then((items) => setRecordings(items))
      .catch(() => setRecordings([]));
  }, []);

  const refreshRecordings = useCallback(async () => {
    try {
      const items = await listRecordings();
      setRecordings(items);
    } catch {
      setRecordings([]);
    }
  }, []);

  const requestMicPermission = useCallback(async () => {
    if (!navigator.mediaDevices?.getUserMedia) {
      setMicPermission("unsupported");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
      setMicPermission("granted");
    } catch {
      setMicPermission("denied");
    }
  }, []);

  const handleTestVoice = useCallback(
    async (persona: VoicePersona) => {
      if (isSpeakingPreview) {
        voiceAudio.stopSpeaking();
        setIsSpeakingPreview(false);
        return;
      }
      try {
        const res = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text: persona.sampleGreetingBn,
            voiceName: persona.geminiVoiceName,
            style: persona.speechStyle,
          }),
        });
        if (!res.ok) throw new Error("TTS API error");
        const { audioBase64 } = (await res.json()) as { audioBase64: string };
        await voiceAudio.playBase64Wav(
          audioBase64,
          settings.speakingRate,
          () => setIsSpeakingPreview(true),
          () => setIsSpeakingPreview(false)
        );
      } catch {
        voiceAudio.speakViaBrowserFallback(
          persona.sampleGreetingBn,
          settings.speakingRate,
          () => setIsSpeakingPreview(true),
          () => setIsSpeakingPreview(false)
        );
      }
    },
    [isSpeakingPreview, settings.speakingRate]
  );

  const handleUpdateSettings = useCallback((patch: Partial<UserSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  }, []);

  const handleAddMessage = useCallback((msg: ChatMessage) => {
    setMessages((prev) => [...prev, msg]);
  }, []);

  const handleAddCallRecord = useCallback((record: CallRecord) => {
    setCalls((prev) => [record, ...prev]);
  }, []);

  const handleDeleteCallRecord = useCallback((id: string) => {
    setCalls((prev) => prev.filter((c) => c.id !== id));
  }, []);

  const handleResetAllData = useCallback(() => {
    setSettings(DEFAULT_USER_SETTINGS);
    setCalls(INITIAL_CALL_HISTORY);
    setMessages([]);
    setRecordings([]);
    void clearAllRecordings();
    localStorage.removeItem(STORAGE_SETTINGS_KEY);
    localStorage.removeItem(STORAGE_CALLS_KEY);
    localStorage.removeItem(STORAGE_CHAT_KEY);
  }, []);

  const navItems: Array<{ id: AppTab; label: string; labelBn: string; icon: typeof LayoutGrid }> = [
    { id: AppTab.DASHBOARD, label: "Dashboard", labelBn: "ড্যাশবোর্ড", icon: LayoutGrid },
    { id: AppTab.VOICE, label: "Voice AI", labelBn: "ভয়েস AI", icon: Mic },
    { id: AppTab.CALLS, label: "Calls", labelBn: "কল", icon: PhoneCall },
    { id: AppTab.SETTINGS, label: "Settings", labelBn: "সেটিংস", icon: Settings },
    { id: AppTab.ANDROID_SDK, label: "Android SDK", labelBn: "Kotlin কোড", icon: Code2 },
  ];

  return (
    <div className="min-h-dvh bg-[#040711] text-slate-100 flex flex-col">
      {/* Top Bar: 3-zone desktop header / compact 52px mobile header */}
      <header className="sticky top-0 z-30 h-[56px] bg-[#040711]/90 backdrop-blur-md border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 flex items-center justify-between gap-8">
          <button
            type="button"
            onClick={() => setActiveTab(AppTab.DASHBOARD)}
            className="text-base sm:text-lg font-semibold tracking-tight text-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            DBT LAB AI Call Assistant
          </button>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            {navItems.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer border-b-2 ${
                    active
                      ? "text-sky-400 border-sky-400"
                      : "text-slate-400 border-transparent hover:text-slate-100"
                  }`}
                >
                  {item.labelBn}
                </button>
              );
            })}
          </nav>

          <button
            type="button"
            onClick={() => setActiveTab(AppTab.VOICE)}
            className="min-h-[38px] px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer"
          >
            ভয়েস চ্যাট
          </button>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 pb-24 md:pb-10">
        {activeTab === AppTab.DASHBOARD && (
          <DashboardView
            settings={settings}
            activeVoice={activeVoice}
            calls={calls}
            chatCount={messages.length}
            geminiReady={geminiReady}
            micPermission={micPermission}
            isSpeakingPreview={isSpeakingPreview}
            onNavigate={setActiveTab}
            onTestBengaliVoice={() => void handleTestVoice(activeVoice)}
            onQuickStartVoice={() => setActiveTab(AppTab.VOICE)}
            onTriggerIncomingDemo={() => {
              setAutoTriggerIncoming(true);
              setActiveTab(AppTab.CALLS);
            }}
            onOpenOutgoingDialer={() => setActiveTab(AppTab.CALLS)}
          />
        )}

        {activeTab === AppTab.VOICE && (
          <VoiceAssistantView
            settings={settings}
            activeVoice={activeVoice}
            messages={messages}
            onAddMessage={handleAddMessage}
            onClearHistory={() => setMessages([])}
            onVoiceCommandCall={(name, phoneNumber) => {
              setPendingCallIntent({ name, phoneNumber, source: "voice_command" });
              setActiveTab(AppTab.CALLS);
            }}
            onTriggerScreenCall={() => {
              setAutoTriggerIncoming(true);
              setActiveTab(AppTab.CALLS);
            }}
            onNavigateSettings={() => setActiveTab(AppTab.SETTINGS)}
            onNavigateCalls={() => setActiveTab(AppTab.CALLS)}
          />
        )}

        {activeTab === AppTab.CALLS && (
          <CallsView
            settings={settings}
            activeVoice={activeVoice}
            calls={calls}
            contacts={INITIAL_CONTACTS}
            recordings={recordings}
            pendingCallIntent={pendingCallIntent}
            autoTriggerIncoming={autoTriggerIncoming}
            onConsumeAutoIncoming={() => setAutoTriggerIncoming(false)}
            onClearPendingIntent={() => setPendingCallIntent(null)}
            onAddCallRecord={handleAddCallRecord}
            onDeleteCallRecord={handleDeleteCallRecord}
            onRecordingAdded={(item) => setRecordings((prev) => [item, ...prev])}
            onRefreshRecordings={refreshRecordings}
          />
        )}

        {activeTab === AppTab.SETTINGS && (
          <SettingsView
            settings={settings}
            activeVoice={activeVoice}
            micPermission={micPermission}
            isSpeakingPreview={isSpeakingPreview}
            onUpdateSettings={handleUpdateSettings}
            onTestVoice={(v) => void handleTestVoice(v)}
            onRequestMicPermission={requestMicPermission}
            onResetAllData={handleResetAllData}
          />
        )}

        {activeTab === AppTab.ANDROID_SDK && <AndroidSdkView />}
      </main>

      {/* Mobile Fixed Bottom Tab Bar (Thumb Zone) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-[#091022]/95 backdrop-blur-md border-t border-slate-800/80 grid grid-cols-5 items-center"
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 transition-colors cursor-pointer ${
                active ? "text-sky-400" : "text-slate-400"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-medium tracking-tight truncate max-w-[68px]">
                {item.labelBn}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
