import { useState } from "react";
import {
  Check,
  Copy,
  Code2,
  Download,
  CheckCircle2,
  Hammer,
  FileArchive,
  AlertCircle,
} from "lucide-react";
import { ANDROID_KOTLIN_FILES } from "../data/androidKotlinTemplates.ts";

const AUDIT_CHECKLIST = [
  {
    titleBn: "১. Kotlin Compile ও API Compat ত্রুটি সংশোধন",
    detailBn:
      "Call.details.state (API 31+) এর বদলে API 26–35 উপযোগী getCompatCallState(), MainActivity-তে pre-onCreate NPE সংশোধন, এবং NonCancellable Auto Answer স্টেট আপডেট যুক্ত করা হয়েছে।",
  },
  {
    titleBn: "২. AndroidManifest.xml সম্পূর্ণ যাচাইকৃত",
    detailBn:
      "Adaptive App Icon, Dark Theme, Android 11+ TTS/SpeechRecognizer <queries>, USE_FULL_SCREEN_INTENT ও ROLE_DIALER intent-filter যুক্ত করা হয়েছে।",
  },
  {
    titleBn: "৩. DbtInCallService নিবন্ধন ও Lock-Screen Launch",
    detailBn:
      "BIND_INCALL_SERVICE অনুমতি ও IN_CALL_SERVICE_UI=true সহ নিবন্ধিত, সাথে setFullScreenIntent Incoming Call Notification যুক্ত।",
  },
  {
    titleBn: "৪. Default Phone App Role Request (ROLE_DIALER)",
    detailBn:
      "DialerRoleHelper-এ RoleManager.createRequestRoleIntent এবং PackageManager ভিত্তিক নিবন্ধন যাচাই।",
  },
  {
    titleBn: "৫. Dual SIM থেকে Jio SIM শনাক্তকরণ",
    detailBn:
      "API 30+ TelephonyManager.getSubscriptionId(PhoneAccountHandle) এবং MCC/MNC 405 (840, 854–874) ম্যাচিং।",
  },
  {
    titleBn: "৬–৮. Auto Answer ON/OFF, ৫ সেকেন্ড Delay ও Stop বাটন",
    detailBn:
      "MainActivity-তে লাইভ ৫ সেকেন্ড কাউন্টডাউন + Stop বাটন, AutoAnswerGuard 6-point সেলফ-টেস্ট এবং AutoAnswerVerificationTest.kt JUnit4 টেস্ট যুক্ত।",
  },
];

const APK_BUILD_STEPS = [
  {
    step: "ধাপ ১",
    titleBn: "Android Studio Project (.ZIP) Export ও Extract করুন",
    descBn:
      "উপরের 'Android Studio Project Export (.ZIP)' বাটনে চাপ দিয়ে DbtLabAiCallAssistant-AndroidStudio.zip ডাউনলোড করে আপনার কম্পিউটারে Extract করুন।",
  },
  {
    step: "ধাপ ২",
    titleBn: "Android Studio-তে প্রজেক্ট Open ও Gradle Sync করুন",
    descBn:
      "Android Studio (Ladybug 2024.2+) খুলে File > Open থেকে Extract করা DbtLabAiCallAssistant-Android ফোল্ডার নির্বাচন করুন। JDK 17 ও Android SDK 35 সহ Gradle 8.9 স্বয়ংক্রিয়ভাবে Sync হবে।",
  },
  {
    step: "ধাপ ৩",
    titleBn: "পিসি ছাড়া মোবাইল থেকে Cloud APK Build (GitHub Actions)",
    descBn:
      "আপনার কাছে পিসি না থাকলে Extract করা DbtLabAiCallAssistant-Android ফোল্ডারটি GitHub-এ আপলোড করুন। প্রজেক্টের ভেতরের .github/workflows/build-apk.yml স্বয়ংক্রিয়ভাবে app-debug.apk বিল্ড করে Artifacts-এ ডাউনলোড লিংক দেবে।",
  },
  {
    step: "ধাপ ৪",
    titleBn: "Unit Test ও Debug APK Build (Android Studio / পিসি)",
    descBn:
      "Android Studio Terminal-এ ./gradlew testDebugUnitTest চালিয়ে AutoAnswerVerificationTest যাচাই করুন এবং Build > Build Bundle(s) / APK(s) > Build APK(s) (বা ./gradlew assembleDebug) দিয়ে app/build/outputs/apk/debug/app-debug.apk তৈরি করুন।",
  },
  {
    step: "ধাপ ৫",
    titleBn: "ফোনে ইনস্টল করে Default Phone App ও Permissions দিন",
    descBn:
      "ফোনে APK ইনস্টল করে 'Default Phone App সেট করুন' বাটনে চাপ দিয়ে ROLE_DIALER ও সব অনুমতি দিন, তারপর Dual SIM ও Auto Answer পরীক্ষা করুন।",
  },
];

export function AndroidSdkView() {
  const [selectedId, setSelectedId] = useState(ANDROID_KOTLIN_FILES[0].id);
  const [copied, setCopied] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);
  const [exportSuccess, setExportSuccess] = useState(false);

  const activeFile =
    ANDROID_KOTLIN_FILES.find((f) => f.id === selectedId) || ANDROID_KOTLIN_FILES[0];

  const handleCopy = async () => {
    await navigator.clipboard.writeText(activeFile.code);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  const handleExportZip = async () => {
    setExporting(true);
    setExportError(null);
    setExportSuccess(false);
    try {
      const response = await fetch("/api/export-android-project");
      if (!response.ok) {
        throw new Error(`Export ব্যর্থ হয়েছে (HTTP ${response.status})`);
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "DbtLabAiCallAssistant-AndroidStudio.zip";
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      setExportSuccess(true);
      window.setTimeout(() => setExportSuccess(false), 3500);
    } catch (err) {
      setExportError(err instanceof Error ? err.message : "ZIP ডাউনলোড করা যায়নি।");
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Export Android Studio Project Card */}
      <section className="rounded-2xl bg-[#091022] border border-blue-500/30 p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-blue-600/20 border border-blue-500/35 flex items-center justify-center shrink-0">
              <FileArchive className="w-5 h-5 text-sky-400" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-100">
                সম্পূর্ণ Android Studio Project Export (.ZIP)
              </h2>
              <p className="text-xs text-slate-400">
                Gradle config, AndroidManifest.xml, Adaptive Icon, Theme, JUnit4 Tests ও সব Kotlin সোর্স ফাইলসহ
              </p>
            </div>
          </div>

          <button
            type="button"
            disabled={exporting}
            onClick={() => void handleExportZip()}
            className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white text-xs font-semibold inline-flex items-center gap-2 cursor-pointer shadow-lg shadow-blue-950/50"
          >
            <Download className="w-4 h-4" />
            <span>
              {exporting
                ? "ZIP তৈরি হচ্ছে..."
                : exportSuccess
                  ? "ডাউনলোড সম্পন্ন হয়েছে"
                  : "Android Studio Project Export (.ZIP)"}
            </span>
          </button>
        </div>

        {exportError && (
          <div className="flex items-center gap-2 p-3 rounded-xl bg-red-950/40 border border-red-800/60 text-xs text-red-200">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{exportError}</span>
          </div>
        )}

        {/* Audit & Verification Checklist */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
          {AUDIT_CHECKLIST.map((item) => (
            <div
              key={item.titleBn}
              className="p-3.5 rounded-xl bg-[#040711] border border-slate-800/80 space-y-1"
            >
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>{item.titleBn}</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">{item.detailBn}</p>
            </div>
          ))}
        </div>
      </section>

      {/* APK Build Guide */}
      <section className="rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600/15 border border-blue-500/25 flex items-center justify-center shrink-0">
            <Hammer className="w-5 h-5 text-sky-400" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-slate-100">
              APK Build করার ধাপ (Android Studio &amp; Gradle)
            </h2>
            <p className="text-xs text-slate-400">
              এই কন্টেইনারে Android SDK/Gradle নেই — নিচের ধাপ অনুসরণ করে আপনার পিসিতে বাস্তব APK বিল্ড করুন
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {APK_BUILD_STEPS.map((item) => (
            <div
              key={item.step}
              className="p-4 rounded-xl bg-[#040711] border border-slate-800/80 flex flex-col sm:flex-row sm:items-start gap-3"
            >
              <span className="px-2.5 py-1 rounded-lg bg-blue-600/15 border border-blue-500/30 text-sky-300 text-xs font-semibold whitespace-nowrap self-start">
                {item.step}
              </span>
              <div className="space-y-1">
                <p className="text-sm font-medium text-slate-100">{item.titleBn}</p>
                <p className="text-xs text-slate-400 leading-relaxed">{item.descBn}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Kotlin & Android Studio File Viewer */}
      <section className="rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/15 border border-blue-500/25 flex items-center justify-center shrink-0">
              <Code2 className="w-5 h-5 text-sky-400" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-100">
                Native Android Kotlin · Jetpack Compose · Telecom API
              </h2>
              <p className="text-xs text-slate-400">
                Android Studio-তে সরাসরি APK বিল্ড করার জন্য সম্পূর্ণ সোর্স কোড ও ম্যানিফেস্ট ({ANDROID_KOTLIN_FILES.length} টি ফাইল)
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => void handleCopy()}
            className="min-h-[40px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? "কপি হয়েছে" : "কোড কপি করুন"}</span>
          </button>
        </div>

        <div className="flex flex-wrap gap-2 pt-2">
          {ANDROID_KOTLIN_FILES.map((file) => (
            <button
              key={file.id}
              type="button"
              onClick={() => setSelectedId(file.id)}
              className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-medium font-mono-tabular whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                selectedId === file.id
                  ? "bg-blue-600 text-white"
                  : "bg-[#0e1833] text-slate-300 border border-slate-800 hover:border-slate-700"
              }`}
            >
              {file.fileName}
            </button>
          ))}
        </div>

        <div className="space-y-2 pt-2">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
            <span className="font-mono-tabular">{activeFile.packagePath}</span>
            <span>{activeFile.summaryBn}</span>
          </div>
          <pre className="p-4 rounded-2xl bg-[#040711] border border-slate-800 overflow-x-auto text-xs leading-relaxed text-slate-200 font-mono-tabular max-h-[480px]">
            <code>{activeFile.code}</code>
          </pre>
        </div>
      </section>
    </div>
  );
}
