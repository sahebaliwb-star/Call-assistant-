import { useEffect, useRef, useState } from "react";
import {
  Circle,
  Pause,
  Play,
  Square,
  ShieldAlert,
  Volume2,
  CheckCircle2,
} from "lucide-react";
import { CallDirection } from "../types.ts";
import type { CallRecordingItem } from "../types.ts";
import { saveRecording } from "../utils/recordingStore.ts";
import { voiceAudio } from "../utils/audioEngine.ts";

interface RecordingControlsBarProps {
  callerName: string;
  phoneNumber: string;
  direction: CallDirection;
  onRecordingSaved: (item: CallRecordingItem) => void;
}

type RecStatus = "idle" | "recording" | "paused";

function formatTimer(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function RecordingControlsBar({
  callerName,
  phoneNumber,
  direction,
  onRecordingSaved,
}: RecordingControlsBarProps) {
  const [status, setStatus] = useState<RecStatus>("idle");
  const [elapsedSec, setElapsedSec] = useState(0);
  const [showConsentGate, setShowConsentGate] = useState(false);
  const [userConsented, setUserConsented] = useState(false);
  const [otherPartyNotified, setOtherPartyNotified] = useState(false);
  const [disclosurePlayed, setDisclosurePlayed] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const durationRef = useRef(0);
  const consentSnapshotRef = useRef({ userConsented: false, otherPartyNotified: false });

  useEffect(() => {
    if (status !== "recording") return;
    const id = window.setInterval(() => {
      setElapsedSec((prev) => {
        const next = prev + 1;
        durationRef.current = next;
        return next;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [status]);

  useEffect(() => {
    return () => {
      if (recorderRef.current && recorderRef.current.state !== "inactive") {
        try {
          recorderRef.current.stop();
        } catch {
          // ignore cleanup stop
        }
      }
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  const playDisclosureAnnouncement = async () => {
    const announcement =
      "অনুগ্রহ করে লক্ষ্য করুন, ডিবিটি ল্যাব এআই কল অ্যাসিস্ট্যান্টের মাধ্যমে এই কলটি ব্যবহারকারীর অনুমতির ভিত্তিতে রেকর্ড করা হচ্ছে।";
    try {
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: announcement,
          voiceName: "Kore",
          style: "Clear, neutral Bengali call recording disclosure announcement",
        }),
      });
      if (res.ok) {
        const { audioBase64 } = (await res.json()) as { audioBase64: string };
        await voiceAudio.playBase64Wav(audioBase64, 1.0);
        setDisclosurePlayed(true);
        setOtherPartyNotified(true);
        return;
      }
    } catch {
      // fall through to browser speech
    }
    const browserRes = voiceAudio.speakViaBrowserSpeech(announcement, 1.0);
    if (!browserRes.started) {
      setSavedNotice("ঘোষণা বার্তাটি স্ক্রিনে দেখানো হয়েছে (ব্রাউজারে TTS সীমিত)।");
    }
    setDisclosurePlayed(true);
    setOtherPartyNotified(true);
  };

  const beginRecordingAfterConsent = async () => {
    if (!userConsented || !otherPartyNotified) return;
    setErrorMsg(null);
    setSavedNotice(null);

    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      setErrorMsg("এই ব্রাউজারে MediaRecorder বা Microphone API সমর্থিত নয়।");
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      chunksRef.current = [];
      durationRef.current = 0;
      setElapsedSec(0);
      consentSnapshotRef.current = {
        userConsented: true,
        otherPartyNotified: true,
      };

      const preferredMime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
        ? "audio/webm;codecs=opus"
        : MediaRecorder.isTypeSupported("audio/webm")
          ? "audio/webm"
          : "";

      const recorder = preferredMime
        ? new MediaRecorder(stream, { mimeType: preferredMime })
        : new MediaRecorder(stream);

      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) {
          chunksRef.current.push(ev.data);
        }
      };

      recorder.onstop = async () => {
        const mimeType = recorder.mimeType || "audio/webm";
        const blob = new Blob(chunksRef.current, { type: mimeType });
        stream.getTracks().forEach((t) => t.stop());
        streamRef.current = null;

        const now = new Date();
        const item: CallRecordingItem = {
          id: `rec-${Date.now()}`,
          callerName: callerName.trim() || "Unknown Contact",
          phoneNumber: phoneNumber.trim() || "Unknown Number",
          direction,
          dateStr: now.toLocaleDateString("en-CA"),
          timeStr: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
          createdAtIso: now.toISOString(),
          durationSec: Math.max(1, durationRef.current),
          mimeType,
          sizeBytes: blob.size,
          userConsented: consentSnapshotRef.current.userConsented,
          otherPartyNotified: consentSnapshotRef.current.otherPartyNotified,
          sourceNote:
            "Browser Microphone / VoIP Capture (IndexedDB Encrypted-Origin Local Store)",
        };

        try {
          await saveRecording(item, blob);
          onRecordingSaved(item);
          setSavedNotice("রেকর্ডিং নিরাপদভাবে সংরক্ষণ করা হয়েছে।");
        } catch (err) {
          setErrorMsg(err instanceof Error ? err.message : "রেকর্ডিং সংরক্ষণ করা যায়নি।");
        }
      };

      recorderRef.current = recorder;
      recorder.start(500);
      setShowConsentGate(false);
      setStatus("recording");
    } catch {
      setErrorMsg("মাইক্রোফোন অনুমতি না থাকায় রেকর্ডিং শুরু করা যায়নি।");
    }
  };

  const pauseOrResumeRecording = () => {
    const rec = recorderRef.current;
    if (!rec) return;
    if (status === "recording" && rec.state === "recording") {
      rec.pause();
      setStatus("paused");
    } else if (status === "paused" && rec.state === "paused") {
      rec.resume();
      setStatus("recording");
    }
  };

  const stopRecording = () => {
    const rec = recorderRef.current;
    if (rec && rec.state !== "inactive") {
      rec.stop();
    }
    recorderRef.current = null;
    setStatus("idle");
    setUserConsented(false);
    setOtherPartyNotified(false);
    setDisclosurePlayed(false);
  };

  return (
    <div className="rounded-2xl bg-[#040711] border border-slate-800 p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="space-y-0.5">
          <p className="text-xs font-medium text-slate-200">
            কল রেকর্ডিং নিয়ন্ত্রণ ({direction === CallDirection.INCOMING ? "Incoming" : "Outgoing"})
          </p>
          <p className="text-[11px] text-slate-400">
            {status === "recording"
              ? "রেকর্ডিং চলছে · অপর পক্ষকে জানানো হয়েছে (গোপন রেকর্ডিং নিষিদ্ধ)"
              : status === "paused"
                ? "রেকর্ডিং বিরতিতে আছে (Paused)"
                : "সম্মতি ও ঘোষণার পর রেকর্ডিং শুরু হবে"}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {status !== "idle" && (
            <span className="px-2.5 py-1 rounded-lg bg-red-950/60 border border-red-700/60 text-xs font-mono-tabular text-red-200">
              REC {formatTimer(elapsedSec)}
            </span>
          )}

          {status === "idle" ? (
            <button
              type="button"
              onClick={() => {
                setErrorMsg(null);
                setSavedNotice(null);
                setShowConsentGate(true);
              }}
              className="min-h-[40px] px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Circle className="w-3.5 h-3.5 fill-current" />
              <span>Recording Start</span>
            </button>
          ) : (
            <>
              <button
                type="button"
                onClick={pauseOrResumeRecording}
                className="min-h-[40px] px-3.5 py-2 rounded-xl bg-[#0e1833] hover:bg-slate-800 border border-slate-700 text-slate-100 text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
              >
                {status === "recording" ? (
                  <>
                    <Pause className="w-3.5 h-3.5 text-amber-400" />
                    <span>Pause</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 text-sky-400" />
                    <span>Resume</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={stopRecording}
                className="min-h-[40px] px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Square className="w-3.5 h-3.5" />
                <span>Stop &amp; Save</span>
              </button>
            </>
          )}
        </div>
      </div>

      {showConsentGate && status === "idle" && (
        <div className="p-4 rounded-xl bg-[#091022] border border-amber-500/40 space-y-3">
          <div className="flex items-start gap-2.5">
            <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="text-xs font-semibold text-slate-100">
                রেকর্ডিং সম্মতি ও অপর পক্ষকে অবহিতকরণ (বাধ্যতামূলক)
              </p>
              <p className="text-xs text-slate-400 leading-relaxed">
                DBT LAB AI Call Assistant-এ কোনো গোপন কল রেকর্ডিং অনুমোদিত নয়। রেকর্ডিং শুরুর আগে আপনার সম্মতি এবং অপর পক্ষকে জানানো আবশ্যক।
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => void playDisclosureAnnouncement()}
              className="min-h-[38px] px-3 py-1.5 rounded-lg bg-[#0e1833] hover:bg-[#17264d] border border-slate-700 text-xs text-sky-300 inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>
                {disclosurePlayed
                  ? "ঘোষণা শোনানো হয়েছে"
                  : "অপর পক্ষকে রেকর্ডিং ঘোষণা শোনান"}
              </span>
            </button>
          </div>

          <div className="space-y-2 text-xs text-slate-200">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={userConsented}
                onChange={(e) => setUserConsented(e.target.checked)}
                className="w-4 h-4 mt-0.5 accent-blue-600 cursor-pointer"
              />
              <span>আমি এই কলটি রেকর্ড করার জন্য স্পষ্ট সম্মতি প্রদান করছি।</span>
            </label>

            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={otherPartyNotified}
                onChange={(e) => setOtherPartyNotified(e.target.checked)}
                className="w-4 h-4 mt-0.5 accent-blue-600 cursor-pointer"
              />
              <span>
                কল রেকর্ডিং শুরু হওয়ার আগে অপর পক্ষকে জানানো হয়েছে / ঘোষণা শোনানো হয়েছে।
              </span>
            </label>
          </div>

          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              type="button"
              disabled={!userConsented || !otherPartyNotified}
              onClick={() => void beginRecordingAfterConsent()}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-xs font-medium cursor-pointer"
            >
              সম্মতিসহ রেকর্ডিং শুরু করুন
            </button>
            <button
              type="button"
              onClick={() => setShowConsentGate(false)}
              className="min-h-[40px] px-3 py-2 text-xs text-slate-400 hover:text-slate-100 cursor-pointer"
            >
              বাতিল
            </button>
          </div>
        </div>
      )}

      {errorMsg && <p className="text-xs text-red-300">{errorMsg}</p>}
      {savedNotice && (
        <p className="text-xs text-emerald-300 inline-flex items-center gap-1.5">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>{savedNotice}</span>
        </p>
      )}
    </div>
  );
}
