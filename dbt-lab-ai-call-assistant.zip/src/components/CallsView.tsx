import { useEffect, useState } from "react";
import {
  PhoneIncoming,
  PhoneOutgoing,
  PhoneOff,
  ShieldCheck,
  Search,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Trash2,
  UserCheck,
  ExternalLink,
} from "lucide-react";
import {
  CallDirection,
  CallStatus,
} from "../types.ts";
import type {
  CallRecord,
  ContactItem,
  PendingCallIntent,
  TranscriptTurn,
  UserSettings,
  VoicePersona,
} from "../types.ts";
import { INCOMING_SCENARIO_PRESETS } from "../data/presets.ts";
import { AcousticOrb3D } from "./AcousticOrb3D.tsx";
import { voiceAudio } from "../utils/audioEngine.ts";
import { RecordingControlsBar } from "./RecordingControlsBar.tsx";
import { RecordingHistoryView } from "./RecordingHistoryView.tsx";
import type { CallRecordingItem } from "../types.ts";

interface CallsViewProps {
  settings: UserSettings;
  activeVoice: VoicePersona;
  calls: CallRecord[];
  contacts: ContactItem[];
  recordings: CallRecordingItem[];
  pendingCallIntent: PendingCallIntent | null;
  autoTriggerIncoming: boolean;
  onConsumeAutoIncoming: () => void;
  onClearPendingIntent: () => void;
  onAddCallRecord: (record: CallRecord) => void;
  onDeleteCallRecord: (id: string) => void;
  onRecordingAdded: (item: CallRecordingItem) => void;
  onRefreshRecordings: () => Promise<void>;
}

type CallStage =
  | "idle"
  | "incoming_ringing"
  | "incoming_ai_screening"
  | "outgoing_confirm"
  | "outgoing_active";

function formatDuration(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function CallsView({
  settings,
  activeVoice,
  calls,
  contacts,
  recordings,
  pendingCallIntent,
  autoTriggerIncoming,
  onConsumeAutoIncoming,
  onClearPendingIntent,
  onAddCallRecord,
  onDeleteCallRecord,
  onRecordingAdded,
  onRefreshRecordings,
}: CallsViewProps) {
  const [subView, setSubView] = useState<"calls" | "recordings">("calls");
  const [filter, setFilter] = useState<"all" | "incoming" | "outgoing" | "screened">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedCallId, setExpandedCallId] = useState<string | null>(null);

  // Incoming & Outgoing active flow state
  const [stage, setStage] = useState<CallStage>("idle");
  const [selectedPresetId, setSelectedPresetId] = useState(INCOMING_SCENARIO_PRESETS[0].id);
  const [incomingCallerName, setIncomingCallerName] = useState(INCOMING_SCENARIO_PRESETS[0].callerName);
  const [incomingCallerNumber, setIncomingCallerNumber] = useState(INCOMING_SCENARIO_PRESETS[0].phoneNumber);
  const [transcript, setTranscript] = useState<TranscriptTurn[]>([]);
  const [callerInput, setCallerInput] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [callSeconds, setCallSeconds] = useState(0);
  const [screeningHint, setScreeningHint] = useState<string | null>(null);
  const [callError, setCallError] = useState<string | null>(null);

  // Outgoing dialer state
  const [dialName, setDialName] = useState("");
  const [dialNumber, setDialNumber] = useState("");
  const [dialTopic, setDialTopic] = useState("");
  const [copilotSuggestions, setCopilotSuggestions] = useState<
    Array<{ label: string; phraseBn: string; phraseEn: string }>
  >([]);

  // Timer during active call stages
  useEffect(() => {
    if (stage !== "incoming_ai_screening" && stage !== "outgoing_active") {
      setCallSeconds(0);
      return;
    }
    const id = window.setInterval(() => setCallSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [stage]);

  // Handle incoming demo trigger from dashboard/voice command
  useEffect(() => {
    if (autoTriggerIncoming) {
      onConsumeAutoIncoming();
      startIncomingSimulation();
    }
  }, [autoTriggerIncoming]);

  // Handle voice-command pending outgoing call (always requires permission!)
  useEffect(() => {
    if (pendingCallIntent) {
      const matched = contacts.find(
        (c) =>
          c.name.toLowerCase().includes(pendingCallIntent.name.toLowerCase()) ||
          pendingCallIntent.phoneNumber === c.phoneNumber
      );
      setDialName(matched?.name || pendingCallIntent.name || "Unknown Contact");
      setDialNumber(matched?.phoneNumber || pendingCallIntent.phoneNumber || "+880 1700-000000");
      setDialTopic(pendingCallIntent.topic || "");
      setStage("outgoing_confirm");
      onClearPendingIntent();
    }
  }, [pendingCallIntent, contacts, onClearPendingIntent]);

  useEffect(() => {
    return () => {
      voiceAudio.stopRingtone();
      voiceAudio.stopSpeaking();
    };
  }, []);

  const speakLine = async (text: string) => {
    try {
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text,
          voiceName: activeVoice.geminiVoiceName,
          style: activeVoice.speechStyle,
        }),
      });
      if (!res.ok) throw new Error("TTS unavailable");
      const { audioBase64 } = (await res.json()) as { audioBase64: string };
      await voiceAudio.playBase64Wav(
        audioBase64,
        settings.speakingRate,
        () => setIsSpeaking(true),
        () => setIsSpeaking(false)
      );
    } catch {
      voiceAudio.speakViaBrowserFallback(
        text,
        settings.speakingRate,
        () => setIsSpeaking(true),
        () => setIsSpeaking(false)
      );
    }
  };

  const startIncomingSimulation = () => {
    setCallError(null);
    setTranscript([]);
    setScreeningHint(null);
    setStage("incoming_ringing");
    voiceAudio.startRingtone();
  };

  const approveAiScreening = async () => {
    voiceAudio.stopRingtone();
    if (!settings.aiCallScreeningEnabled) {
      setCallError("সেটিংসে AI Call Screening বন্ধ করা আছে। প্রথমে অনুমতি চালু করুন।");
      setStage("idle");
      return;
    }

    setStage("incoming_ai_screening");
    setAiBusy(true);
    setCallError(null);

    try {
      const res = await fetch("/api/call-screen", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          callerName: incomingCallerName,
          callerNumber: incomingCallerNumber,
          transcript: [],
          userName: settings.userName,
          customGreetingBn: settings.customGreetingBn,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Call screening AI failed");

      const turn: TranscriptTurn = {
        id: `t-${Date.now()}`,
        speaker: "AI Assistant",
        text: data.assistantReply,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
      };
      setTranscript([turn]);
      setScreeningHint(`${data.callerIntent || "Checking"} · Urgency: ${data.urgency || "Normal"}`);
      await speakLine(data.assistantReply);
    } catch (err) {
      setCallError(err instanceof Error ? err.message : "Failed to initialize AI call screener.");
    } finally {
      setAiBusy(false);
    }
  };

  const sendCallerUtterance = async (utterance: string) => {
    const clean = utterance.trim();
    if (!clean || aiBusy) return;
    setCallerInput("");
    setCallError(null);

    const callerTurn: TranscriptTurn = {
      id: `tc-${Date.now()}`,
      speaker: "Caller",
      text: clean,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
    };

    const updated = [...transcript, callerTurn];
    setTranscript(updated);
    setAiBusy(true);

    try {
      const res = await fetch("/api/call-screen", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          callerName: incomingCallerName,
          callerNumber: incomingCallerNumber,
          callerUtterance: clean,
          transcript: updated.map((t) => ({ speaker: t.speaker, text: t.text })),
          userName: settings.userName,
          customGreetingBn: settings.customGreetingBn,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Call screen response error");

      const aiTurn: TranscriptTurn = {
        id: `ta-${Date.now()}`,
        speaker: "AI Assistant",
        text: data.assistantReply,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
      };
      setTranscript((prev) => [...prev, aiTurn]);
      setScreeningHint(`${data.callerIntent} · Urgency: ${data.urgency}`);
      await speakLine(data.assistantReply);
    } catch (err) {
      setCallError(err instanceof Error ? err.message : "AI call screening reply failed.");
    } finally {
      setAiBusy(false);
    }
  };

  const endScreenedCallAndSummarize = async () => {
    voiceAudio.stopRingtone();
    voiceAudio.stopSpeaking();
    setAiBusy(true);
    setCallError(null);

    try {
      let summaryBn = "ইনকামিং কল AI অ্যাসিস্ট্যান্ট দ্বারা স্ক্রিন করা হয়েছে।";
      let summaryEn = "Incoming call screened by DBT LAB AI Call Assistant.";
      let category = "Screened";
      let urgency = "Normal";
      let actionItems: string[] = [];

      if (transcript.length > 0) {
        const res = await fetch("/api/call-summary", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            callerName: incomingCallerName,
            callerNumber: incomingCallerNumber,
            transcript: transcript.map((t) => ({ speaker: t.speaker, text: t.text })),
          }),
        });
        if (res.ok) {
          const s = await res.json();
          summaryBn = s.summaryBn || summaryBn;
          summaryEn = s.summaryEn || summaryEn;
          category = s.category || category;
          urgency = s.urgency || urgency;
          actionItems = Array.isArray(s.actionItems) ? s.actionItems : [];
        }
      }

      onAddCallRecord({
        id: `call-${Date.now()}`,
        callerName: incomingCallerName,
        phoneNumber: incomingCallerNumber,
        direction: CallDirection.INCOMING,
        status: CallStatus.AI_SCREENED,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        durationSec: Math.max(callSeconds, 12),
        aiScreened: true,
        category,
        urgency,
        summaryBn,
        summaryEn,
        actionItems,
        transcript: settings.saveTranscripts ? transcript : [],
      });
    } finally {
      setAiBusy(false);
      setStage("idle");
    }
  };

  const requestOutgoingCall = () => {
    if (!dialNumber.trim()) {
      setCallError("অনুগ্রহ করে একটি বৈধ ফোন নম্বর লিখুন বা কন্টাক্ট নির্বাচন করুন।");
      return;
    }
    setCallError(null);
    if (settings.requireCallApproval) {
      setStage("outgoing_confirm");
    } else {
      void startApprovedOutgoingCall();
    }
  };

  const startApprovedOutgoingCall = async () => {
    setStage("outgoing_active");
    setAiBusy(true);
    setCopilotSuggestions([]);
    try {
      const res = await fetch("/api/outgoing-copilot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contactName: dialName || dialNumber,
          callTopic: dialTopic || "সাধারণ কথোপকথন",
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setCopilotSuggestions(Array.isArray(data.suggestions) ? data.suggestions : []);
      }
    } catch {
      // ignore copilot fetch failure, call controls stay functional
    } finally {
      setAiBusy(false);
    }
  };

  const finishOutgoingCall = () => {
    onAddCallRecord({
      id: `call-${Date.now()}`,
      callerName: dialName || dialNumber,
      phoneNumber: dialNumber,
      direction: CallDirection.OUTGOING,
      status: CallStatus.COMPLETED,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      durationSec: Math.max(callSeconds, 5),
      aiScreened: false,
      category: dialTopic ? "Work / Planned" : "Personal",
      urgency: "Normal",
      summaryBn: `${dialName || dialNumber}-কে ব্যবহারকারীর অনুমোদনসহ আউটগোয়িং কল সেশন সম্পন্ন হয়েছে।`,
      summaryEn: `User-approved outgoing call session with ${dialName || dialNumber} completed.`,
      actionItems: dialTopic ? [`বিষয়: ${dialTopic}`] : [],
      transcript: [],
    });
    setStage("idle");
  };

  const activePreset = INCOMING_SCENARIO_PRESETS.find((p) => p.id === selectedPresetId);

  const filteredCalls = calls.filter((c) => {
    const matchesFilter =
      filter === "all" ||
      (filter === "incoming" && c.direction === CallDirection.INCOMING) ||
      (filter === "outgoing" && c.direction === CallDirection.OUTGOING) ||
      (filter === "screened" && c.aiScreened);
    const q = searchQuery.trim().toLowerCase();
    const matchesQuery =
      !q ||
      c.callerName.toLowerCase().includes(q) ||
      c.phoneNumber.toLowerCase().includes(q) ||
      c.summaryBn.toLowerCase().includes(q);
    return matchesFilter && matchesQuery;
  });

  return (
    <div className="space-y-6">
      {stage === "idle" && (
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-1 p-1 rounded-xl bg-[#091022] border border-slate-800/80">
            <button
              type="button"
              onClick={() => setSubView("calls")}
              className={`min-h-[38px] px-4 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                subView === "calls" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-slate-100"
              }`}
            >
              কল ও স্ক্রিনিং
            </button>
            <button
              type="button"
              onClick={() => setSubView("recordings")}
              className={`min-h-[38px] px-4 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer tabular-nums ${
                subView === "recordings"
                  ? "bg-blue-600 text-white"
                  : "text-slate-400 hover:text-slate-100"
              }`}
            >
              Recording History ({recordings.length})
            </button>
          </div>
        </div>
      )}

      {callError && (
        <div className="p-3.5 rounded-xl bg-red-950/50 border border-red-800/60 text-xs text-red-200">
          {callError}
        </div>
      )}

      {/* Active Call Overlay / Stage */}
      {stage === "incoming_ringing" && (
        <section className="rounded-3xl bg-[#091022] border border-amber-500/40 p-6 sm:p-8 flex flex-col items-center text-center space-y-6">
          <div className="space-y-1">
            <p className="text-xs font-medium text-amber-400">ইনকামিং কল শনাক্ত হয়েছে</p>
            <h2 className="text-2xl font-semibold text-slate-50">{incomingCallerName}</h2>
            <p className="text-sm text-slate-400 font-mono-tabular">{incomingCallerNumber}</p>
          </div>

          <AcousticOrb3D state="ringing" size={200} />

          <div className="max-w-md space-y-2">
            <p className="text-sm text-slate-200">
              DBT LAB AI Call Assistant-কে কলটি রিসিভ করে পরিচয় ও কলের কারণ জানতে অনুমতি দেবেন?
            </p>
            <p className="text-xs text-slate-400">
              Android Default Dialer ও CallScreeningService অনুমতির নিয়ম অনুযায়ী আপনার সম্মতি প্রয়োজন।
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => void approveAiScreening()}
              className="min-h-[48px] px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium inline-flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>AI-কে স্ক্রিনিং অনুমতি দিন</span>
            </button>

            <button
              type="button"
              onClick={() => {
                voiceAudio.stopRingtone();
                setStage("idle");
                onAddCallRecord({
                  id: `call-${Date.now()}`,
                  callerName: incomingCallerName,
                  phoneNumber: incomingCallerNumber,
                  direction: CallDirection.INCOMING,
                  status: CallStatus.DECLINED,
                  timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                  durationSec: 0,
                  aiScreened: false,
                  category: "Declined",
                  urgency: "Normal",
                  summaryBn: "ব্যবহারকারী কলটি সরাসরি প্রত্যাখ্যান করেছেন।",
                  summaryEn: "Call declined by user.",
                  actionItems: [],
                  transcript: [],
                });
              }}
              className="min-h-[48px] px-5 py-3 rounded-xl bg-red-600/90 hover:bg-red-500 text-white text-sm font-medium inline-flex items-center gap-2 cursor-pointer"
            >
              <PhoneOff className="w-4 h-4" />
              <span>কল কাটুন</span>
            </button>
          </div>
        </section>
      )}

      {stage === "incoming_ai_screening" && (
        <section className="rounded-3xl bg-[#091022] border border-blue-500/40 p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800/70">
            <div>
              <p className="text-xs text-sky-400">
                AI Call Screening Active · {formatDuration(callSeconds)}
              </p>
              <h2 className="text-lg font-semibold text-slate-100">
                {incomingCallerName} ({incomingCallerNumber})
              </h2>
              {screeningHint && <p className="text-xs text-slate-400 mt-0.5">{screeningHint}</p>}
            </div>

            <button
              type="button"
              disabled={aiBusy}
              onClick={() => void endScreenedCallAndSummarize()}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-sm font-medium inline-flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <PhoneOff className="w-4 h-4" />
              <span>কল শেষ ও সারাংশ তৈরি</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-4 flex flex-col items-center text-center space-y-3 py-2">
              <AcousticOrb3D state={isSpeaking ? "speaking" : aiBusy ? "thinking" : "listening"} size={180} />
              <p className="text-xs text-slate-400">
                {activeVoice.nameBn} কলের অপর প্রান্তের ব্যক্তির সাথে কথা বলছেন
              </p>
            </div>

            <div className="lg:col-span-8 space-y-4">
              <div className="max-h-60 overflow-y-auto space-y-3 pr-1">
                {transcript.map((t) => (
                  <div
                    key={t.id}
                    className={`p-3 rounded-xl text-sm ${
                      t.speaker === "AI Assistant"
                        ? "bg-[#0e1833] border border-slate-800 text-slate-100"
                        : "bg-blue-950/50 border border-blue-900/50 text-sky-100"
                    }`}
                  >
                    <p className="text-[11px] text-slate-400 mb-1">
                      {t.speaker === "AI Assistant" ? "DBT LAB AI" : "কলার (Caller)"} · {t.timestamp}
                    </p>
                    <p className="leading-relaxed">{t.text}</p>
                  </div>
                ))}
              </div>

              {activePreset && (
                <div className="space-y-1.5">
                  <p className="text-xs text-slate-400">কলারের উত্তর সিমুলেট করুন:</p>
                  <div className="flex flex-wrap gap-2">
                    {activePreset.sampleCallerReplies.map((reply) => (
                      <button
                        key={reply}
                        type="button"
                        disabled={aiBusy}
                        onClick={() => void sendCallerUtterance(reply)}
                        className="text-left text-xs px-3 py-2 rounded-lg bg-[#0e1833] hover:bg-[#17264d] border border-slate-800 text-slate-200 cursor-pointer disabled:opacity-50"
                      >
                        {reply}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  void sendCallerUtterance(callerInput);
                }}
                className="flex gap-2"
              >
                <input
                  type="text"
                  value={callerInput}
                  onChange={(e) => setCallerInput(e.target.value)}
                  placeholder="কলারের উত্তর লিখুন (বাংলা বা English)..."
                  className="flex-1 min-h-[44px] px-3.5 rounded-xl bg-[#040711] border border-slate-800 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                />
                <button
                  type="submit"
                  disabled={!callerInput.trim() || aiBusy}
                  className="min-h-[44px] px-4 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-sm font-medium cursor-pointer"
                >
                  পাঠান
                </button>
              </form>

              <RecordingControlsBar
                callerName={incomingCallerName}
                phoneNumber={incomingCallerNumber}
                direction={CallDirection.INCOMING}
                onRecordingSaved={onRecordingAdded}
              />
            </div>
          </div>
        </section>
      )}

      {stage === "outgoing_confirm" && (
        <section className="rounded-3xl bg-[#091022] border border-blue-500/40 p-6 space-y-4">
          <div className="flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h2 className="text-lg font-semibold text-slate-100">কল করার আগে আপনার অনুমতি প্রয়োজন</h2>
              <p className="text-sm text-slate-300">
                DBT LAB AI Call Assistant কখনোই ব্যবহারকারীর স্পষ্ট অনুমতি ছাড়া কোনো কল শুরু করে না।
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-[#0e1833] border border-slate-800 space-y-1">
            <p className="text-sm font-medium text-slate-100">{dialName || "Unknown Recipient"}</p>
            <p className="text-sm text-sky-400 font-mono-tabular">{dialNumber}</p>
            {dialTopic && <p className="text-xs text-slate-400">বিষয়: {dialTopic}</p>}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => void startApprovedOutgoingCall()}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium inline-flex items-center gap-2 cursor-pointer"
            >
              <UserCheck className="w-4 h-4" />
              <span>অনুমতি দিন ও Co-Pilot শুরু করুন</span>
            </button>

            <a
              href={`tel:${dialNumber.replace(/\s+/g, "")}`}
              className="min-h-[44px] px-4 py-2.5 rounded-xl bg-[#0e1833] hover:bg-[#17264d] border border-slate-700 text-slate-200 text-sm font-medium inline-flex items-center gap-2"
            >
              <ExternalLink className="w-4 h-4" />
              <span>ডিভাইস ডায়ালারে খুলুন</span>
            </a>

            <button
              type="button"
              onClick={() => setStage("idle")}
              className="min-h-[44px] px-4 py-2.5 rounded-xl text-slate-400 hover:text-slate-100 text-sm font-medium cursor-pointer"
            >
              বাতিল করুন
            </button>
          </div>
        </section>
      )}

      {stage === "outgoing_active" && (
        <section className="rounded-3xl bg-[#091022] border border-blue-500/40 p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800/70">
            <div>
              <p className="text-xs text-sky-400">
                Approved Outgoing Call Co-Pilot · {formatDuration(callSeconds)}
              </p>
              <h2 className="text-lg font-semibold text-slate-100">
                {dialName || dialNumber}
              </h2>
              <p className="text-xs text-slate-400 font-mono-tabular">{dialNumber}</p>
            </div>

            <button
              type="button"
              onClick={finishOutgoingCall}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-sm font-medium inline-flex items-center gap-2 cursor-pointer"
            >
              <PhoneOff className="w-4 h-4" />
              <span>কল শেষ করুন</span>
            </button>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm font-medium text-slate-100">AI রিয়েল-টাইম কথোপকথন সহায়তা</p>
              <span className="text-xs text-slate-400">
                {settings.futureOutgoingAiBridgeEnabled
                  ? "Future AI Audio Bridge: Android InCallService Only"
                  : "Whisper Co-Pilot Active"}
              </span>
            </div>

            {aiBusy ? (
              <p className="text-xs text-slate-400">কথোপকথনের সহায়ক পয়েন্ট তৈরি হচ্ছে...</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {copilotSuggestions.map((s, idx) => (
                  <div key={idx} className="p-4 rounded-2xl bg-[#0e1833] border border-slate-800 space-y-1.5">
                    <p className="text-xs font-medium text-sky-400">{s.label}</p>
                    <p className="text-sm text-slate-100 leading-relaxed">{s.phraseBn}</p>
                    <p className="text-xs text-slate-400">{s.phraseEn}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          <RecordingControlsBar
            callerName={dialName || dialNumber}
            phoneNumber={dialNumber}
            direction={CallDirection.OUTGOING}
            onRecordingSaved={onRecordingAdded}
          />
        </section>
      )}

      {stage === "idle" && subView === "recordings" && (
        <RecordingHistoryView
          recordings={recordings}
          onRefreshRecordings={onRefreshRecordings}
          onRecordingAdded={onRecordingAdded}
        />
      )}

      {/* Idle Controls: Incoming Screening Lab + Outgoing Dialer */}
      {stage === "idle" && subView === "calls" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Incoming Call Screening Panel */}
          <section className="lg:col-span-6 rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600/15 border border-blue-500/25 flex items-center justify-center">
                <PhoneIncoming className="w-5 h-5 text-sky-400" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-slate-100">ইনকামিং কল ও স্ক্রিনিং সিমুলেটর</h2>
                <p className="text-xs text-slate-400">
                  ব্রাউজারে ইনকামিং কল শনাক্তকরণ, অনুমতি গেট এবং AI সারাংশ পরীক্ষা করুন
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-xs text-slate-400">সিনারিও নির্বাচন করুন</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {INCOMING_SCENARIO_PRESETS.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      setSelectedPresetId(p.id);
                      setIncomingCallerName(p.callerName);
                      setIncomingCallerNumber(p.phoneNumber);
                    }}
                    className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                      selectedPresetId === p.id
                        ? "bg-blue-600/15 border-blue-500/60 text-slate-50"
                        : "bg-[#0e1833] border-slate-800 text-slate-300 hover:border-slate-700"
                    }`}
                  >
                    <p className="text-xs font-medium truncate">{p.callerName}</p>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">{p.tagBn}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={incomingCallerName}
                onChange={(e) => setIncomingCallerName(e.target.value)}
                placeholder="কলারের নাম"
                className="min-h-[42px] px-3.5 rounded-xl bg-[#040711] border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-blue-500"
              />
              <input
                type="text"
                value={incomingCallerNumber}
                onChange={(e) => setIncomingCallerNumber(e.target.value)}
                placeholder="ফোন নম্বর"
                className="min-h-[42px] px-3.5 rounded-xl bg-[#040711] border border-slate-800 text-sm text-slate-100 font-mono-tabular focus:outline-none focus:border-blue-500"
              />
            </div>

            <button
              type="button"
              onClick={startIncomingSimulation}
              className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <PhoneIncoming className="w-4 h-4" />
              <span>ইনকামিং কল টেস্ট শুরু করুন</span>
            </button>
          </section>

          {/* Outgoing Call Panel */}
          <section className="lg:col-span-6 rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600/15 border border-blue-500/25 flex items-center justify-center">
                <PhoneOutgoing className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-slate-100">আউটগোয়িং কল ও অনুমতি গেট</h2>
                <p className="text-xs text-slate-400">
                  অনুমতি ছাড়া কোনো কল করা যাবে না; কল চলাকালীন AI সহায়তা পাবেন
                </p>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {contacts.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => {
                    setDialName(c.name);
                    setDialNumber(c.phoneNumber);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-[#0e1833] hover:bg-[#17264d] border border-slate-800 text-xs text-slate-200 cursor-pointer"
                >
                  {c.name}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={dialName}
                onChange={(e) => setDialName(e.target.value)}
                placeholder="প্রাপকের নাম"
                className="min-h-[42px] px-3.5 rounded-xl bg-[#040711] border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-blue-500"
              />
              <input
                type="text"
                value={dialNumber}
                onChange={(e) => setDialNumber(e.target.value)}
                placeholder="+880 17..."
                className="min-h-[42px] px-3.5 rounded-xl bg-[#040711] border border-slate-800 text-sm text-slate-100 font-mono-tabular focus:outline-none focus:border-blue-500"
              />
            </div>

            <input
              type="text"
              value={dialTopic}
              onChange={(e) => setDialTopic(e.target.value)}
              placeholder="কলের বিষয় (ঐচ্ছিক, যেমন: মিটিং সময়সূচী)"
              className="w-full min-h-[42px] px-3.5 rounded-xl bg-[#040711] border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-blue-500"
            />

            <button
              type="button"
              onClick={requestOutgoingCall}
              className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-[#0e1833] hover:bg-[#152448] border border-blue-500/40 text-slate-100 text-sm font-medium inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <PhoneOutgoing className="w-4 h-4 text-sky-400" />
              <span>অনুমতিসহ কল শুরু করুন</span>
            </button>
          </section>
        </div>
      )}

      {/* Call History Table / List */}
      <section className="rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-100">কল হিস্ট্রি ও সারাংশ</h2>
            <p className="text-xs text-slate-400 tabular-nums">{filteredCalls.length} টি রেকর্ড</p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="নাম বা নম্বর খুঁজুন..."
                className="min-h-[40px] pl-9 pr-3 rounded-xl bg-[#040711] border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex items-center gap-1 p-1 rounded-xl bg-[#040711] border border-slate-800">
              {[
                { id: "all", label: "সব" },
                { id: "incoming", label: "ইনকামিং" },
                { id: "outgoing", label: "আউটগোয়িং" },
                { id: "screened", label: "AI স্ক্রিনড" },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setFilter(t.id as typeof filter)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                    filter === t.id ? "bg-blue-600 text-white" : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {filteredCalls.length === 0 ? (
          <div className="py-10 text-center text-sm text-slate-400 border-t border-slate-800/70">
            কোনো কল রেকর্ড পাওয়া যায়নি।
          </div>
        ) : (
          <div className="divide-y divide-slate-800/70 border-t border-slate-800/70">
            {filteredCalls.map((call) => {
              const isOpen = expandedCallId === call.id;
              return (
                <div key={call.id} className="py-4 space-y-2.5">
                  <div className="flex items-start justify-between gap-4">
                    <button
                      type="button"
                      onClick={() => setExpandedCallId(isOpen ? null : call.id)}
                      className="flex-1 text-left space-y-1 cursor-pointer min-w-0"
                    >
                      <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
                        <span className="text-sm font-medium text-slate-100">{call.callerName}</span>
                        <span className="text-xs text-slate-400 font-mono-tabular">
                          {call.phoneNumber}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 tabular-nums">
                        {call.direction === CallDirection.INCOMING ? "Incoming" : "Outgoing"}
                        {" · "}
                        {call.category}
                        {" · "}
                        {call.timestamp}
                        {" · "}
                        {formatDuration(call.durationSec)}
                        {call.isSampleDemo ? " · Sample Demo" : ""}
                      </p>
                      <p className="text-sm text-slate-300 leading-relaxed pt-1">{call.summaryBn}</p>
                    </button>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => setExpandedCallId(isOpen ? null : call.id)}
                        aria-label="Toggle call details"
                        className="min-h-[40px] min-w-[40px] rounded-lg hover:bg-slate-800/70 text-slate-400 flex items-center justify-center cursor-pointer"
                      >
                        {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteCallRecord(call.id)}
                        aria-label="Delete call record"
                        className="min-h-[40px] min-w-[40px] rounded-lg hover:bg-red-950/50 text-slate-400 hover:text-red-300 flex items-center justify-center cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {isOpen && (
                    <div className="pt-3 border-t border-slate-800/60 space-y-3">
                      <p className="text-xs text-slate-400">English Summary: {call.summaryEn}</p>
                      {call.actionItems.length > 0 && (
                        <div className="space-y-1">
                          <p className="text-xs font-medium text-sky-400">Action Items</p>
                          <ul className="list-disc list-inside text-xs text-slate-300 space-y-0.5">
                            {call.actionItems.map((item, idx) => (
                              <li key={idx}>{item}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {call.transcript.length > 0 && (
                        <div className="space-y-1.5">
                          <p className="text-xs font-medium text-slate-300">ট্রান্সক্রিপ্ট</p>
                          <div className="space-y-1.5">
                            {call.transcript.map((t) => (
                              <p key={t.id} className="text-xs text-slate-400">
                                <span className="text-slate-200 font-medium">{t.speaker}:</span> {t.text}
                              </p>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
