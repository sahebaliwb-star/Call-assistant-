import {
  ArrowUpRight,
  Mic,
  PhoneIncoming,
  PhoneOutgoing,
  ShieldCheck,
  Volume2,
  Code2,
} from "lucide-react";
import { AppTab, CallDirection, CallStatus } from "../types.ts";
import type { CallRecord, UserSettings, VoicePersona } from "../types.ts";
import { AcousticOrb3D } from "./AcousticOrb3D.tsx";

interface DashboardViewProps {
  settings: UserSettings;
  activeVoice: VoicePersona;
  calls: CallRecord[];
  chatCount: number;
  geminiReady: boolean | null;
  micPermission: "granted" | "denied" | "prompt" | "unsupported";
  isSpeakingPreview: boolean;
  onNavigate: (tab: AppTab) => void;
  onTestBengaliVoice: () => void;
  onQuickStartVoice: () => void;
  onTriggerIncomingDemo: () => void;
  onOpenOutgoingDialer: () => void;
}

function formatDuration(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function DashboardView({
  settings,
  activeVoice,
  calls,
  chatCount,
  geminiReady,
  micPermission,
  isSpeakingPreview,
  onNavigate,
  onTestBengaliVoice,
  onQuickStartVoice,
  onTriggerIncomingDemo,
  onOpenOutgoingDialer,
}: DashboardViewProps) {
  const screenedCount = calls.filter((c) => c.aiScreened).length;

  return (
    <div className="space-y-8">
      {/* Primary Hero Anchor: 3D AI Voice Assistant Core */}
      <section className="rounded-3xl bg-[#091022] border border-slate-800/80 p-6 sm:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-5 flex flex-col items-center justify-center py-2">
            <AcousticOrb3D
              state={isSpeakingPreview ? "speaking" : "idle"}
              size={220}
              label="DBT LAB AI Call Assistant 3D Voice Core"
            />
            <p className="mt-3 text-xs text-slate-400 text-center">
              {activeVoice.nameBn} · বাংলা ও ইংরেজি ভয়েস ইঞ্জিন
            </p>
          </div>

          <div className="lg:col-span-7 space-y-5">
            <div className="space-y-2">
              <p className="text-xs font-medium tracking-wide text-sky-400">
                DBT LAB AI Call Assistant · {settings.userName}
              </p>
              <h1 className="text-2xl sm:text-3xl font-semibold text-slate-50 leading-snug text-balance">
                আপনার ব্যক্তিগত বাংলা ও ইংরেজি AI ভয়েস কল অ্যাসিস্ট্যান্ট
              </h1>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
                সরাসরি বাংলা বা ইংরেজিতে কথা বলুন, ইনকামিং কল অনুমতির ভিত্তিতে স্ক্রিনিং করুন এবং প্রতিটি কলের পরিষ্কার সারাংশ পান।
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                type="button"
                onClick={onQuickStartVoice}
                className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Mic className="w-4 h-4" />
                <span>AI-এর সাথে কথা বলুন</span>
              </button>

              <button
                type="button"
                onClick={onTestBengaliVoice}
                className="min-h-[44px] px-4 py-2.5 rounded-xl bg-[#0e1833] hover:bg-[#152347] border border-slate-700/80 text-slate-100 text-sm font-medium inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Volume2 className="w-4 h-4 text-sky-400" />
                <span>{isSpeakingPreview ? "কণ্ঠস্বর থামান" : "বাংলা মহিলা কণ্ঠ শুনুন"}</span>
              </button>
            </div>

            <div className="pt-4 border-t border-slate-800/70 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-slate-400">
              <span>
                Gemini API: {geminiReady === null ? "Checking..." : geminiReady ? "Connected (Server)" : "API Key Missing"}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                Microphone: {micPermission === "granted" ? "Permitted" : micPermission === "denied" ? "Blocked" : "Needs Permission"}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                Call Screening: {settings.aiCallScreeningEnabled ? "Authorized in App" : "Disabled"}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Key Operational Metrics Row (4 clean cells, no card-in-card nesting) */}
      <section className="rounded-2xl bg-[#091022] border border-slate-800/80 grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-slate-800/70">
        <div className="p-5 space-y-1">
          <p className="text-xs text-slate-400">মোট কল রেকর্ড</p>
          <p className="text-2xl font-semibold text-slate-50 tabular-nums">{calls.length}</p>
          <p className="text-xs text-slate-400">হিস্ট্রিতে সংরক্ষিত</p>
        </div>
        <div className="p-5 space-y-1">
          <p className="text-xs text-slate-400">AI স্ক্রিনড কল</p>
          <p className="text-2xl font-semibold text-sky-400 tabular-nums">{screenedCount}</p>
          <p className="text-xs text-slate-400">সারাংশসহ যাচাইকৃত</p>
        </div>
        <div className="p-5 space-y-1">
          <p className="text-xs text-slate-400">ভয়েস চ্যাট মেসেজ</p>
          <p className="text-2xl font-semibold text-slate-50 tabular-nums">{chatCount}</p>
          <p className="text-xs text-slate-400">বাংলা · English</p>
        </div>
        <div className="p-5 space-y-1">
          <p className="text-xs text-slate-400">অনুমোদন নীতি</p>
          <p className="text-2xl font-semibold text-slate-50">
            {settings.requireCallApproval ? "সুরক্ষিত" : "শিথিল"}
          </p>
          <p className="text-xs text-slate-400">অনুমতি ছাড়া কল বন্ধ</p>
        </div>
      </section>

      {/* Two-Column Action & Recent Call Summaries */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Call Controls & Honest Platform Status */}
        <section className="lg:col-span-5 rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-5">
          <div className="space-y-1">
            <h2 className="text-base font-semibold text-slate-100">কল ইন্টিগ্রেশন ও দ্রুত অ্যাকশন</h2>
            <p className="text-xs text-slate-400">
              ইনকামিং কল স্ক্রিনিং এবং অনুমতি-সাপেক্ষ আউটগোয়িং কল পরিচালনা করুন
            </p>
          </div>

          <div className="space-y-2.5">
            <button
              type="button"
              onClick={onTriggerIncomingDemo}
              className="w-full min-h-[52px] px-4 py-3 rounded-xl bg-[#0e1833] hover:bg-[#142246] border border-slate-800 flex items-center justify-between text-left transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-lg bg-blue-600/15 border border-blue-500/25 flex items-center justify-center shrink-0">
                  <PhoneIncoming className="w-4 h-4 text-sky-400" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-100 truncate">ইনকামিং কল স্ক্রিনিং টেস্ট</p>
                  <p className="text-xs text-slate-400 truncate">AI পরিচয় ও লাইভ সারাংশ যাচাই করুন</p>
                </div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-400 shrink-0" />
            </button>

            <button
              type="button"
              onClick={onOpenOutgoingDialer}
              className="w-full min-h-[52px] px-4 py-3 rounded-xl bg-[#0e1833] hover:bg-[#142246] border border-slate-800 flex items-center justify-between text-left transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-lg bg-blue-600/15 border border-blue-500/25 flex items-center justify-center shrink-0">
                  <PhoneOutgoing className="w-4 h-4 text-blue-400" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-100 truncate">আউটগোয়িং কল ও Co-Pilot</p>
                  <p className="text-xs text-slate-400 truncate">ভয়েস কমান্ড ও অনুমোদন গেটসহ ডায়ালার</p>
                </div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-400 shrink-0" />
            </button>

            <button
              type="button"
              onClick={() => onNavigate(AppTab.ANDROID_SDK)}
              className="w-full min-h-[52px] px-4 py-3 rounded-xl bg-[#0e1833] hover:bg-[#142246] border border-slate-800 flex items-center justify-between text-left transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-lg bg-slate-800/80 border border-slate-700/70 flex items-center justify-center shrink-0">
                  <Code2 className="w-4 h-4 text-slate-300" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-100 truncate">Native Android Kotlin & Compose</p>
                  <p className="text-xs text-slate-400 truncate">CallScreeningService ও Telecom API কোড</p>
                </div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-400 shrink-0" />
            </button>
          </div>

          <div className="pt-4 border-t border-slate-800/70 space-y-2">
            <div className="flex items-center gap-2 text-xs font-medium text-slate-200">
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
              <span>বাস্তব প্ল্যাটফর্ম স্থিতি (স্বচ্ছ রিপোর্ট)</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              এই ওয়েব প্রিভিউতে Gemini AI চ্যাট, বাংলা মহিলা TTS কণ্ঠ, ভয়েস রিকগনিশন এবং ইন্টারঅ্যাক্টিভ কল স্ক্রিনিং সিমুলেশন সরাসরি কাজ করে। তবে ব্রাউজার স্যান্ডবক্স থেকে সরাসরি মোবাইল নেটওয়ার্ক (PSTN/SIM) কল ধরা বা Default Dialer হওয়া সম্ভব নয়—তার জন্য Android Studio-তে প্রদত্ত Kotlin + Telecom API প্রজেক্ট বিল্ড করতে হবে।
            </p>
          </div>
        </section>

        {/* Recent Call Activity & AI Summaries */}
        <section className="lg:col-span-7 rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-semibold text-slate-100">সাম্প্রতিক কল ও AI সারাংশ</h2>
              <p className="text-xs text-slate-400">প্রতিটি স্ক্রিনড কলের মূল তথ্য ও পরবর্তী করণীয়</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate(AppTab.CALLS)}
              className="min-h-[40px] px-3 py-1.5 text-xs font-medium text-sky-400 hover:text-sky-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              সব দেখুন
            </button>
          </div>

          {calls.length === 0 ? (
            <div className="py-10 text-center space-y-3 border-t border-slate-800/70">
              <p className="text-sm text-slate-300">এখনো কোনো কল রেকর্ড নেই</p>
              <button
                type="button"
                onClick={onTriggerIncomingDemo}
                className="min-h-[40px] px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-medium cursor-pointer"
              >
                প্রথম কল স্ক্রিনিং টেস্ট করুন
              </button>
            </div>
          ) : (
            <div className="divide-y divide-slate-800/70 border-t border-slate-800/70">
              {calls.slice(0, 4).map((call) => (
                <div key={call.id} className="py-4 space-y-2">
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-100 truncate">
                        {call.callerName}
                      </p>
                      <p className="text-xs text-slate-400 font-mono-tabular">
                        {call.phoneNumber} · {call.timestamp} · {formatDuration(call.durationSec)}
                      </p>
                    </div>
                    <span className="text-xs text-slate-300 whitespace-nowrap shrink-0">
                      {call.direction === CallDirection.INCOMING ? "Incoming" : "Outgoing"}
                      {" · "}
                      {call.status === CallStatus.AI_SCREENED ? "AI Screened" : call.category}
                      {call.isSampleDemo ? " · Sample" : ""}
                    </span>
                  </div>
                  <p className="text-sm text-slate-300 leading-relaxed">{call.summaryBn}</p>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
