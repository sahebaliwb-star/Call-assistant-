import { useState } from "react";
import {
  Volume2,
  Shield,
  Mic,
  User,
  Lock,
  Trash2,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";
import { BENGALI_FEMALE_VOICES } from "../data/presets.ts";
import type { UserSettings, VoicePersona } from "../types.ts";

interface SettingsViewProps {
  settings: UserSettings;
  activeVoice: VoicePersona;
  micPermission: "granted" | "denied" | "prompt" | "unsupported";
  isSpeakingPreview: boolean;
  onUpdateSettings: (patch: Partial<UserSettings>) => void;
  onTestVoice: (persona: VoicePersona) => void;
  onRequestMicPermission: () => Promise<void>;
  onResetAllData: () => void;
}

export function SettingsView({
  settings,
  activeVoice,
  micPermission,
  isSpeakingPreview,
  onUpdateSettings,
  onTestVoice,
  onRequestMicPermission,
  onResetAllData,
}: SettingsViewProps) {
  const [confirmReset, setConfirmReset] = useState(false);

  const androidPermissions = [
    {
      name: "RECORD_AUDIO",
      titleBn: "মাইক্রোফোন ও ভয়েস কমান্ড",
      statusText:
        micPermission === "granted"
          ? "Granted (Live in Browser)"
          : micPermission === "denied"
            ? "Denied in Browser"
            : "Needs Request",
      isLiveHere: true,
    },
    {
      name: "READ_PHONE_STATE & CALL_SCREENING",
      titleBn: "ইনকামিং কল শনাক্ত ও স্ক্রিনিং",
      statusText: "Native Android APK Only (Not accessible from Web Browser)",
      isLiveHere: false,
    },
    {
      name: "ROLE_DIALER & ANSWER_PHONE_CALLS",
      titleBn: "Default Dialer ইন্টিগ্রেশন",
      statusText: "Native Android APK Only (Requires Android RoleManager)",
      isLiveHere: false,
    },
    {
      name: "CALL_PHONE & READ_CALL_LOG",
      titleBn: "আউটগোয়িং কল ও কল লগ অ্যাক্সেস",
      statusText: "Native Android APK Only (Browser uses tel: link & local log)",
      isLiveHere: false,
    },
    {
      name: "FOREGROUND_SERVICE_MICROPHONE (Call Recording)",
      titleBn: "সম্মতি-ভিত্তিক কল রেকর্ডিং ও অডিও স্টোরেজ",
      statusText: "Browser VoIP/Mic Vault Live · Standard SIM Recording Blocked on Android 9+",
      isLiveHere: false,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Bengali Female Voice Selection */}
      <section className="rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/15 border border-blue-500/25 flex items-center justify-center">
              <Volume2 className="w-5 h-5 text-sky-400" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-100">বাংলা মহিলা কণ্ঠ ও ভয়েস সেটিংস</h2>
              <p className="text-xs text-slate-400">
                Gemini 3.8 TTS বাংলা মহিলা ভয়েস পার্সোনা নির্বাচন ও গতি নিয়ন্ত্রণ করুন
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onTestVoice(activeVoice)}
            className="min-h-[42px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium inline-flex items-center gap-2 cursor-pointer"
          >
            <Volume2 className="w-4 h-4" />
            <span>{isSpeakingPreview ? "থামান" : "নির্বাচিত কণ্ঠ শুনুন"}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {BENGALI_FEMALE_VOICES.map((voice) => {
            const selected = settings.selectedVoiceId === voice.id;
            return (
              <div
                key={voice.id}
                className={`p-4 rounded-2xl border transition-colors space-y-3 ${
                  selected
                    ? "bg-blue-600/10 border-blue-500/60"
                    : "bg-[#0e1833] border-slate-800"
                }`}
              >
                <div className="space-y-1">
                  <p className="text-sm font-semibold text-slate-100">{voice.nameBn}</p>
                  <p className="text-xs text-slate-400">{voice.roleBn}</p>
                </div>

                <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800/70">
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ selectedVoiceId: voice.id })}
                    className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer ${
                      selected
                        ? "bg-blue-600 text-white"
                        : "bg-[#091022] text-slate-300 hover:text-white border border-slate-700"
                    }`}
                  >
                    {selected ? "নির্বাচিত" : "নির্বাচন করুন"}
                  </button>

                  <button
                    type="button"
                    onClick={() => onTestVoice(voice)}
                    className="min-h-[36px] px-2.5 py-1.5 rounded-lg text-xs text-sky-400 hover:text-sky-300 cursor-pointer"
                  >
                    নমুনা শুনুন
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-3 border-t border-slate-800/70">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">কথা বলার গতি (Speaking Rate)</span>
              <span className="font-mono-tabular text-sky-400">{settings.speakingRate.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min={0.8}
              max={1.25}
              step={0.05}
              value={settings.speakingRate}
              onChange={(e) => onUpdateSettings({ speakingRate: Number(e.target.value) })}
              className="w-full accent-blue-500 cursor-pointer"
            />
          </div>

          <label className="flex items-center justify-between gap-4 cursor-pointer">
            <div>
              <p className="text-sm font-medium text-slate-100">উত্তর স্বয়ংক্রিয়ভাবে পড়ে শোনাবে</p>
              <p className="text-xs text-slate-400">চ্যাট এবং কল স্ক্রিনিংয়ে বাংলা কণ্ঠ চালু থাকবে</p>
            </div>
            <input
              type="checkbox"
              checked={settings.autoSpeakResponses}
              onChange={(e) => onUpdateSettings({ autoSpeakResponses: e.target.checked })}
              className="w-5 h-5 accent-blue-600 cursor-pointer"
            />
          </label>
        </div>
      </section>

      {/* Permission Management (Honest Browser + Android Status) */}
      <section className="rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/15 border border-blue-500/25 flex items-center justify-center">
              <Shield className="w-5 h-5 text-sky-400" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-100">অনুমতি ব্যবস্থাপনা (Permission Management)</h2>
              <p className="text-xs text-slate-400">
                কোন অনুমতিটি ব্রাউজারে সক্রিয় এবং কোনটি Android ডিভাইস নির্ভর তা স্বচ্ছভাবে দেখুন
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => void onRequestMicPermission()}
            className="min-h-[42px] px-4 py-2 rounded-xl bg-[#0e1833] hover:bg-[#17264d] border border-slate-700 text-slate-100 text-xs font-medium inline-flex items-center gap-2 cursor-pointer"
          >
            <Mic className="w-4 h-4 text-sky-400" />
            <span>মাইক্রোফোন অনুমতি যাচাই করুন</span>
          </button>
        </div>

        <div className="divide-y divide-slate-800/70 border-t border-slate-800/70">
          {androidPermissions.map((perm) => (
            <div key={perm.name} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <p className="text-sm font-medium text-slate-100">{perm.titleBn}</p>
                <p className="text-xs text-slate-400 font-mono-tabular">{perm.name}</p>
              </div>
              <div className="flex items-center gap-2 text-xs">
                {perm.isLiveHere && micPermission === "granted" ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                )}
                <span className={perm.isLiveHere && micPermission === "granted" ? "text-emerald-300" : "text-slate-300"}>
                  {perm.statusText}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Profile & Privacy / Security */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-4">
          <div className="flex items-center gap-3">
            <User className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-semibold text-slate-100">প্রোফাইল ও AI গ্রিটিং</h2>
          </div>

          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs text-slate-400">ব্যবহারকারীর নাম</label>
              <input
                type="text"
                value={settings.userName}
                onChange={(e) => onUpdateSettings({ userName: e.target.value })}
                className="w-full min-h-[42px] px-3.5 rounded-xl bg-[#040711] border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs text-slate-400">ভাষা অগ্রাধিকার</label>
              <select
                value={settings.preferredLanguage}
                onChange={(e) =>
                  onUpdateSettings({ preferredLanguage: e.target.value as UserSettings["preferredLanguage"] })
                }
                className="w-full min-h-[42px] px-3.5 rounded-xl bg-[#040711] border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-blue-500"
              >
                <option value="bilingual">বাংলা ও English (Bilingual)</option>
                <option value="bn">শুধুমাত্র বাংলা</option>
                <option value="en">English Priority</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs text-slate-400">ইনকামিং কল স্ক্রিনিং অভিবাদন (বাংলা)</label>
              <textarea
                rows={3}
                value={settings.customGreetingBn}
                onChange={(e) => onUpdateSettings({ customGreetingBn: e.target.value })}
                className="w-full p-3 rounded-xl bg-[#040711] border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
        </section>

        <section className="rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-4">
          <div className="flex items-center gap-3">
            <Lock className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-semibold text-slate-100">প্রাইভেসি ও নিরাপত্তা</h2>
          </div>

          <div className="space-y-4">
            <label className="flex items-center justify-between gap-4 cursor-pointer">
              <div>
                <p className="text-sm font-medium text-slate-100">আউটগোয়িং কলের আগে বাধ্যতামূলক অনুমতি</p>
                <p className="text-xs text-slate-400">আপনার নিশ্চিতকরণ ছাড়া কোনো কল শুরু হবে না</p>
              </div>
              <input
                type="checkbox"
                checked={settings.requireCallApproval}
                onChange={(e) => onUpdateSettings({ requireCallApproval: e.target.checked })}
                className="w-5 h-5 accent-blue-600 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between gap-4 cursor-pointer">
              <div>
                <p className="text-sm font-medium text-slate-100">AI কল স্ক্রিনিং অনুমতি</p>
                <p className="text-xs text-slate-400">ইনকামিং কলে আপনার অনুমোদনে AI কথা বলতে পারবে</p>
              </div>
              <input
                type="checkbox"
                checked={settings.aiCallScreeningEnabled}
                onChange={(e) => onUpdateSettings({ aiCallScreeningEnabled: e.target.checked })}
                className="w-5 h-5 accent-blue-600 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between gap-4 cursor-pointer">
              <div>
                <p className="text-sm font-medium text-slate-100">কল ট্রান্সক্রিপ্ট স্থানীয়ভাবে সংরক্ষণ</p>
                <p className="text-xs text-slate-400">বন্ধ রাখলে শুধু সারাংশ সংরক্ষিত হবে</p>
              </div>
              <input
                type="checkbox"
                checked={settings.saveTranscripts}
                onChange={(e) => onUpdateSettings({ saveTranscripts: e.target.checked })}
                className="w-5 h-5 accent-blue-600 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between gap-4 cursor-pointer">
              <div>
                <p className="text-sm font-medium text-slate-100">ভবিষ্যৎ অনুমোদিত Outgoing AI Audio Bridge</p>
                <p className="text-xs text-slate-400">Android InCallService ডিভাইসে সক্রিয় করার ফ্ল্যাগ</p>
              </div>
              <input
                type="checkbox"
                checked={settings.futureOutgoingAiBridgeEnabled}
                onChange={(e) =>
                  onUpdateSettings({ futureOutgoingAiBridgeEnabled: e.target.checked })
                }
                className="w-5 h-5 accent-blue-600 cursor-pointer"
              />
            </label>

            <div className="pt-3 border-t border-slate-800/70 flex items-center justify-between gap-4">
              <p className="text-xs text-slate-400">
                সকল API কী সার্ভার-সাইডে সুরক্ষিত; ব্রাউজারে কোনো কী সংরক্ষণ করা হয় না।
              </p>

              {!confirmReset ? (
                <button
                  type="button"
                  onClick={() => setConfirmReset(true)}
                  className="min-h-[38px] px-3 py-1.5 rounded-lg border border-red-900/60 text-red-300 hover:bg-red-950/50 text-xs font-medium inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>ডেটা রিসেট</span>
                </button>
              ) : (
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      onResetAllData();
                      setConfirmReset(false);
                    }}
                    className="min-h-[36px] px-3 py-1 rounded-lg bg-red-600 text-white text-xs font-medium cursor-pointer"
                  >
                    নিশ্চিত মুছুন
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmReset(false)}
                    className="min-h-[36px] px-2.5 py-1 text-xs text-slate-400 cursor-pointer"
                  >
                    না
                  </button>
                </div>
              )}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
