import { useEffect, useRef, useState } from "react";
import {
  Play,
  Pause,
  Square,
  Download,
  Trash2,
  Search,
  ShieldCheck,
  AlertTriangle,
  Lock,
} from "lucide-react";
import { CallDirection } from "../types.ts";
import type { CallRecordingItem } from "../types.ts";
import { RecordingControlsBar } from "./RecordingControlsBar.tsx";
import {
  clearAllRecordings,
  deleteRecording,
  getRecordingBlob,
} from "../utils/recordingStore.ts";

interface RecordingHistoryViewProps {
  recordings: CallRecordingItem[];
  onRefreshRecordings: () => Promise<void>;
  onRecordingAdded: (item: CallRecordingItem) => void;
}

function formatDuration(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  return `${(kb / 1024).toFixed(2)} MB`;
}

export function RecordingHistoryView({
  recordings,
  onRefreshRecordings,
  onRecordingAdded,
}: RecordingHistoryViewProps) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "incoming" | "outgoing">("all");
  const [studioCallerName, setStudioCallerName] = useState("আরিফ / অফিস কল");
  const [studioPhoneNumber, setStudioPhoneNumber] = useState("+880 1712-345678");
  const [studioDirection, setStudioDirection] = useState<CallDirection>(CallDirection.INCOMING);

  // Audio playback state
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [playbackError, setPlaybackError] = useState<string | null>(null);
  const [confirmClearAll, setConfirmClearAll] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const objectUrlRef = useRef<string | null>(null);

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }
    if (objectUrlRef.current) {
      URL.revokeObjectURL(objectUrlRef.current);
      objectUrlRef.current = null;
    }
    setPlayingId(null);
    setIsPaused(false);
  };

  useEffect(() => {
    return () => stopAudio();
  }, []);

  const handlePlayToggle = async (item: CallRecordingItem) => {
    setPlaybackError(null);

    if (playingId === item.id && audioRef.current) {
      if (isPaused) {
        await audioRef.current.play();
        setIsPaused(false);
      } else {
        audioRef.current.pause();
        setIsPaused(true);
      }
      return;
    }

    stopAudio();
    try {
      const blob = await getRecordingBlob(item.id);
      if (!blob) {
        setPlaybackError("এই রেকর্ডিংয়ের অডিও ফাইল পাওয়া যায়নি।");
        return;
      }
      const url = URL.createObjectURL(blob);
      objectUrlRef.current = url;
      const audio = new Audio(url);
      audioRef.current = audio;

      audio.onended = () => stopAudio();
      audio.onerror = () => {
        setPlaybackError("অডিও প্লেব্যাক করতে সমস্যা হয়েছে।");
        stopAudio();
      };
      await audio.play();
      setPlayingId(item.id);
      setIsPaused(false);
    } catch (err) {
      setPlaybackError(err instanceof Error ? err.message : "প্লেব্যাক ত্রুটি।");
      stopAudio();
    }
  };

  const handleDownload = async (item: CallRecordingItem) => {
    setPlaybackError(null);
    const blob = await getRecordingBlob(item.id);
    if (!blob) {
      setPlaybackError("ডাউনলোড করার জন্য অডিও ফাইল পাওয়া যায়নি।");
      return;
    }
    const ext = item.mimeType.includes("ogg") ? "ogg" : "webm";
    const safeNumber = item.phoneNumber.replace(/[^0-9+]/g, "") || "call";
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `DBT_LAB_${item.direction}_${safeNumber}_${item.dateStr}.${ext}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const handleDelete = async (id: string) => {
    if (playingId === id) stopAudio();
    await deleteRecording(id);
    await onRefreshRecordings();
  };

  const handleClearAll = async () => {
    stopAudio();
    await clearAllRecordings();
    await onRefreshRecordings();
    setConfirmClearAll(false);
  };

  const filtered = recordings.filter((r) => {
    const matchDir =
      filter === "all" ||
      (filter === "incoming" && r.direction === CallDirection.INCOMING) ||
      (filter === "outgoing" && r.direction === CallDirection.OUTGOING);
    const q = search.trim().toLowerCase();
    const matchQ =
      !q ||
      r.callerName.toLowerCase().includes(q) ||
      r.phoneNumber.toLowerCase().includes(q) ||
      r.dateStr.includes(q);
    return matchDir && matchQ;
  });

  return (
    <div className="space-y-6">
      {/* Honest Android SIM Recording Limitation & Privacy Policy */}
      <section className="rounded-2xl bg-[#091022] border border-amber-500/35 p-5 space-y-3">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1.5">
            <h2 className="text-sm font-semibold text-slate-100">
              Android SIM Call Recording সীমাবদ্ধতা ও স্বচ্ছ নীতি
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Android 9 এবং পরবর্তী সংস্করণে Google ও Android OS নিরাপত্তার কারণে তৃতীয় পক্ষের অ্যাপ থেকে সাধারণ SIM/Cellular কলের অপর প্রান্তের অডিও (<span className="font-mono-tabular">MediaRecorder.AudioSource.VOICE_CALL</span>) রেকর্ড করা সিস্টেম দ্বারা ব্লক করা থাকে।
            </p>
            <p className="text-xs text-slate-400 leading-relaxed">
              তাই ওয়েব প্রিভিউ এবং নন-প্রিভিলেজড ডিভাইসে শুধুমাত্র মাইক্রোফোন / VoIP / স্পিকারফোন ও AI কল স্ক্রিনিং সেশনের অডিও নিরাপদে রেকর্ড হয়। যদি Android ডিভাইসে সাধারণ SIM কল রেকর্ডিং OS কর্তৃক বন্ধ থাকে, অ্যাপটি সেটিকে পরিষ্কারভাবে জানাবে এবং কোনো গোপন রেকর্ডিং করবে না।
            </p>
          </div>
        </div>
      </section>

      {/* Manual / Test Call Recording Studio */}
      <section className="rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-slate-100">নতুন কল রেকর্ডিং সেশন</h2>
            <p className="text-xs text-slate-400">
              Incoming বা Outgoing কলের তথ্য দিয়ে সম্মতিসহ রেকর্ডিং পরীক্ষা ও সংরক্ষণ করুন
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 rounded-xl bg-[#040711] border border-slate-800">
            <button
              type="button"
              onClick={() => setStudioDirection(CallDirection.INCOMING)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer ${
                studioDirection === CallDirection.INCOMING
                  ? "bg-blue-600 text-white"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Incoming
            </button>
            <button
              type="button"
              onClick={() => setStudioDirection(CallDirection.OUTGOING)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer ${
                studioDirection === CallDirection.OUTGOING
                  ? "bg-blue-600 text-white"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Outgoing
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <input
            type="text"
            value={studioCallerName}
            onChange={(e) => setStudioCallerName(e.target.value)}
            placeholder="কলার বা প্রাপকের নাম"
            className="min-h-[42px] px-3.5 rounded-xl bg-[#040711] border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-blue-500"
          />
          <input
            type="text"
            value={studioPhoneNumber}
            onChange={(e) => setStudioPhoneNumber(e.target.value)}
            placeholder="ফোন নম্বর (+880...)"
            className="min-h-[42px] px-3.5 rounded-xl bg-[#040711] border border-slate-800 text-sm text-slate-100 font-mono-tabular focus:outline-none focus:border-blue-500"
          />
        </div>

        <RecordingControlsBar
          callerName={studioCallerName}
          phoneNumber={studioPhoneNumber}
          direction={studioDirection}
          onRecordingSaved={onRecordingAdded}
        />
      </section>

      {/* Recording History Screen */}
      <section className="rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-sky-400" />
              <h2 className="text-base font-semibold text-slate-100">
                Recording History (নিরাপদ স্থানীয় ভল্ট)
              </h2>
            </div>
            <p className="text-xs text-slate-400 tabular-nums">
              {filtered.length} টি সংরক্ষিত রেকর্ডিং · IndexedDB Private Storage
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="নম্বর, নাম বা তারিখ..."
                className="min-h-[40px] pl-9 pr-3 rounded-xl bg-[#040711] border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex items-center gap-1 p-1 rounded-xl bg-[#040711] border border-slate-800">
              {[
                { id: "all", label: "সব" },
                { id: "incoming", label: "Incoming" },
                { id: "outgoing", label: "Outgoing" },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setFilter(t.id as typeof filter)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer ${
                    filter === t.id ? "bg-blue-600 text-white" : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {recordings.length > 0 && !confirmClearAll && (
              <button
                type="button"
                onClick={() => setConfirmClearAll(true)}
                className="min-h-[38px] px-3 py-1.5 rounded-lg border border-red-900/60 text-red-300 hover:bg-red-950/40 text-xs font-medium cursor-pointer"
              >
                সব মুছুন
              </button>
            )}

            {confirmClearAll && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void handleClearAll()}
                  className="min-h-[36px] px-3 py-1 rounded-lg bg-red-600 text-white text-xs font-medium cursor-pointer"
                >
                  নিশ্চিত মুছুন
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClearAll(false)}
                  className="min-h-[36px] px-2 text-xs text-slate-400 cursor-pointer"
                >
                  না
                </button>
              </div>
            )}
          </div>
        </div>

        {playbackError && (
          <div className="p-3 rounded-xl bg-red-950/50 border border-red-800/60 text-xs text-red-200">
            {playbackError}
          </div>
        )}

        {filtered.length === 0 ? (
          <div className="py-12 text-center space-y-2 border-t border-slate-800/70">
            <p className="text-sm text-slate-300">এখনো কোনো কল রেকর্ডিং সংরক্ষিত নেই</p>
            <p className="text-xs text-slate-500">
              উপরের &ldquo;Recording Start&rdquo; বাটন বা ইনকামিং/আউটগোয়িং কল সেশনের মাধ্যমে সম্মতিসহ রেকর্ড করুন।
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-800/70 border-t border-slate-800/70">
            {filtered.map((item) => {
              const isThisPlaying = playingId === item.id;
              return (
                <div
                  key={item.id}
                  className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
                      <span className="text-sm font-medium text-slate-100">{item.callerName}</span>
                      <span className="text-xs text-sky-400 font-mono-tabular">{item.phoneNumber}</span>
                    </div>
                    <p className="text-xs text-slate-400 font-mono-tabular">
                      {item.direction === CallDirection.INCOMING ? "Incoming" : "Outgoing"}
                      {" · "}
                      {item.dateStr} · {item.timeStr}
                      {" · "}
                      {formatDuration(item.durationSec)}
                      {" · "}
                      {formatBytes(item.sizeBytes)}
                    </p>
                    <p className="text-[11px] text-emerald-300 inline-flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                      <span>সম্মতি ও অপর পক্ষকে অবহিতকরণ যাচাইকৃত</span>
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => void handlePlayToggle(item)}
                      className="min-h-[40px] px-3.5 py-2 rounded-xl bg-[#0e1833] hover:bg-[#17264d] border border-slate-700 text-slate-100 text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      {isThisPlaying && !isPaused ? (
                        <>
                          <Pause className="w-3.5 h-3.5 text-amber-400" />
                          <span>Pause</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5 text-sky-400" />
                          <span>{isThisPlaying && isPaused ? "Resume" : "Play"}</span>
                        </>
                      )}
                    </button>

                    {isThisPlaying && (
                      <button
                        type="button"
                        onClick={stopAudio}
                        aria-label="Stop playback"
                        className="min-h-[40px] min-w-[40px] rounded-xl bg-[#0e1833] border border-slate-700 hover:bg-slate-800 text-slate-200 flex items-center justify-center cursor-pointer"
                      >
                        <Square className="w-3.5 h-3.5 text-red-400" />
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => void handleDownload(item)}
                      aria-label="Download recording"
                      className="min-h-[40px] px-3.5 py-2 rounded-xl bg-[#0e1833] hover:bg-[#17264d] border border-slate-700 text-slate-200 text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5 text-sky-400" />
                      <span>Download</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => void handleDelete(item.id)}
                      aria-label="Delete recording"
                      className="min-h-[40px] min-w-[40px] rounded-xl hover:bg-red-950/50 border border-slate-800 text-slate-400 hover:text-red-300 flex items-center justify-center cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
