import { useEffect, useRef } from "react";

export type OrbState = "idle" | "listening" | "thinking" | "speaking" | "ringing";

interface AcousticOrb3DProps {
  state: OrbState;
  audioLevel?: number;
  size?: number;
  label?: string;
}

export function AcousticOrb3D({
  state,
  audioLevel = 0,
  size = 220,
  label,
}: AcousticOrb3DProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const levelRef = useRef(audioLevel);
  const stateRef = useRef(state);

  levelRef.current = audioLevel;
  stateRef.current = state;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = size * dpr;
    canvas.height = size * dpr;

    let animId = 0;
    let phase = 0;
    let smoothLevel = 0;

    const prefersReduced =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const draw = () => {
      const currentState = stateRef.current;
      const targetLevel =
        currentState === "speaking"
          ? Math.max(0.28, levelRef.current)
          : currentState === "listening"
            ? Math.max(0.22, levelRef.current)
            : currentState === "ringing"
              ? 0.45
              : currentState === "thinking"
                ? 0.18
                : 0.05;

      smoothLevel += (targetLevel - smoothLevel) * 0.16;
      phase += prefersReduced ? 0.008 : currentState === "thinking" ? 0.055 : 0.028 + smoothLevel * 0.04;

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, size, size);

      const cx = size / 2;
      const cy = size / 2;
      const baseR = size * 0.31;
      const dynamicR = baseR * (1 + smoothLevel * 0.12);

      // Ambient deep-navy volumetric halo
      const haloColor =
        currentState === "ringing"
          ? "rgba(212, 175, 55, 0.20)"
          : currentState === "listening"
            ? "rgba(56, 189, 248, 0.24)"
            : currentState === "speaking"
              ? "rgba(37, 99, 235, 0.28)"
              : "rgba(37, 99, 235, 0.14)";

      const halo = ctx.createRadialGradient(cx, cy, dynamicR * 0.3, cx, cy, size * 0.48);
      halo.addColorStop(0, haloColor);
      halo.addColorStop(1, "rgba(4, 7, 17, 0)");
      ctx.fillStyle = halo;
      ctx.beginPath();
      ctx.arc(cx, cy, size * 0.48, 0, Math.PI * 2);
      ctx.fill();

      // 3D Sphere body with top-left studio directional rim lighting
      const sphereGrad = ctx.createRadialGradient(
        cx - dynamicR * 0.32,
        cy - dynamicR * 0.36,
        dynamicR * 0.08,
        cx,
        cy,
        dynamicR
      );
      if (currentState === "ringing") {
        sphereGrad.addColorStop(0, "#FDE68A");
        sphereGrad.addColorStop(0.28, "#D4AF37");
        sphereGrad.addColorStop(0.68, "#1E3A8A");
        sphereGrad.addColorStop(1, "#040817");
      } else {
        sphereGrad.addColorStop(0, "#7DD3FC");
        sphereGrad.addColorStop(0.24, "#2563EB");
        sphereGrad.addColorStop(0.65, "#0F1E46");
        sphereGrad.addColorStop(1, "#030712");
      }

      ctx.beginPath();
      ctx.arc(cx, cy, dynamicR, 0, Math.PI * 2);
      ctx.fillStyle = sphereGrad;
      ctx.fill();

      // 3D Geodesic Meridian Rings (perspective projection)
      const ringCount = 5;
      for (let i = 0; i < ringCount; i++) {
        const tilt = phase * (0.6 + i * 0.12) + (i * Math.PI) / ringCount;
        const rx = dynamicR * (0.94 + Math.sin(phase + i) * 0.04);
        const ry = Math.max(4, Math.abs(Math.cos(tilt)) * dynamicR * 0.55);
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate((i * Math.PI) / 5 + Math.sin(phase * 0.4) * 0.18);
        ctx.beginPath();
        ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
        ctx.strokeStyle =
          currentState === "ringing"
            ? `rgba(253, 230, 138, ${0.14 + smoothLevel * 0.22})`
            : `rgba(125, 211, 252, ${0.12 + smoothLevel * 0.26})`;
        ctx.lineWidth = 1.1;
        ctx.stroke();
        ctx.restore();
      }

      // Inner Harmonic Voice Waveform Ribbon
      const wavePoints = 64;
      for (let layer = 0; layer < 2; layer++) {
        ctx.beginPath();
        const amp = (4 + smoothLevel * 22) * (layer === 0 ? 1 : 0.6);
        const freq = layer === 0 ? 3 : 5;
        for (let i = 0; i <= wavePoints; i++) {
          const t = i / wavePoints;
          const x = cx - dynamicR * 0.78 + t * dynamicR * 1.56;
          const envelope = Math.sin(t * Math.PI);
          const y =
            cy +
            Math.sin(t * Math.PI * freq + phase * (layer === 0 ? 2.4 : -3.1)) *
              amp *
              envelope;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.strokeStyle =
          currentState === "ringing"
            ? layer === 0
              ? "rgba(254, 243, 199, 0.9)"
              : "rgba(212, 175, 55, 0.5)"
            : layer === 0
              ? "rgba(224, 242, 254, 0.92)"
              : "rgba(56, 189, 248, 0.52)";
        ctx.lineWidth = layer === 0 ? 2 : 1.25;
        ctx.stroke();
      }

      // Precision outer orbital bezel
      ctx.beginPath();
      ctx.arc(cx, cy, dynamicR + 10 + smoothLevel * 6, 0, Math.PI * 2);
      ctx.strokeStyle =
        currentState === "ringing"
          ? "rgba(212, 175, 55, 0.28)"
          : "rgba(56, 189, 248, 0.18)";
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 6]);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.restore();
      animId = requestAnimationFrame(draw);
    };

    animId = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animId);
  }, [size]);

  return (
    <div className="relative flex flex-col items-center justify-center select-none">
      <canvas
        ref={canvasRef}
        style={{ width: size, height: size }}
        className="block"
        aria-label={label || "DBT LAB 3D AI Voice Wave Visualizer"}
      />
    </div>
  );
}
