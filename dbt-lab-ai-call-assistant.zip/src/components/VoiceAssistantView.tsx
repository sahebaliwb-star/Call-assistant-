import { useCallback, useEffect, useRef, useState } from "react";
import {
  Mic,
  MicOff,
  Send,
  Volume2,
  Play,
  Pause,
  Square,
  Trash2,
  PhoneCall,
  RotateCcw,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import type { ChatMessage, UserSettings, VoicePersona } from "../types.ts";
import { AcousticOrb3D } from "./AcousticOrb3D.tsx";
import type { OrbState } from "./AcousticOrb3D.tsx";
import { voiceAudio } from "../utils/audioEngine.ts";
import type { BrowserVoiceInfo, PlaybackStatus } from "../utils/audioEngine.ts";

interface VoiceAssistantViewProps {
  settings: UserSettings;
  activeVoice: VoicePersona;
  messages: ChatMessage[];
  onAddMessage: (msg: ChatMessage) => void;
  onClearHistory: () => void;
  onVoiceCommandCall: (name: string, phoneNumber: string) => void;
  onTriggerScreenCall: () => void;
  onNavigateSettings: () => void;
  onNavigateCalls: () => void;
}

interface SpeechRecognitionEventLike {
  results: {
    [index: number]: {
      [index: number]: { transcript: string };
      isFinal?: boolean;
    };
    length: number;
  };
}

interface SpeechRecognitionInstance {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((e: SpeechRecognitionEventLike) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

type VoiceOutputEngine = "web-speech-first" | "gemini-tts";

interface DiagnosticReport {
  testedAt: string;
  speechRecognitionSupported: boolean;
  speechRecognitionNote: string;
  geminiChatOk: boolean;
  geminiChatSample: string;
  bengaliVoiceOk: boolean;
  bengaliVoiceNote: string;
}

const QUICK_PROMPTS = [
  "আমার নাম মনে রেখো, আমি আরিফ। আজকের কাজের পরিকল্পনা বাংলায় বলো।",
  "রহিমকে কল করো",
  "ইনকামিং কল স্ক্রিনিং টেস্ট করো",
  "Explain in English how you protect my call privacy.",
];

export function VoiceAssistantView({
  settings,
  activeVoice,
  messages,
  onAddMessage,
  onClearHistory,
  onVoiceCommandCall,
  onTriggerScreenCall,
  onNavigateSettings,
  onNavigateCalls,
}: VoiceAssistantViewProps) {
  const [input, setInput] = useState("");
  const [capturedSpeech, setCapturedSpeech] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [playbackStatus, setPlaybackStatus] = useState<PlaybackStatus>("idle");
  const [activeSpokenText, setActiveSpokenText] = useState<string | null>(null);
  const [activeSpokenAudio, setActiveSpokenAudio] = useState<string | undefined>(undefined);
  const [audioLevel, setAudioLevel] = useState(0);
  const [listenLang, setListenLang] = useState<"bn-BD" | "en-US">(
    settings.preferredLanguage === "en" ? "en-US" : "bn-BD"
  );
  const [continuousLoop, setContinuousLoop] = useState(true);
  const [reviewBeforeSend, setReviewBeforeSend] = useState(false);
  const [voiceOutputEngine, setVoiceOutputEngine] = useState<VoiceOutputEngine>("web-speech-first");
  const [browserVoiceInfo, setBrowserVoiceInfo] = useState<BrowserVoiceInfo>(() =>
    voiceAudio.getBrowserBengaliVoiceInfo()
  );
  const [statusNote, setStatusNote] = useState<string | null>(null);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  // Real live verification diagnostic state
  const [diagRunning, setDiagRunning] = useState(false);
  const [diagnostic, setDiagnostic] = useState<DiagnosticReport | null>(null);

  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const micStreamRef = useRef<MediaStream | null>(null);
  const micAnalyserRef = useRef<AnalyserNode | null>(null);
  const chatEndRef = useRef<HTMLDivElement | null>(null);
  const continuousLoopRef = useRef(continuousLoop);
  const messagesRef = useRef(messages);

  continuousLoopRef.current = continuousLoop;
  messagesRef.current = messages;

  // Listen for browser Web Speech API voices loading
  useEffect(() => {
    const refreshVoices = () => setBrowserVoiceInfo(voiceAudio.getBrowserBengaliVoiceInfo());
    refreshVoices();
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.addEventListener("voiceschanged", refreshVoices);
      return () => window.speechSynthesis.removeEventListener("voiceschanged", refreshVoices);
    }
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  // Real-time audio level polling for 3D Acoustic Orb
  useEffect(() => {
    if (!isListening && playbackStatus !== "playing") {
      setAudioLevel(0);
      return;
    }
    let raf = 0;
    const data = new Uint8Array(64);
    const tick = () => {
      if (playbackStatus === "playing") {
        setAudioLevel(voiceAudio.getOutputLevel() || 0.28);
      } else if (isListening && micAnalyserRef.current) {
        micAnalyserRef.current.getByteFrequencyData(data);
        let sum = 0;
        for (let i = 0; i < data.length; i++) sum += data[i];
        setAudioLevel(Math.min(1, sum / (data.length * 110)));
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [isListening, playbackStatus]);

  const stopAllListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // ignore stop errors
      }
      recognitionRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach((t) => t.stop());
      micStreamRef.current = null;
    }
    micAnalyserRef.current = null;
    setIsListening(false);
  }, []);

  useEffect(() => {
    return () => {
      stopAllListening();
      voiceAudio.stopSpeaking();
    };
  }, [stopAllListening]);

  const speakAssistantReply = useCallback(
    async (
      text: string,
      cachedAudio?: string,
      onComplete?: () => void
    ): Promise<string | undefined> => {
      setErrorBanner(null);
      setActiveSpokenText(text);
      setActiveSpokenAudio(cachedAudio);

      // 1. If user prefers Web Speech API first AND browser has a Bengali voice (e.g. Google বাংলা), use it!
      if (voiceOutputEngine === "web-speech-first" && browserVoiceInfo.available && !cachedAudio) {
        const res = voiceAudio.speakViaBrowserSpeech(
          text,
          settings.speakingRate,
          () => setPlaybackStatus("playing"),
          () => {
            setPlaybackStatus("idle");
            onComplete?.();
          },
          (st) => setPlaybackStatus(st)
        );
        if (res.started) {
          setStatusNote(`Web Speech API: ${res.voiceName}`);
          return undefined;
        }
      }

      // 2. Otherwise use Gemini 3.8 Bengali Female TTS (high-quality WAV audio)
      try {
        if (cachedAudio) {
          await voiceAudio.playBase64Wav(
            cachedAudio,
            settings.speakingRate,
            () => setPlaybackStatus("playing"),
            () => {
              setPlaybackStatus("idle");
              onComplete?.();
            },
            (st) => setPlaybackStatus(st)
          );
          return cachedAudio;
        }

        const ttsRes = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text,
            voiceName: activeVoice.geminiVoiceName,
            style: activeVoice.speechStyle,
          }),
        });

        if (!ttsRes.ok) {
          const errBody = await ttsRes.json().catch(() => ({}));
          throw new Error(errBody.error || "TTS service unavailable");
        }

        const { audioBase64 } = (await ttsRes.json()) as { audioBase64: string };
        setActiveSpokenAudio(audioBase64);
        setStatusNote(
          browserVoiceInfo.available
            ? `Gemini Female TTS (${activeVoice.nameBn})`
            : `ব্রাউজারে Google Bengali Voice না থাকায় Gemini Female TTS (${activeVoice.nameBn}) ব্যবহৃত হচ্ছে`
        );

        await voiceAudio.playBase64Wav(
          audioBase64,
          settings.speakingRate,
          () => setPlaybackStatus("playing"),
          () => {
            setPlaybackStatus("idle");
            onComplete?.();
          },
          (st) => setPlaybackStatus(st)
        );
        return audioBase64;
      } catch (err) {
        setPlaybackStatus("idle");
        const msg = err instanceof Error ? err.message : "Voice synthesis error";
        // Last resort: try browser Web Speech API if available
        const fallback = voiceAudio.speakViaBrowserSpeech(
          text,
          settings.speakingRate,
          () => setPlaybackStatus("playing"),
          () => {
            setPlaybackStatus("idle");
            onComplete?.();
          },
          (st) => setPlaybackStatus(st)
        );
        if (!fallback.started) {
          setErrorBanner(`ভয়েস আউটপুট ব্যর্থ হয়েছে: ${msg}`);
          onComplete?.();
        }
        return undefined;
      }
    },
    [
      activeVoice.geminiVoiceName,
      activeVoice.nameBn,
      activeVoice.speechStyle,
      browserVoiceInfo.available,
      settings.speakingRate,
      voiceOutputEngine,
    ]
  );

  // Ref for re-opening mic after AI finishes speaking in continuous conversation
  const startVoiceCaptureRef = useRef<(() => Promise<void>) | null>(null);

  const sendMessageToAi = useCallback(
    async (textToSend: string, fromVoiceTurn = false) => {
      const clean = textToSend.trim();
      if (!clean || isSending) return;

      setErrorBanner(null);
      setInput("");
      setCapturedSpeech("");

      const userMsg: ChatMessage = {
        id: `u-${Date.now()}`,
        role: "user",
        text: clean,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      onAddMessage(userMsg);
      setIsSending(true);

      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: clean,
            history: [...messagesRef.current, userMsg]
              .slice(-14)
              .map((m) => ({ role: m.role, text: m.text })),
            userName: settings.userName,
            preferredLanguage: settings.preferredLanguage,
            voicePersona: activeVoice.nameEn,
          }),
        });

        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || "Failed to reach DBT LAB AI server.");
        }

        const assistantMsg: ChatMessage = {
          id: `a-${Date.now()}`,
          role: "assistant",
          text: data.replyText || "দুঃখিত, উত্তর তৈরি করতে সমস্যা হয়েছে।",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          language: data.language === "en" ? "en" : "bn",
          commandType: data.commandType,
          targetName: data.targetName,
          targetNumber: data.targetNumber,
          suggestedFollowUps: Array.isArray(data.suggestedFollowUps) ? data.suggestedFollowUps : [],
        };

        onAddMessage(assistantMsg);
        setIsSending(false);

        // Execute safe voice commands
        if (data.commandType === "MAKE_CALL" && (data.targetName || data.targetNumber)) {
          onVoiceCommandCall(data.targetName || "", data.targetNumber || "");
        } else if (data.commandType === "SCREEN_CALL") {
          onTriggerScreenCall();
        } else if (data.commandType === "OPEN_SETTINGS") {
          onNavigateSettings();
        } else if (data.commandType === "OPEN_HISTORY") {
          onNavigateCalls();
        }

        const shouldAutoResumeMic =
          fromVoiceTurn &&
          continuousLoopRef.current &&
          (!data.commandType || data.commandType === "NONE");

        if (settings.autoSpeakResponses) {
          await speakAssistantReply(assistantMsg.text, undefined, () => {
            if (shouldAutoResumeMic && startVoiceCaptureRef.current) {
              setStatusNote("AI-এর উত্তর শেষ — এখন আপনি আবার কথা বলতে পারেন...");
              void startVoiceCaptureRef.current();
            }
          });
        } else if (shouldAutoResumeMic && startVoiceCaptureRef.current) {
          void startVoiceCaptureRef.current();
        }
      } catch (err) {
        setIsSending(false);
        setErrorBanner(err instanceof Error ? err.message : "Failed to connect to Gemini AI.");
      }
    },
    [
      activeVoice.nameEn,
      isSending,
      onAddMessage,
      onNavigateCalls,
      onNavigateSettings,
      onTriggerScreenCall,
      onVoiceCommandCall,
      settings.autoSpeakResponses,
      settings.preferredLanguage,
      settings.userName,
      speakAssistantReply,
    ]
  );

  const startVoiceCapture = useCallback(async () => {
    setErrorBanner(null);
    setCapturedSpeech("");
    voiceAudio.stopSpeaking();
    setPlaybackStatus("idle");

    if (!navigator.mediaDevices?.getUserMedia) {
      setErrorBanner("এই ব্রাউজারে Microphone API সমর্থিত নয়।");
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;

      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      const src = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 128;
      src.connect(analyser);
      micAnalyserRef.current = analyser;

      const SpeechRec =
        (window as unknown as { SpeechRecognition?: new () => SpeechRecognitionInstance }).SpeechRecognition ||
        (window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognitionInstance }).webkitSpeechRecognition;

      if (SpeechRec) {
        setIsListening(true);
        setStatusNote(
          `শুনছি (${listenLang === "bn-BD" ? "বাংলা Speech Recognition" : "English Speech Recognition"})...`
        );
        const rec = new SpeechRec();
        rec.lang = listenLang;
        rec.interimResults = true;
        rec.continuous = false;

        let latestTranscript = "";
        let hadError = false;

        rec.onresult = (e: SpeechRecognitionEventLike) => {
          let text = "";
          for (let i = 0; i < e.results.length; i++) {
            text += e.results[i][0].transcript;
          }
          latestTranscript = text.trim();
          setCapturedSpeech(latestTranscript);
          setInput(latestTranscript);
        };
        rec.onerror = (ev) => {
          hadError = true;
          stopAllListening();
          if (ev.error === "no-speech") {
            setStatusNote("কোনো কথা শোনা যায়নি। আবার চেষ্টা করতে মাইক্রোফোন চাপুন।");
          } else if (ev.error === "not-allowed") {
            setErrorBanner("মাইক্রোফোন অনুমতি প্রত্যাখ্যান করা হয়েছে।");
          } else {
            setStatusNote(`Speech Recognition ত্রুটি (${ev.error}) — আবার বলুন বা টাইপ করুন।`);
          }
        };
        rec.onend = () => {
          stopAllListening();
          if (!hadError && latestTranscript) {
            if (reviewBeforeSend) {
              setStatusNote("আপনার কথা শনাক্ত হয়েছে — সঠিক হলে পাঠান অথবা ভুল হলে 'আবার বলুন' চাপুন।");
            } else {
              void sendMessageToAi(latestTranscript, true);
            }
          }
        };
        recognitionRef.current = rec;
        rec.start();
      } else {
        // Fallback: MediaRecorder + Server Gemini 3.5 Transcribe
        setIsListening(true);
        setStatusNote(
          "অডিও রেকর্ড হচ্ছে (Gemini Transcribe)... কথা শেষে থামাতে মাইক্রোফোন বাটনে চাপ দিন।"
        );
        audioChunksRef.current = [];
        const recorder = new MediaRecorder(stream);
        mediaRecorderRef.current = recorder;

        recorder.ondataavailable = (ev) => {
          if (ev.data.size > 0) audioChunksRef.current.push(ev.data);
        };
        recorder.onstop = () => {
          const blob = new Blob(audioChunksRef.current, { type: recorder.mimeType || "audio/webm" });
          const reader = new FileReader();
          reader.onloadend = async () => {
            const base64 = String(reader.result || "").split(",")[1];
            if (!base64) return;
            setStatusNote("বাংলা/ইংরেজি অডিও ট্রান্সক্রাইব করা হচ্ছে...");
            try {
              const res = await fetch("/api/transcribe", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ audioBase64: base64, mimeType: blob.type || "audio/webm" }),
              });
              const data = await res.json();
              if (!res.ok) throw new Error(data.error || "Transcription failed");
              const transcript = (data.text || "").trim();
              if (transcript) {
                setCapturedSpeech(transcript);
                setInput(transcript);
                if (reviewBeforeSend) {
                  setStatusNote("অডিও ট্রান্সক্রাইব সম্পন্ন — যাচাই করে পাঠান বা আবার বলুন।");
                } else {
                  setStatusNote(null);
                  await sendMessageToAi(transcript, true);
                }
              } else {
                setStatusNote("কোনো কথা শনাক্ত হয়নি, অনুগ্রহ করে আবার বলুন।");
              }
            } catch (err) {
              setErrorBanner(err instanceof Error ? err.message : "Audio transcription error.");
            }
          };
          reader.readAsDataURL(blob);
        };
        recorder.start();
      }
    } catch {
      setErrorBanner("মাইক্রোফোন অনুমতি পাওয়া যায়নি। অনুগ্রহ করে ব্রাউজার থেকে Microphone Allow করুন।");
      setIsListening(false);
    }
  }, [listenLang, reviewBeforeSend, sendMessageToAi, stopAllListening]);

  startVoiceCaptureRef.current = startVoiceCapture;

  const toggleMic = () => {
    if (isListening) {
      stopAllListening();
    } else {
      void startVoiceCapture();
    }
  };

  const handlePlayPause = () => {
    if (playbackStatus === "playing") {
      voiceAudio.pauseSpeaking();
    } else if (playbackStatus === "paused") {
      voiceAudio.resumeSpeaking();
    } else if (activeSpokenText) {
      void speakAssistantReply(activeSpokenText, activeSpokenAudio);
    } else {
      const lastAi = [...messages].reverse().find((m) => m.role === "assistant");
      if (lastAi) {
        void speakAssistantReply(lastAi.text, lastAi.audioBase64);
      } else {
        void speakAssistantReply(activeVoice.sampleGreetingBn);
      }
    }
  };

  const handleStopPlayback = () => {
    voiceAudio.stopSpeaking();
    setPlaybackStatus("idle");
  };

  // Real Live Feature Verification (Step 6: পরীক্ষা)
  const runLiveDiagnostics = async () => {
    setDiagRunning(true);
    setErrorBanner(null);

    const hasSpeechRec = Boolean(
      (window as unknown as { SpeechRecognition?: unknown }).SpeechRecognition ||
        (window as unknown as { webkitSpeechRecognition?: unknown }).webkitSpeechRecognition
    );
    const voiceInfo = voiceAudio.getBrowserBengaliVoiceInfo();
    setBrowserVoiceInfo(voiceInfo);

    let geminiChatOk = false;
    let geminiChatSample = "";
    try {
      const chatRes = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: "তুমি কি বাংলা ও ইংরেজি বুঝতে পারো? এক বাক্যে উত্তর দাও।",
          history: [],
          userName: settings.userName,
          preferredLanguage: "bn",
          voicePersona: activeVoice.nameEn,
        }),
      });
      const chatData = await chatRes.json();
      if (chatRes.ok && chatData.replyText) {
        geminiChatOk = true;
        geminiChatSample = chatData.replyText;
      } else {
        geminiChatSample = chatData.error || "API error";
      }
    } catch (err) {
      geminiChatSample = err instanceof Error ? err.message : "Network error";
    }

    let ttsOk = false;
    let ttsNote = "";
    if (voiceInfo.available) {
      ttsOk = true;
      ttsNote = `Web Speech API active: ${voiceInfo.selectedVoiceName} (${voiceInfo.selectedVoiceLang})`;
    } else {
      try {
        const ttsRes = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text: "নমস্কার, আমি ডিবিটি ল্যাব এআই কল অ্যাসিস্ট্যান্ট।",
            voiceName: activeVoice.geminiVoiceName,
            style: activeVoice.speechStyle,
          }),
        });
        const ttsData = await ttsRes.json();
        if (ttsRes.ok && ttsData.audioBase64) {
          ttsOk = true;
          ttsNote = `Browser Web Speech bn voice নেই; Gemini Female TTS (${activeVoice.nameBn}) সচল`;
        } else {
          ttsNote = ttsData.error || "TTS failed";
        }
      } catch (err) {
        ttsNote = err instanceof Error ? err.message : "TTS error";
      }
    }

    setDiagnostic({
      testedAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
      speechRecognitionSupported: hasSpeechRec,
      speechRecognitionNote: hasSpeechRec
        ? "Browser SpeechRecognition (bn-BD / en-US) সমর্থিত"
        : "Browser SpeechRecognition নেই; MediaRecorder + Gemini Transcribe fallback সক্রিয়",
      geminiChatOk,
      geminiChatSample,
      bengaliVoiceOk: ttsOk,
      bengaliVoiceNote: ttsNote,
    });
    setDiagRunning(false);
  };

  const orbState: OrbState = isListening
    ? "listening"
    : isSending
      ? "thinking"
      : playbackStatus === "playing"
        ? "speaking"
        : "idle";

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: 3D Voice Console, Live Transcript Review & Play/Pause/Stop */}
        <section className="lg:col-span-5 rounded-3xl bg-[#091022] border border-slate-800/80 p-6 flex flex-col items-center text-center space-y-5">
          <div className="w-full flex items-center justify-between gap-2">
            <div className="text-left">
              <h2 className="text-base font-semibold text-slate-100">AI ভয়েস কনসোল</h2>
              <p className="text-xs text-slate-400">{activeVoice.nameBn}</p>
            </div>
            <div className="flex items-center gap-1 p-1 rounded-lg bg-[#040711] border border-slate-800">
              <button
                type="button"
                onClick={() => setListenLang("bn-BD")}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  listenLang === "bn-BD" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-slate-200"
                }`}
              >
                বাংলা
              </button>
              <button
                type="button"
                onClick={() => setListenLang("en-US")}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  listenLang === "en-US" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-slate-200"
                }`}
              >
                English
              </button>
            </div>
          </div>

          <AcousticOrb3D state={orbState} audioLevel={audioLevel} size={224} />

          <div className="space-y-1 min-h-[40px]">
            <p className="text-sm font-medium text-slate-100">
              {isListening
                ? "আপনার কথা শুনছি..."
                : isSending
                  ? "Gemini AI উত্তর তৈরি করছে..."
                  : playbackStatus === "playing"
                    ? `${activeVoice.nameBn} কথা বলছেন`
                    : playbackStatus === "paused"
                      ? "ভয়েস আউটপুট বিরতি (Paused)"
                      : "কথা বলতে মাইক্রোফোন চাপুন"}
            </p>
            {statusNote && <p className="text-xs text-sky-400">{statusNote}</p>}
          </div>

          {/* Primary Mic + Play / Pause / Stop Controls */}
          <div className="flex flex-wrap items-center justify-center gap-2.5">
            <button
              type="button"
              onClick={toggleMic}
              disabled={isSending}
              aria-label={isListening ? "Stop listening" : "Start voice command"}
              className={`min-h-[48px] px-5 py-2.5 rounded-2xl font-medium text-sm inline-flex items-center gap-2 transition-colors cursor-pointer ${
                isListening
                  ? "bg-red-600 hover:bg-red-500 text-white"
                  : "bg-blue-600 hover:bg-blue-500 text-white"
              } disabled:opacity-50`}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              <span>{isListening ? "শোনা থামান" : "কথা বলুন"}</span>
            </button>

            <button
              type="button"
              onClick={handlePlayPause}
              aria-label={playbackStatus === "playing" ? "Pause voice" : "Play voice"}
              className="min-h-[48px] px-3.5 py-2.5 rounded-2xl bg-[#0e1833] border border-slate-700 hover:bg-slate-800 text-slate-100 text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
            >
              {playbackStatus === "playing" ? (
                <>
                  <Pause className="w-4 h-4 text-sky-400" />
                  <span>Pause</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 text-sky-400" />
                  <span>{playbackStatus === "paused" ? "Resume" : "Play"}</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleStopPlayback}
              disabled={playbackStatus === "idle"}
              aria-label="Stop voice playback"
              className="min-h-[48px] px-3.5 py-2.5 rounded-2xl bg-[#0e1833] border border-slate-700 hover:bg-slate-800 disabled:opacity-40 text-slate-100 text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Square className="w-3.5 h-3.5 text-red-400" />
              <span>Stop</span>
            </button>
          </div>

          {/* Live Captured Speech Transcript & Retry/Fix Option */}
          {(isListening || capturedSpeech) && (
            <div className="w-full p-3.5 rounded-2xl bg-[#040711] border border-slate-800 text-left space-y-2.5">
              <div className="flex items-center justify-between gap-2 text-xs text-slate-400">
                <span>আপনার বলা কথা (Speech Transcript)</span>
                {isListening && <span className="text-sky-400">Live</span>}
              </div>
              <p className="text-sm text-slate-100 min-h-[24px] leading-relaxed">
                {capturedSpeech || "কথা বলার জন্য অপেক্ষা করছি..."}
              </p>
              {!isListening && capturedSpeech && (
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => void sendMessageToAi(capturedSpeech, true)}
                    className="min-h-[36px] px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>পাঠান</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => void startVoiceCapture()}
                    className="min-h-[36px] px-3.5 py-1.5 rounded-lg bg-[#0e1833] hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>ভুল হয়েছে, আবার বলুন</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Voice Conversation & Engine Preferences */}
          <div className="w-full pt-4 border-t border-slate-800/70 space-y-3 text-left">
            <label className="flex items-center justify-between gap-3 text-xs cursor-pointer">
              <span className="text-slate-300">কথোপকথন লুপ (AI উত্তর শেষে আবার শুনবে)</span>
              <input
                type="checkbox"
                checked={continuousLoop}
                onChange={(e) => setContinuousLoop(e.target.checked)}
                className="w-4 h-4 accent-blue-600 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between gap-3 text-xs cursor-pointer">
              <span className="text-slate-300">পাঠানোর আগে কথা যাচাই করব (ভুল সংশোধন)</span>
              <input
                type="checkbox"
                checked={reviewBeforeSend}
                onChange={(e) => setReviewBeforeSend(e.target.checked)}
                className="w-4 h-4 accent-blue-600 cursor-pointer"
              />
            </label>

            <div className="space-y-1.5 pt-1">
              <p className="text-xs text-slate-400">বাংলা মহিলা Voice Engine</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setVoiceOutputEngine("web-speech-first")}
                  className={`px-3 py-2 rounded-xl border text-xs font-medium text-left cursor-pointer ${
                    voiceOutputEngine === "web-speech-first"
                      ? "bg-blue-600/15 border-blue-500/60 text-slate-100"
                      : "bg-[#0e1833] border-slate-800 text-slate-400"
                  }`}
                >
                  Web Speech (Auto)
                </button>
                <button
                  type="button"
                  onClick={() => setVoiceOutputEngine("gemini-tts")}
                  className={`px-3 py-2 rounded-xl border text-xs font-medium text-left cursor-pointer ${
                    voiceOutputEngine === "gemini-tts"
                      ? "bg-blue-600/15 border-blue-500/60 text-slate-100"
                      : "bg-[#0e1833] border-slate-800 text-slate-400"
                  }`}
                >
                  Gemini Female TTS
                </button>
              </div>
              <p className="text-[11px] text-slate-400">
                {browserVoiceInfo.available
                  ? `Browser Bengali Voice: ${browserVoiceInfo.selectedVoiceName} (${browserVoiceInfo.selectedVoiceLang})`
                  : "এই ব্রাউজারে Google Bengali Voice নেই; Gemini 3.8 Female TTS দিয়ে বাংলা কণ্ঠ চালু হবে।"}
              </p>
            </div>
          </div>

          <div className="w-full pt-4 border-t border-slate-800/70 space-y-2 text-left">
            <p className="text-xs font-medium text-slate-400">দ্রুত ভয়েস কমান্ড</p>
            <div className="flex flex-wrap gap-2">
              {QUICK_PROMPTS.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => void sendMessageToAi(q, false)}
                  className="text-left text-xs px-3 py-2 rounded-lg bg-[#0e1833] hover:bg-[#162449] border border-slate-800 text-slate-200 transition-colors cursor-pointer"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Right: Conversational AI Chat & Audio Replay History */}
        <section className="lg:col-span-7 rounded-3xl bg-[#091022] border border-slate-800/80 flex flex-col h-[640px]">
          <div className="px-6 py-4 border-b border-slate-800/70 flex items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-semibold text-slate-100">AI কথোপকথন ও ভয়েস হিস্ট্রি</h2>
              <p className="text-xs text-slate-400">
                Gemini AI · আগের প্রসঙ্গ মনে রাখে · {messages.length} টি মেসেজ
              </p>
            </div>
            {messages.length > 0 && (
              <button
                type="button"
                onClick={onClearHistory}
                className="min-h-[38px] px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-100 hover:bg-slate-800/60 inline-flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>হিস্ট্রি মুছুন</span>
              </button>
            )}
          </div>

          {errorBanner && (
            <div className="mx-6 mt-4 p-3 rounded-xl bg-red-950/50 border border-red-800/60 text-xs text-red-200">
              {errorBanner}
            </div>
          )}

          <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-2 px-4">
                <p className="text-sm font-medium text-slate-200">
                  DBT LAB AI Call Assistant প্রস্তুত
                </p>
                <p className="text-xs text-slate-400 max-w-md leading-relaxed">
                  &ldquo;কথা বলুন&rdquo; বাটনে চাপ দিয়ে বাংলা বা ইংরেজিতে কথা বলুন অথবা নিচে লিখে পাঠান। AI আপনার প্রশ্নের উত্তর বাংলা মহিলা কণ্ঠে পড়ে শোনাবে এবং আগের কথোপকথন মনে রাখবে।
                </p>
              </div>
            ) : (
              messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col ${m.role === "user" ? "items-end" : "items-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 space-y-2 ${
                      m.role === "user"
                        ? "bg-blue-600 text-white"
                        : "bg-[#0e1833] border border-slate-800 text-slate-100"
                    }`}
                  >
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.text}</p>

                    {m.role === "assistant" && m.commandType === "MAKE_CALL" && (
                      <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between gap-3">
                        <span className="text-xs text-sky-300">
                          কল কমান্ড শনাক্ত: {m.targetName || m.targetNumber}
                        </span>
                        <button
                          type="button"
                          onClick={() => onVoiceCommandCall(m.targetName || "", m.targetNumber || "")}
                          className="min-h-[34px] px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
                        >
                          <PhoneCall className="w-3.5 h-3.5" />
                          <span>অনুমতি ও কল দেখুন</span>
                        </button>
                      </div>
                    )}

                    <div className="flex items-center justify-between gap-4 pt-1 text-[11px] opacity-80">
                      <span className="tabular-nums">{m.timestamp}</span>
                      {m.role === "assistant" && (
                        <div className="flex items-center gap-2.5">
                          <button
                            type="button"
                            onClick={() => void speakAssistantReply(m.text, m.audioBase64)}
                            className="inline-flex items-center gap-1 hover:text-sky-300 transition-colors cursor-pointer"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                            <span>শুনুন</span>
                          </button>
                          {playbackStatus !== "idle" && activeSpokenText === m.text && (
                            <button
                              type="button"
                              onClick={handleStopPlayback}
                              className="inline-flex items-center gap-1 text-red-300 hover:text-red-200 cursor-pointer"
                            >
                              <Square className="w-3 h-3" />
                              <span>থামান</span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
            <div ref={chatEndRef} />
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              void sendMessageToAi(input, false);
            }}
            className="p-4 border-t border-slate-800/70 flex items-center gap-2.5"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="বাংলা বা ইংরেজিতে লিখুন..."
              className="flex-1 min-h-[44px] px-4 rounded-xl bg-[#040711] border border-slate-800 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
            />
            <button
              type="submit"
              disabled={!input.trim() || isSending}
              aria-label="Send message"
              className="min-h-[44px] min-w-[44px] px-4 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-sm font-medium inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">পাঠান</span>
            </button>
          </form>
        </section>
      </div>

      {/* Step 6: Live System Diagnostics & Verification Panel */}
      <section className="rounded-2xl bg-[#091022] border border-slate-800/80 p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-semibold text-slate-100">
              ভয়েস ও Gemini AI লাইভ পরীক্ষা (Real Feature Verification)
            </h3>
            <p className="text-xs text-slate-400">
              বাংলা Voice Input, Gemini AI সার্ভার উত্তর এবং বাংলা মহিলা Voice Output বাস্তবে পরীক্ষা করুন
            </p>
          </div>
          <button
            type="button"
            disabled={diagRunning}
            onClick={() => void runLiveDiagnostics()}
            className="min-h-[42px] px-4 py-2 rounded-xl bg-[#0e1833] hover:bg-[#17264d] border border-blue-500/40 text-slate-100 text-xs font-medium inline-flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 text-sky-400 ${diagRunning ? "animate-spin" : ""}`} />
            <span>{diagRunning ? "পরীক্ষা চলছে..." : "সিস্টেম পরীক্ষা চালান"}</span>
          </button>
        </div>

        {diagnostic && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 border-t border-slate-800/70">
            <div className="p-4 rounded-xl bg-[#040711] border border-slate-800 space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-medium text-slate-200">
                <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                <span>১. বাংলা Voice Input</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {diagnostic.speechRecognitionNote}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#040711] border border-slate-800 space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-medium text-slate-200">
                {diagnostic.geminiChatOk ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                )}
                <span>২. Gemini AI Server Response</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {diagnostic.geminiChatSample}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#040711] border border-slate-800 space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-medium text-slate-200">
                {diagnostic.bengaliVoiceOk ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                )}
                <span>৩. বাংলা মহিলা Voice Output</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {diagnostic.bengaliVoiceNote}
              </p>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
