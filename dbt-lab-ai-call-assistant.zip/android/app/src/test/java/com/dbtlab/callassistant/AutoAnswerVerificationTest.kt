package com.dbtlab.callassistant

import com.dbtlab.callassistant.telecom.AutoAnswerDelay
import com.dbtlab.callassistant.telecom.AutoAnswerEligibility
import com.dbtlab.callassistant.telecom.AutoAnswerGuard
import com.dbtlab.callassistant.telecom.AutoAnswerSettings
import com.dbtlab.callassistant.telecom.IncomingSimCategory
import com.dbtlab.callassistant.telecom.PublicApiCapabilities
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AutoAnswerVerificationTest {

    @Test
    fun `auto answer OFF blocks incoming call even on Jio SIM`() {
        val settings = AutoAnswerSettings(
            enabled = false,
            delay = AutoAnswerDelay.FIVE_SECONDS,
            jioSimOnly = true
        )
        val result = AutoAnswerGuard.evaluateRules(
            settings = settings,
            isEmergency = false,
            simCategory = IncomingSimCategory.JIO_SIM,
            carrierName = "Jio 4G",
            callerNumber = "+919876543210",
            isDefaultDialer = true
        )
        assertTrue(result is AutoAnswerEligibility.Blocked)
    }

    @Test
    fun `auto answer ON with 5s delay allows Jio SIM when default dialer`() {
        val settings = AutoAnswerSettings(
            enabled = true,
            delay = AutoAnswerDelay.FIVE_SECONDS,
            jioSimOnly = true
        )
        val result = AutoAnswerGuard.evaluateRules(
            settings = settings,
            isEmergency = false,
            simCategory = IncomingSimCategory.JIO_SIM,
            carrierName = "Jio 4G",
            callerNumber = "+919876543210",
            isDefaultDialer = true
        )
        assertTrue(result is AutoAnswerEligibility.Eligible)
        assertEquals(5, settings.delay.seconds)
    }

    @Test
    fun `jio only mode keeps other SIM calls ringing normally`() {
        val settings = AutoAnswerSettings(
            enabled = true,
            delay = AutoAnswerDelay.FIVE_SECONDS,
            jioSimOnly = true
        )
        val result = AutoAnswerGuard.evaluateRules(
            settings = settings,
            isEmergency = false,
            simCategory = IncomingSimCategory.OTHER_SIM,
            carrierName = "Airtel",
            callerNumber = "+919876543210",
            isDefaultDialer = true
        )
        assertTrue(result is AutoAnswerEligibility.Blocked)
    }

    @Test
    fun `emergency numbers are never auto answered`() {
        val settings = AutoAnswerSettings(
            enabled = true,
            delay = AutoAnswerDelay.THREE_SECONDS,
            jioSimOnly = false
        )
        val emergencyList = listOf("112", "911", "100", "101", "102", "108")
        emergencyList.forEach { number ->
            assertTrue(AutoAnswerGuard.isKnownEmergencyNumber(number))
            val result = AutoAnswerGuard.evaluateRules(
                settings = settings,
                isEmergency = true,
                simCategory = IncomingSimCategory.JIO_SIM,
                carrierName = "Jio 4G",
                callerNumber = number,
                isDefaultDialer = true
            )
            assertTrue("Emergency $number must be blocked", result is AutoAnswerEligibility.Blocked)
        }
    }

    @Test
    fun `stop auto answer cancels 5 second countdown before answering`() = runTest {
        var answered = false
        var stopped = false

        val job = launch {
            try {
                for (sec in 5 downTo 1) {
                    delay(1000L)
                }
                answered = true
            } catch (_: CancellationException) {
                stopped = true
            }
        }

        // Advance 2.5 seconds then press Stop Auto Answer
        testScheduler.advanceTimeBy(2500L)
        job.cancel()
        testScheduler.advanceUntilIdle()

        assertTrue(stopped)
        assertFalse(answered)
    }

    @Test
    fun `public API capability does not fake AI voice injection into SIM uplink`() {
        assertFalse(PublicApiCapabilities.DIRECT_PSTN_UPLINK_AI_INJECTION)
    }
}
