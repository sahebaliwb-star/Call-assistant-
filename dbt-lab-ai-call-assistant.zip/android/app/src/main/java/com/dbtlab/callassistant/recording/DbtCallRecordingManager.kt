package com.dbtlab.callassistant.recording

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class RecordingStartResult {
    data class Started(val file: File, val sourceMode: String) : RecordingStartResult()
    data class BlockedByOs(val reasonBn: String) : RecordingStartResult()
    data class ConsentRequired(val reasonBn: String) : RecordingStartResult()
}

class DbtCallRecordingManager(private val context: Context) {

    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null

    fun startRecording(
        phoneNumber: String,
        direction: String,
        userConsented: Boolean,
        otherPartyNotified: Boolean,
        isStandardSimCall: Boolean
    ): RecordingStartResult {
        // Strict anti-covert-recording policy: never record without consent & disclosure
        if (!userConsented || !otherPartyNotified) {
            return RecordingStartResult.ConsentRequired(
                "ব্যবহারকারীর সম্মতি এবং অপর পক্ষকে অবহিত করা ছাড়া কোনো কল রেকর্ড করা যাবে না।"
            )
        }

        // Android 9+ restricts third-party apps from recording raw PSTN/SIM call downlink
        if (isStandardSimCall && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return RecordingStartResult.BlockedByOs(
                "Android OS সীমাবদ্ধতার কারণে সাধারণ SIM কল অডিও রেকর্ড করা সম্ভব নয়।"
            )
        }

        val secureDir = File(context.filesDir, "dbt_secure_recordings").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safeNum = phoneNumber.replace(Regex("[^0-9+]"), "")
        val targetFile = File(secureDir, "DBT_${direction}_${safeNum}_${stamp}.m4a")
        outputFile = targetFile

        return try {
            val mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            mediaRecorder.apply {
                setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(128000)
                setOutputFile(targetFile.absolutePath)
                prepare()
                start()
            }
            recorder = mediaRecorder
            RecordingStartResult.Started(targetFile, "VOICE_COMMUNICATION")
        } catch (e: Exception) {
            targetFile.delete()
            RecordingStartResult.BlockedByOs(
                "ডিভাইস অডিও সোর্স সীমাবদ্ধতার কারণে কল রেকর্ড শুরু করা যায়নি: ${e.localizedMessage}"
            )
        }
    }

    fun pauseRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            recorder?.pause()
        }
    }

    fun resumeRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            recorder?.resume()
        }
    }

    fun stopRecording(): File? {
        return try {
            recorder?.apply {
                stop()
                release()
            }
            recorder = null
            outputFile
        } catch (_: Exception) {
            recorder?.release()
            recorder = null
            null
        }
    }
}
