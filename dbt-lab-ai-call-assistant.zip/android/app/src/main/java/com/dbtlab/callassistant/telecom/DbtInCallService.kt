package com.dbtlab.callassistant.telecom

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import androidx.core.content.ContextCompat
import com.dbtlab.callassistant.R
import com.dbtlab.callassistant.data.AutoAnswerPreferencesStore
import com.dbtlab.callassistant.data.ContactsResolver
import com.dbtlab.callassistant.ui.IncomingCallActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DbtInCallService : InCallService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    companion object {
        private const val INCOMING_CHANNEL_ID = "dbt_lab_incoming_calls"
        private const val INCOMING_NOTIFICATION_ID = 4102

        private var activeService: DbtInCallService? = null
        private var currentCall: Call? = null
        private var autoAnswerJob: Job? = null

        private val _isServiceBound = MutableStateFlow(false)
        val isServiceBound: StateFlow<Boolean> = _isServiceBound.asStateFlow()

        private val _callUiState = MutableStateFlow(ActiveCallUiState())
        val callUiState: StateFlow<ActiveCallUiState> = _callUiState.asStateFlow()

        fun getCompatCallState(call: Call): Int {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                call.details.state
            } else {
                @Suppress("DEPRECATION")
                call.state
            }
        }

        fun answerIncomingCall() {
            cancelAutoAnswer(cancelledByUser = false)
            currentCall?.answer(VideoProfile.STATE_AUDIO_ONLY)
        }

        fun rejectOrDisconnectCall() {
            cancelAutoAnswer(cancelledByUser = true)
            val call = currentCall ?: return
            if (getCompatCallState(call) == Call.STATE_RINGING) {
                call.reject(false, null)
            } else {
                call.disconnect()
            }
        }

        fun cancelAutoAnswer(cancelledByUser: Boolean = true) {
            autoAnswerJob?.cancel()
            autoAnswerJob = null
            if (_callUiState.value.autoAnswerState.isCountingDown) {
                _callUiState.value = _callUiState.value.copy(
                    autoAnswerState = _callUiState.value.autoAnswerState.copy(
                        isCountingDown = false,
                        remainingSeconds = 0,
                        wasCancelledByUser = cancelledByUser,
                        statusMessageBn = if (cancelledByUser) {
                            "ব্যবহারকারী Auto Answer বন্ধ (Stop) করেছেন — কল স্বাভাবিকভাবে রিং হচ্ছে।"
                        } else {
                            ""
                        }
                    )
                )
            }
        }

        fun setSpeakerEnabled(enabled: Boolean) {
            val route = if (enabled) {
                CallAudioState.ROUTE_SPEAKER
            } else {
                CallAudioState.ROUTE_EARPIECE
            }
            @Suppress("DEPRECATION")
            activeService?.setAudioRoute(route)
            _callUiState.value = _callUiState.value.copy(isSpeakerOn = enabled)
        }

        fun setMutedEnabled(muted: Boolean) {
            activeService?.setMuted(muted)
            _callUiState.value = _callUiState.value.copy(isMuted = muted)
        }
    }

    private val callCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            if (state != Call.STATE_RINGING) {
                autoAnswerJob?.cancel()
                autoAnswerJob = null
                cancelIncomingCallNotification()
                if (_callUiState.value.autoAnswerState.isCountingDown) {
                    _callUiState.value = _callUiState.value.copy(
                        autoAnswerState = _callUiState.value.autoAnswerState.copy(
                            isCountingDown = false,
                            remainingSeconds = 0
                        )
                    )
                }
            }
            publishCallState(call, state)
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) {
            publishCallState(call, getCompatCallState(call))
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        activeService = this
        _isServiceBound.value = true
        return super.onBind(intent)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        _isServiceBound.value = false
        if (activeService === this) {
            activeService = null
        }
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        autoAnswerJob?.cancel()
        serviceScope.cancel()
        cancelIncomingCallNotification()
        _isServiceBound.value = false
        if (activeService === this) {
            activeService = null
        }
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        currentCall = call
        call.registerCallback(callCallback)

        val initialState = getCompatCallState(call)
        publishCallState(call, initialState)

        if (initialState == Call.STATE_RINGING) {
            evaluateAndScheduleAutoAnswer(call)
            val intent = Intent(this, IncomingCallActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            showIncomingCallNotification(intent)
            runCatching { startActivity(intent) }
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        autoAnswerJob?.cancel()
        autoAnswerJob = null
        cancelIncomingCallNotification()
        call.unregisterCallback(callCallback)
        if (currentCall === call) {
            currentCall = null
        }
        _callUiState.value = ActiveCallUiState(
            hasActiveCall = false,
            callState = DbtCallState.DISCONNECTED
        )
    }

    private fun evaluateAndScheduleAutoAnswer(call: Call) {
        autoAnswerJob?.cancel()

        val settings = AutoAnswerPreferencesStore.load(this)
        val rawNumber = call.details.handle?.schemeSpecificPart
        val simInfo = SimSubscriptionDetector.detectIncomingSim(this, call.details)

        // Extra telecom property guard for emergency calls
        val hasEmergencyProperty =
            call.details.hasProperty(Call.Details.PROPERTY_EMERGENCY_CALLBACK_MODE)
        if (hasEmergencyProperty || AutoAnswerGuard.isEmergencyNumber(this, rawNumber)) {
            _callUiState.value = _callUiState.value.copy(
                autoAnswerState = AutoAnswerRuntimeState(
                    isCountingDown = false,
                    statusMessageBn = "Emergency Call শনাক্ত — অটোমেটিক Answer কখনোই করা হবে না।"
                )
            )
            return
        }

        when (val check = AutoAnswerGuard.evaluateIncomingCall(this, settings, rawNumber, simInfo)) {
            is AutoAnswerEligibility.Blocked -> {
                _callUiState.value = _callUiState.value.copy(
                    autoAnswerState = AutoAnswerRuntimeState(
                        isCountingDown = false,
                        statusMessageBn = check.reasonBn
                    )
                )
            }
            is AutoAnswerEligibility.Eligible -> {
                autoAnswerJob = serviceScope.launch {
                    val total = settings.delay.seconds
                    for (sec in total downTo 1) {
                        if (getCompatCallState(call) != Call.STATE_RINGING) return@launch
                        _callUiState.value = _callUiState.value.copy(
                            autoAnswerState = AutoAnswerRuntimeState(
                                isCountingDown = true,
                                remainingSeconds = sec,
                                statusMessageBn = "${simInfo.carrierName} কল $sec সেকেন্ড পর Auto Answer হবে..."
                            )
                        )
                        delay(1000L)
                    }

                    if (getCompatCallState(call) == Call.STATE_RINGING) {
                        withContext(NonCancellable) {
                            val aiCap = AutoAnswerGuard.inspectAiVoiceCallIntegrationCapability(
                                this@DbtInCallService
                            )

                            // Honest AI capability check: DO NOT pretend AI speaks into the SIM call if unsupported
                            val postAnswerNote = if (aiCap.canInjectAiVoiceIntoSimCall) {
                                "কল Answer করা হয়েছে ও AI Voice Audio সক্রিয়।"
                            } else {
                                "কলটি অনুমোদিতভাবে Answer করা হয়েছে। SIM কল অডিওতে AI Voice ইনজেক্ট করা Unsupported — AI কথা বলছে এমন ভান করা হয়নি।"
                            }

                            _callUiState.value = _callUiState.value.copy(
                                autoAnswerState = AutoAnswerRuntimeState(
                                    isCountingDown = false,
                                    remainingSeconds = 0,
                                    autoAnsweredThisCall = true,
                                    statusMessageBn = postAnswerNote
                                )
                            )
                            call.answer(VideoProfile.STATE_AUDIO_ONLY)
                        }
                    }
                }
            }
        }
    }

    private fun showIncomingCallNotification(activityIntent: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val manager = getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(
            INCOMING_CHANNEL_ID,
            getString(R.string.incoming_call_channel_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        manager.createNotificationChannel(channel)

        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            1001,
            activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val state = _callUiState.value
        val title = state.callerName ?: state.callerNumber.ifBlank { "Incoming Call" }
        val text = state.simInfo?.statusNote ?: "DBT LAB AI Call Assistant"

        val notification = Notification.Builder(this, INCOMING_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .build()

        runCatching { manager.notify(INCOMING_NOTIFICATION_ID, notification) }
    }

    private fun cancelIncomingCallNotification() {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        runCatching { manager.cancel(INCOMING_NOTIFICATION_ID) }
    }

    private fun publishCallState(call: Call, rawState: Int) {
        val number = call.details.handle?.schemeSpecificPart ?: "অজানা নম্বর"
        val lookup = ContactsResolver.lookupCallerName(this, number)
        val simInfo = SimSubscriptionDetector.detectIncomingSim(this, call.details)
        val mappedState = mapTelecomState(rawState)

        val existingStart = _callUiState.value.callStartTimeMillis
        val startMillis = if (mappedState == DbtCallState.ACTIVE && existingStart == 0L) {
            System.currentTimeMillis()
        } else if (mappedState == DbtCallState.DISCONNECTED) {
            0L
        } else {
            existingStart
        }

        _callUiState.value = _callUiState.value.copy(
            hasActiveCall = mappedState != DbtCallState.DISCONNECTED,
            callerNumber = number,
            callerName = lookup.displayName ?: call.details.callerDisplayName,
            contactLookupStatus = lookup.statusNote,
            callState = mappedState,
            simInfo = simInfo,
            callStartTimeMillis = startMillis
        )
    }

    private fun mapTelecomState(state: Int): DbtCallState = when (state) {
        Call.STATE_RINGING -> DbtCallState.RINGING
        Call.STATE_DIALING -> DbtCallState.DIALING
        Call.STATE_CONNECTING -> DbtCallState.CONNECTING
        Call.STATE_ACTIVE -> DbtCallState.ACTIVE
        Call.STATE_HOLDING -> DbtCallState.HOLDING
        Call.STATE_DISCONNECTED -> DbtCallState.DISCONNECTED
        else -> DbtCallState.IDLE
    }
}
