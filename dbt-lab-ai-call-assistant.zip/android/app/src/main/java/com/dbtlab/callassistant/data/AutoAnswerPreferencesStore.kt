package com.dbtlab.callassistant.data

import android.content.Context
import com.dbtlab.callassistant.telecom.AutoAnswerDelay
import com.dbtlab.callassistant.telecom.AutoAnswerSettings

object AutoAnswerPreferencesStore {
    private const val PREFS_NAME = "dbt_lab_auto_answer_prefs"
    private const val KEY_ENABLED = "auto_answer_enabled"
    private const val KEY_DELAY_SECONDS = "auto_answer_delay_seconds"
    private const val KEY_JIO_ONLY = "auto_answer_jio_only"

    fun load(context: Context): AutoAnswerSettings {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean(KEY_ENABLED, false)
        val delaySec = prefs.getInt(KEY_DELAY_SECONDS, AutoAnswerDelay.FIVE_SECONDS.seconds)
        val jioOnly = prefs.getBoolean(KEY_JIO_ONLY, true)

        val delay = AutoAnswerDelay.entries.firstOrNull { it.seconds == delaySec }
            ?: AutoAnswerDelay.FIVE_SECONDS

        return AutoAnswerSettings(
            enabled = enabled,
            delay = delay,
            jioSimOnly = jioOnly
        )
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, enabled)
            .apply()
    }

    fun setDelay(context: Context, delay: AutoAnswerDelay) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_DELAY_SECONDS, delay.seconds)
            .apply()
    }

    fun setJioOnly(context: Context, jioOnly: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_JIO_ONLY, jioOnly)
            .apply()
    }
}
