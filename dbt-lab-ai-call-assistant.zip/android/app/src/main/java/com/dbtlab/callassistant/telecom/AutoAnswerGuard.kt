package com.dbtlab.callassistant.telecom

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.telecom.InCallService
import android.telephony.PhoneNumberUtils
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed class AutoAnswerEligibility {
    data class Eligible(val reasonBn: String) : AutoAnswerEligibility()
    data class Blocked(val reasonBn: String) : AutoAnswerEligibility()
}

data class AiCallAudioCapabilityReport(
    val canInjectAiVoiceIntoSimCall: Boolean,
    val statusTitleBn: String,
    val detailBn: String
)

data class AutoAnswerTestCheck(
    val nameBn: String,
    val passed: Boolean,
    val detailBn: String
)

object AutoAnswerGuard {

    private val knownEmergencyNumbers = setOf(
        "112", "911", "100", "101", "102", "108", "1091", "1098", "999", "1930"
    )

    fun isKnownEmergencyNumber(rawNumber: String?): Boolean {
        val cleaned = rawNumber.orEmpty().replace(Regex("[^0-9+]"), "")
        return cleaned.isNotBlank() && cleaned in knownEmergencyNumbers
    }

    fun isEmergencyNumber(context: Context, rawNumber: String?): Boolean {
        if (isKnownEmergencyNumber(rawNumber)) return true
        val cleaned = rawNumber.orEmpty().replace(Regex("[^0-9+]"), "")
        if (cleaned.isBlank()) return false

        val systemCheck = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val tm = context.getSystemService(TelephonyManager::class.java)
                tm?.isEmergencyNumber(cleaned) == true
            } else {
                @Suppress("DEPRECATION")
                PhoneNumberUtils.isEmergencyNumber(cleaned)
            }
        }.getOrDefault(false)

        return systemCheck
    }

    fun evaluateRules(
        settings: AutoAnswerSettings,
        isEmergency: Boolean,
        simCategory: IncomingSimCategory,
        carrierName: String,
        callerNumber: String?,
        isDefaultDialer: Boolean
    ): AutoAnswerEligibility {
        if (!settings.enabled) {
            return AutoAnswerEligibility.Blocked("Settings-এ Automatic Call Receive বন্ধ আছে।")
        }

        if (isEmergency) {
            return AutoAnswerEligibility.Blocked(
                "Emergency Call ($callerNumber) কখনোই অটোমেটিক Answer করা হয় না।"
            )
        }

        if (settings.jioSimOnly && simCategory != IncomingSimCategory.JIO_SIM) {
            return AutoAnswerEligibility.Blocked(
                "শুধু Jio SIM অপশন চালু আছে — অন্য SIM-এর কল স্বাভাবিকভাবে রিং হবে।"
            )
        }

        if (!isDefaultDialer) {
            return AutoAnswerEligibility.Blocked(
                "Auto Answer চালাতে অ্যাপটিকে Default Phone App (ROLE_DIALER) হতে হবে।"
            )
        }

        return AutoAnswerEligibility.Eligible(
            "$carrierName কল ${settings.delay.seconds} সেকেন্ড পর অটো-অ্যান্সার হবে।"
        )
    }

    fun evaluateIncomingCall(
        context: Context,
        settings: AutoAnswerSettings,
        callerNumber: String?,
        simInfo: SimCarrierInfo
    ): AutoAnswerEligibility {
        return evaluateRules(
            settings = settings,
            isEmergency = isEmergencyNumber(context, callerNumber),
            simCategory = simInfo.category,
            carrierName = simInfo.carrierName,
            callerNumber = callerNumber,
            isDefaultDialer = DialerRoleHelper.isDefaultDialer(context)
        )
    }

    fun isInCallServiceRegistered(context: Context): Boolean {
        val intent = Intent(InCallService.SERVICE_INTERFACE).apply {
            setPackage(context.packageName)
        }
        val services = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.packageManager.queryIntentServices(
                intent,
                PackageManager.ResolveInfoFlags.of(PackageManager.GET_META_DATA.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.queryIntentServices(intent, PackageManager.GET_META_DATA)
        }
        return services.any { resolveInfo ->
            val svc = resolveInfo.serviceInfo
            svc.packageName == context.packageName &&
                svc.permission == Manifest.permission.BIND_INCALL_SERVICE
        }
    }

    fun inspectAiVoiceCallIntegrationCapability(context: Context): AiCallAudioCapabilityReport {
        val hasMic = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        // Android Public InCallService API does NOT allow third-party apps to inject
        // synthesized TTS audio directly into the cellular PSTN uplink audio stream.
        return AiCallAudioCapabilityReport(
            canInjectAiVoiceIntoSimCall = PublicApiCapabilities.DIRECT_PSTN_UPLINK_AI_INJECTION,
            statusTitleBn = "AI Call Audio Integration: Unsupported (Android Public API)",
            detailBn = if (hasMic) {
                "সাধারণ SIM কলের অডিওতে সরাসরি AI Voice পাঠানো Android Public API দ্বারা অসম্ভব। Auto Answer শুধু কল রিসিভ করবে এবং AI কথা বলছে এমন ভান করবে না।"
            } else {
                "Android Public API দিয়ে SIM কলের অডিওতে AI Voice পাঠানো সম্ভব নয় (Unsupported) এবং RECORD_AUDIO অনুমতিও দেওয়া হয়নি।"
            }
        )
    }

    suspend fun runSelfVerificationTests(
        context: Context,
        currentSettings: AutoAnswerSettings
    ): List<AutoAnswerTestCheck> = coroutineScope {
        val checks = mutableListOf<AutoAnswerTestCheck>()

        // 1. Auto Answer OFF Behavior Check
        val offSettings = AutoAnswerSettings(
            enabled = false,
            delay = AutoAnswerDelay.FIVE_SECONDS,
            jioSimOnly = true
        )
        val offResult = evaluateRules(
            settings = offSettings,
            isEmergency = false,
            simCategory = IncomingSimCategory.JIO_SIM,
            carrierName = "Jio 4G",
            callerNumber = "+919876543210",
            isDefaultDialer = true
        )
        checks.add(
            AutoAnswerTestCheck(
                nameBn = "১. Auto Answer OFF পরীক্ষা",
                passed = offResult is AutoAnswerEligibility.Blocked,
                detailBn = when (offResult) {
                    is AutoAnswerEligibility.Blocked -> "সফল: OFF অবস্থায় কল অটো-রিসিভ হবে না (${offResult.reasonBn})"
                    is AutoAnswerEligibility.Eligible -> "ত্রুটি: OFF অবস্থায় অটো-রিসিভ অনুমোদিত হয়েছে!"
                }
            )
        )

        // 2. Auto Answer ON + 5s Delay + Coroutine Stop Cancellation Check
        val fiveSecSettings = AutoAnswerSettings(
            enabled = true,
            delay = AutoAnswerDelay.FIVE_SECONDS,
            jioSimOnly = true
        )
        val fiveSecEligibility = evaluateRules(
            settings = fiveSecSettings,
            isEmergency = false,
            simCategory = IncomingSimCategory.JIO_SIM,
            carrierName = "Jio 4G",
            callerNumber = "+919876543210",
            isDefaultDialer = true
        )
        var answeredDuringTest = false
        var stoppedCleanly = false
        val timerJob = launch {
            try {
                for (sec in fiveSecSettings.delay.seconds downTo 1) {
                    delay(50L)
                }
                answeredDuringTest = true
            } catch (_: CancellationException) {
                stoppedCleanly = true
            }
        }
        delay(80L)
        timerJob.cancel()
        timerJob.join()

        checks.add(
            AutoAnswerTestCheck(
                nameBn = "২. ৫ সেকেন্ড Delay ও Stop Auto Answer পরীক্ষা",
                passed = fiveSecEligibility is AutoAnswerEligibility.Eligible && stoppedCleanly && !answeredDuringTest,
                detailBn = "5s নিয়ম অনুমোদিত ও Stop চাপে কাউন্টডাউন বাতিল হয়েছে (নির্বাচিত সেটিং: ${currentSettings.delay.seconds}s)।"
            )
        )

        // 3. Emergency Number Block Check (must ALWAYS be blocked even if auto-answer is ON)
        val forcedOnSettings = AutoAnswerSettings(
            enabled = true,
            delay = currentSettings.delay,
            jioSimOnly = false
        )
        val jioSim = SimCarrierInfo("Jio 4G", 1, 1, true, IncomingSimCategory.JIO_SIM, "Unknown", "Jio SIM")
        val emergencyResult = evaluateIncomingCall(context, forcedOnSettings, "112", jioSim)
        checks.add(
            AutoAnswerTestCheck(
                nameBn = "৩. Emergency Call সুরক্ষা পরীক্ষা (112/911/100)",
                passed = emergencyResult is AutoAnswerEligibility.Blocked,
                detailBn = when (emergencyResult) {
                    is AutoAnswerEligibility.Blocked -> "সফল: ${emergencyResult.reasonBn}"
                    is AutoAnswerEligibility.Eligible -> "ত্রুটি: Emergency কল অনুমোদিত হয়েছে!"
                }
            )
        )

        // 4. Dual SIM Jio Detection + Other SIM Filter Check
        val simInventory = SimSubscriptionDetector.inspectDualSimSlots(context)
        val otherSim = SimCarrierInfo("Airtel", 2, 2, false, IncomingSimCategory.OTHER_SIM, "Unknown", "Airtel")
        val jioOnlySettings = AutoAnswerSettings(enabled = true, delay = currentSettings.delay, jioSimOnly = true)
        val otherSimResult = evaluateIncomingCall(context, jioOnlySettings, "+919876543210", otherSim)
        checks.add(
            AutoAnswerTestCheck(
                nameBn = "৪. Dual SIM ও শুধু Jio SIM ফিল্টার পরীক্ষা",
                passed = otherSimResult is AutoAnswerEligibility.Blocked,
                detailBn = "${simInventory.summaryNote} Other SIM স্বাভাবিকভাবে রিং হবে।"
            )
        )

        // 5. InCallService Manifest Registration + Default Dialer (ROLE_DIALER) + Permissions
        val serviceRegistered = isInCallServiceRegistered(context)
        val isDefaultDialer = DialerRoleHelper.isDefaultDialer(context)
        val hasPhoneState = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED
        val hasAnswerCalls = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ANSWER_PHONE_CALLS
        ) == PackageManager.PERMISSION_GRANTED
        checks.add(
            AutoAnswerTestCheck(
                nameBn = "৫. InCallService নিবন্ধন, ROLE_DIALER ও অনুমতি পরীক্ষা",
                passed = serviceRegistered && isDefaultDialer && hasPhoneState && hasAnswerCalls,
                detailBn = "InCallService Manifest: ${if (serviceRegistered) "Registered" else "Missing"} · ROLE_DIALER: ${if (isDefaultDialer) "Active" else "Not Default"} · PHONE_STATE: ${if (hasPhoneState) "OK" else "Denied"} · ANSWER_CALLS: ${if (hasAnswerCalls) "OK" else "Denied"}"
            )
        )

        // 6. Real AI Voice Audio Integration Capability Check (No Fake AI Speech)
        val aiCap = inspectAiVoiceCallIntegrationCapability(context)
        checks.add(
            AutoAnswerTestCheck(
                nameBn = "৬. AI Call Audio Integration সক্ষমতা যাচাই",
                passed = !aiCap.canInjectAiVoiceIntoSimCall,
                detailBn = aiCap.detailBn
            )
        )

        checks
    }
}
