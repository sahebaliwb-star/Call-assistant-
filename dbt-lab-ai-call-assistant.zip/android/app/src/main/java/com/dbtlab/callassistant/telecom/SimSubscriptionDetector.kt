package com.dbtlab.callassistant.telecom

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telecom.Call
import android.telecom.TelecomManager
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

data class DualSimInventoryResult(
    val sim1: SimSlotInfo,
    val sim2: SimSlotInfo,
    val permissionGranted: Boolean,
    val summaryNote: String
)

object SimSubscriptionDetector {

    @SuppressLint("MissingPermission")
    fun inspectDualSimSlots(context: Context): DualSimInventoryResult {
        val hasPhoneState = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPhoneState) {
            return DualSimInventoryResult(
                sim1 = SimSlotInfo(
                    slotNumber = 1,
                    subscriptionId = null,
                    operatorName = "Unknown",
                    simStatus = "READ_PHONE_STATE অনুমতি প্রয়োজন",
                    phoneNumber = "Unknown",
                    isJioSim = false,
                    isActive = false
                ),
                sim2 = SimSlotInfo(
                    slotNumber = 2,
                    subscriptionId = null,
                    operatorName = "Unknown",
                    simStatus = "READ_PHONE_STATE অনুমতি প্রয়োজন",
                    phoneNumber = "Unknown",
                    isJioSim = false,
                    isActive = false
                ),
                permissionGranted = false,
                summaryNote = "SIM 1 ও SIM 2 শনাক্ত করতে READ_PHONE_STATE অনুমতি দিন।"
            )
        }

        val subManager = context.getSystemService(SubscriptionManager::class.java)
        val activeSubs = runCatching {
            subManager?.activeSubscriptionInfoList.orEmpty()
        }.getOrDefault(emptyList())

        val sim1Sub = activeSubs.firstOrNull { it.simSlotIndex == 0 }
        val sim2Sub = activeSubs.firstOrNull { it.simSlotIndex == 1 }

        val sim1 = buildSlotInfo(context, subManager, slotNumber = 1, sub = sim1Sub)
        val sim2 = buildSlotInfo(context, subManager, slotNumber = 2, sub = sim2Sub)

        val jioSlot = listOf(sim1, sim2).firstOrNull { it.isJioSim }?.slotNumber
        val summary = when {
            activeSubs.isEmpty() -> "কোনো সক্রিয় SIM পাওয়া যায়নি।"
            jioSlot != null -> "মোট ${activeSubs.size} টি সক্রিয় SIM শনাক্ত হয়েছে (Jio SIM: Slot $jioSlot)।"
            else -> "মোট ${activeSubs.size} টি সক্রিয় SIM শনাক্ত হয়েছে।"
        }

        return DualSimInventoryResult(
            sim1 = sim1,
            sim2 = sim2,
            permissionGranted = true,
            summaryNote = summary
        )
    }

    @SuppressLint("MissingPermission")
    private fun buildSlotInfo(
        context: Context,
        subManager: SubscriptionManager?,
        slotNumber: Int,
        sub: SubscriptionInfo?
    ): SimSlotInfo {
        if (sub == null) {
            return SimSlotInfo(
                slotNumber = slotNumber,
                subscriptionId = null,
                operatorName = "কোনো SIM নেই",
                simStatus = "Empty / Inactive",
                phoneNumber = "Unknown",
                isJioSim = false,
                isActive = false
            )
        }

        val operatorName = sub.carrierName?.toString()?.takeIf { it.isNotBlank() }
            ?: sub.displayName?.toString()?.takeIf { it.isNotBlank() }
            ?: "Unknown Operator"
        val isJio = isJioCarrier(operatorName, sub)
        val number = resolveSafePhoneNumber(context, subManager, sub)

        return SimSlotInfo(
            slotNumber = slotNumber,
            subscriptionId = sub.subscriptionId,
            operatorName = operatorName,
            simStatus = if (isJio) "Active · Jio SIM" else "Active",
            phoneNumber = number,
            isJioSim = isJio,
            isActive = true
        )
    }

    @SuppressLint("MissingPermission")
    private fun resolveSafePhoneNumber(
        context: Context,
        subManager: SubscriptionManager?,
        sub: SubscriptionInfo
    ): String {
        val hasPhoneNumbers = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_PHONE_NUMBERS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPhoneNumbers) {
            return "Unknown"
        }

        val rawNumber = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            runCatching { subManager?.getPhoneNumber(sub.subscriptionId) }.getOrNull()
        } else {
            @Suppress("DEPRECATION")
            sub.number
        }

        return rawNumber?.trim()?.takeIf { it.isNotBlank() } ?: "Unknown"
    }

    @SuppressLint("MissingPermission")
    fun detectIncomingSim(context: Context, callDetails: Call.Details?): SimCarrierInfo {
        val hasPhoneState = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPhoneState) {
            return SimCarrierInfo(
                carrierName = "Unknown SIM",
                simSlotIndex = null,
                subscriptionId = null,
                isJioSim = false,
                category = IncomingSimCategory.UNKNOWN_SIM,
                phoneNumber = "Unknown",
                statusNote = "SIM তথ্য জানতে READ_PHONE_STATE অনুমতি প্রয়োজন"
            )
        }

        val telecomManager = context.getSystemService(TelecomManager::class.java)
        val subscriptionManager = context.getSystemService(SubscriptionManager::class.java)
        val telephonyManager = context.getSystemService(TelephonyManager::class.java)
        val accountHandle = callDetails?.accountHandle

        var resolvedLabel: String? = null
        var exactSubId: Int? = null
        if (accountHandle != null) {
            val phoneAccount = runCatching { telecomManager?.getPhoneAccount(accountHandle) }.getOrNull()
            resolvedLabel = phoneAccount?.label?.toString()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val subId = runCatching {
                    telephonyManager?.getSubscriptionId(accountHandle)
                }.getOrNull()
                if (subId != null && subId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
                    exactSubId = subId
                }
            }
        }

        val activeSubs = runCatching {
            subscriptionManager?.activeSubscriptionInfoList.orEmpty()
        }.getOrDefault(emptyList())

        val handleId = accountHandle?.id.orEmpty()
        val matchedSub: SubscriptionInfo? =
            (exactSubId?.let { id -> activeSubs.firstOrNull { it.subscriptionId == id } })
                ?: activeSubs.firstOrNull { sub ->
                    handleId == sub.subscriptionId.toString() ||
                        handleId.contains(sub.subscriptionId.toString()) ||
                        (!resolvedLabel.isNullOrBlank() &&
                            sub.carrierName?.toString()?.contains(resolvedLabel, ignoreCase = true) == true)
                }
                ?: if (activeSubs.size == 1) activeSubs.first() else null

        val carrierName = matchedSub?.carrierName?.toString()
            ?: resolvedLabel
            ?: "Unknown Operator"
        val isJio = isJioCarrier(carrierName, matchedSub)
        val slotNumber = matchedSub?.simSlotIndex?.plus(1)
        val simNumber = matchedSub?.let { resolveSafePhoneNumber(context, subscriptionManager, it) } ?: "Unknown"

        val category = when {
            isJio -> IncomingSimCategory.JIO_SIM
            matchedSub != null || !resolvedLabel.isNullOrBlank() -> IncomingSimCategory.OTHER_SIM
            else -> IncomingSimCategory.UNKNOWN_SIM
        }

        val statusNote = when {
            isJio && slotNumber != null -> "Jio SIM Incoming (SIM $slotNumber)"
            isJio -> "Jio SIM Incoming"
            slotNumber != null -> "$carrierName (SIM $slotNumber)"
            else -> "SIM: $carrierName"
        }

        return SimCarrierInfo(
            carrierName = carrierName,
            simSlotIndex = slotNumber,
            subscriptionId = matchedSub?.subscriptionId ?: exactSubId,
            isJioSim = isJio,
            category = category,
            phoneNumber = simNumber,
            statusNote = statusNote
        )
    }

    private fun isJioCarrier(name: String, sub: SubscriptionInfo?): Boolean {
        if (name.contains("jio", ignoreCase = true) || name.contains("reliance", ignoreCase = true)) {
            return true
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && sub != null) {
            if (sub.mccString == "405") {
                val mncInt = sub.mncString?.toIntOrNull()
                if (mncInt != null && (mncInt == 840 || mncInt in 854..874)) {
                    return true
                }
            }
        }
        return false
    }
}
