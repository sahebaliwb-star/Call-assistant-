package com.dbtlab.callassistant.permissions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

data class AndroidPermissionItem(
    val permission: String,
    val titleBn: String,
    val granted: Boolean
)

object PermissionManager {

    fun requiredRuntimePermissions(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            list.add(Manifest.permission.READ_PHONE_NUMBERS)
        }
        return list.toTypedArray()
    }

    fun inspectPermissions(context: Context): List<AndroidPermissionItem> {
        return requiredRuntimePermissions().map { perm ->
            val label = when (perm) {
                Manifest.permission.RECORD_AUDIO -> "মাইক্রোফোন (Voice Input)"
                Manifest.permission.READ_PHONE_STATE -> "SIM ও কলের অবস্থা (Jio SIM Detection)"
                Manifest.permission.READ_CONTACTS -> "কন্টাক্টস (কলারের নাম)"
                Manifest.permission.READ_CALL_LOG -> "কল হিস্ট্রি"
                Manifest.permission.CALL_PHONE -> "কল ডায়াল"
                Manifest.permission.ANSWER_PHONE_CALLS -> "কল রিসিভ"
                Manifest.permission.POST_NOTIFICATIONS -> "কল নোটিফিকেশন"
                Manifest.permission.READ_PHONE_NUMBERS -> "ফোন নম্বর পঠন"
                else -> perm
            }
            AndroidPermissionItem(
                permission = perm,
                titleBn = label,
                granted = ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
            )
        }
    }
}
