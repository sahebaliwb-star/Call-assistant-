package com.dbtlab.callassistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object DbtColors {
    val CanvasBlackNavy = Color(0xFF040711)
    val SurfaceNavy = Color(0xFF091022)
    val ElevatedNavy = Color(0xFF0E1833)
    val BorderSlate = Color(0xFF1E293B)
    val AccentBlue = Color(0xFF2563EB)
    val AccentSky = Color(0xFF38BDF8)
    val AnswerGreen = Color(0xFF16A34A)
    val RejectRed = Color(0xFFDC2626)
    val WarningAmber = Color(0xFFF59E0B)
    val TextPrimary = Color(0xFFF1F5F9)
    val TextSecondary = Color(0xFF94A3B8)
}

private val DbtDarkScheme = darkColorScheme(
    primary = DbtColors.AccentBlue,
    secondary = DbtColors.AccentSky,
    background = DbtColors.CanvasBlackNavy,
    surface = DbtColors.SurfaceNavy,
    onPrimary = Color.White,
    onBackground = DbtColors.TextPrimary,
    onSurface = DbtColors.TextPrimary
)

@Composable
fun DbtLabTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DbtDarkScheme,
        content = content
    )
}
