package com.dbtlab.callassistant.ui

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.dbtlab.callassistant.BuildConfig
import com.dbtlab.callassistant.telecom.DbtCallState
import com.dbtlab.callassistant.telecom.DbtInCallService
import com.dbtlab.callassistant.voice.BengaliVoiceAssistantEngine
import kotlinx.coroutines.launch

class IncomingCallActivity : ComponentActivity() {

    private lateinit var voiceEngine: BengaliVoiceAssistantEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }

        // Uses BACKEND_BASE_URL from BuildConfig (Gemini API key stays strictly on server)
        voiceEngine = BengaliVoiceAssistantEngine(
            context = this,
            backendBaseUrl = BuildConfig.BACKEND_BASE_URL
        )

        setContent {
            DbtLabTheme {
                val uiState by DbtInCallService.callUiState.collectAsState()
                val scope = rememberCoroutineScope()

                var aiPanelOpen by remember { mutableStateOf(false) }
                var aiListening by remember { mutableStateOf(false) }
                var aiReply by remember { mutableStateOf<String?>(null) }

                LaunchedEffect(uiState.callState) {
                    if (uiState.callState == DbtCallState.DISCONNECTED) {
                        finish()
                    }
                }

                IncomingCallScreen(
                    uiState = uiState,
                    aiAssistantReply = aiReply,
                    aiListening = aiListening,
                    aiPanelOpen = aiPanelOpen,
                    onAnswerCall = { DbtInCallService.answerIncomingCall() },
                    onRejectOrEndCall = { DbtInCallService.rejectOrDisconnectCall() },
                    onStopAutoAnswer = { DbtInCallService.cancelAutoAnswer(cancelledByUser = true) },
                    onToggleSpeaker = { enabled -> DbtInCallService.setSpeakerEnabled(enabled) },
                    onToggleMute = { muted -> DbtInCallService.setMutedEnabled(muted) },
                    onToggleAiAssistant = {
                        aiPanelOpen = !aiPanelOpen
                        if (aiPanelOpen) {
                            val intro = "নমস্কার, আমি ডিবিটি ল্যাব এআই কল অ্যাসিস্ট্যান্ট। " +
                                "আপনার ইনকামিং কলটি ${uiState.callerName ?: uiState.callerNumber} থেকে এসেছে।"
                            aiReply = intro
                            voiceEngine.speakBengali(intro)
                        } else {
                            voiceEngine.stopSpeaking()
                        }
                    },
                    onAskAiByVoice = {
                        aiListening = true
                        voiceEngine.startListening(
                            onTranscript = { spokenText ->
                                aiListening = false
                                scope.launch {
                                    val contextInfo =
                                        "Incoming call from ${uiState.callerName ?: "Unknown"} (${uiState.callerNumber}), SIM: ${uiState.simInfo?.carrierName ?: "Unknown"}"
                                    val result = voiceEngine.askAssistantViaServer(spokenText, contextInfo)
                                    val replyText = result.getOrElse { err ->
                                        "AI সার্ভার সংযোগ ত্রুটি: ${err.localizedMessage}"
                                    }
                                    aiReply = replyText
                                    voiceEngine.speakBengali(replyText)
                                }
                            },
                            onError = { errMsg ->
                                aiListening = false
                                aiReply = errMsg
                            }
                        )
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        voiceEngine.release()
        super.onDestroy()
    }
}
