package com.dbtlab.callassistant.data

import android.content.Context
import com.dbtlab.callassistant.telecom.PreferredSimOption

object SimPreferencesStore {
    private const val PREFS_NAME = "dbt_lab_sim_preferences"
    private const val KEY_PREFERRED_SIM = "preferred_sim_option"

    fun getPreferredSim(context: Context): PreferredSimOption {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_PREFERRED_SIM, PreferredSimOption.ASK_EVERY_TIME.name)
        return runCatching {
            PreferredSimOption.valueOf(raw ?: PreferredSimOption.ASK_EVERY_TIME.name)
        }.getOrDefault(PreferredSimOption.ASK_EVERY_TIME)
    }

    fun setPreferredSim(context: Context, option: PreferredSimOption) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PREFERRED_SIM, option.name)
            .apply()
    }
}
