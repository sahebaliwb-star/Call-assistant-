# DBT LAB AI Call Assistant — Native Android Project

## Build & Run Requirements
- **Android Studio**: Ladybug (2024.2+) or newer
- **JDK**: Java 17 (Android Studio bundled JBR 17 works automatically)
- **Android SDK**: `compileSdk = 35`, `targetSdk = 35`, `minSdk = 26`

## APK Build করার ধাপ (Steps to Build APK)
1. **Android Studio-তে Open করুন**:
   - Export করা ZIP Extract করে এই `android/` ফোল্ডারটি Android Studio দিয়ে Open করুন।
   - Android Studio স্বয়ংক্রিয়ভাবে `gradle/wrapper/gradle-wrapper.properties` ব্যবহার করে Gradle 8.9 ও ডিপেন্ডেন্সি Sync করবে।
2. **Backend URL কনফিগার করুন** (ঐচ্ছিক, AI Voice Assistant-এর জন্য):
   - `app/build.gradle.kts`-এ `BACKEND_BASE_URL` আপনার হোস্টেড সার্ভার URL-এ সেট করুন (কোনো Gemini API Key APK-তে রাখবেন না)।
3. **Unit Test চালান**:
   ```bash
   ./gradlew testDebugUnitTest
   ```
4. **Debug APK Build করুন**:
   - Android Studio মেনু: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
   - অথবা Terminal-এ:
     ```bash
     ./gradlew assembleDebug
     ```
   - তৈরি হওয়া APK পাওয়া যাবে: `app/build/outputs/apk/debug/app-debug.apk`
5. **Release Signed APK Build করুন**:
   - **Build > Generate Signed Bundle / APK > APK** -> Keystore নির্বাচন করে Build করুন।
6. **ফোনে পরীক্ষা করুন**:
   - APK ইনস্টল করার পর **Default Phone App সেট করুন** বাটনে চাপ দিয়ে `ROLE_DIALER` অনুমোদন দিন এবং সব Runtime অনুমতি দিন।
