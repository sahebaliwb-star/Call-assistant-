import "dotenv/config";
import express from "express";
import type { Request, Response } from "express";
import fs from "fs";
import path from "path";
import zlib from "zlib";
import { fileURLToPath } from "url";
import { GoogleGenAI, ThinkingLevel, Type } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

function parseGeminiError(err: unknown): { status: number; message: string } {
  const raw = err instanceof Error ? err.message : String(err);
  try {
    const parsed = JSON.parse(raw) as { error?: { code?: number; message?: string; status?: string } };
    if (parsed?.error) {
      return {
        status: parsed.error.code || 500,
        message: parsed.error.message || raw,
      };
    }
  } catch {
    // not JSON
  }
  if (raw.includes("429") || raw.includes("RESOURCE_EXHAUSTED")) {
    return { status: 429, message: "API quota exceeded. Please check billing/quota in Settings > Secrets." };
  }
  if (raw.includes("503") || raw.includes("UNAVAILABLE")) {
    return { status: 503, message: "Gemini model is temporarily busy (503). Please try again shortly." };
  }
  return { status: 500, message: raw || "Unknown server error" };
}

async function generateChatWithRetry(
  ai: GoogleGenAI,
  contents: string,
  config: Parameters<typeof ai.models.generateContent>[0]["config"]
) {
  const attempts: Array<{ model: string; thinkingLevel: ThinkingLevel }> = [
    { model: "gemini-4-hydrogen", thinkingLevel: ThinkingLevel.LOW },
    { model: "gemini-3.1-flash-lite", thinkingLevel: ThinkingLevel.MINIMAL },
  ];
  let lastErr: unknown;
  for (let i = 0; i < attempts.length; i++) {
    try {
      return await ai.models.generateContent({
        model: attempts[i].model,
        contents,
        config: {
          ...config,
          thinkingConfig: { thinkingLevel: attempts[i].thinkingLevel },
        },
      });
    } catch (err) {
      lastErr = err;
      const parsed = parseGeminiError(err);
      if ((parsed.status === 503 || parsed.status === 429) && i < attempts.length - 1) {
        await new Promise((r) => setTimeout(r, 400));
        continue;
      }
      throw err;
    }
  }
  throw lastErr;
}

async function createServer() {
  const app = express();
  app.use(express.json({ limit: "15mb" }));

  // Health & API readiness endpoint (never exposes API keys)
  app.get("/api/health", (_req: Request, res: Response) => {
    const hasKey = Boolean(
      process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY"
    );
    res.json({
      status: "ok",
      appName: "DBT LAB AI Call Assistant",
      geminiConfigured: hasKey,
      environment: isProduction ? "production" : "development",
    });
  });

  // Conversational AI Voice Assistant & Voice Command Parser
  app.post("/api/chat", async (req: Request, res: Response) => {
    const ai = getAiClient();
    if (!ai) {
      res.status(503).json({
        error: "GEMINI_API_KEY is not configured. Please add it in Settings > Secrets.",
      });
      return;
    }

    try {
      const { message, history = [], userName = "User", preferredLanguage = "bn", voicePersona = "Ananya" } = req.body as {
        message?: string;
        history?: Array<{ role: "user" | "assistant"; text: string }>;
        userName?: string;
        preferredLanguage?: "bn" | "en" | "bilingual";
        voicePersona?: string;
      };

      if (!message || !message.trim()) {
        res.status(400).json({ error: "Message is required." });
        return;
      }

      const conversationContext = history
        .slice(-14)
        .map((h) => `${h.role === "user" ? "User" : "Assistant"}: ${h.text}`)
        .join("\n");

      const systemInstruction = `You are "DBT LAB AI Call Assistant" (persona: ${voicePersona}), a polite, intelligent, warm Bengali female AI Voice Call Assistant speaking to ${userName}.
Language rules:
- You understand both Bengali (বাংলা) and English fluently, including Banglish.
- Preferred language mode: ${preferredLanguage}. If the user writes or speaks in Bengali or Banglish, reply naturally in clear, polite Bengali feminine phrasing (e.g. "আমি আপনাকে সাহায্য করছি", "অনুমতি পেলে আমি কলটি শুরু করব"). If the user speaks purely in English, reply in crisp, helpful English unless bn-only is requested.
- Keep spoken replies concise (1 to 3 sentences) so they sound natural when read aloud via Text-to-Speech.
- Detect voice commands carefully:
  - If the user asks to call someone (e.g., "রহিমকে কল করো", "Call Mom", "Dial 01712345678"), set commandType="MAKE_CALL", extract targetName and/or targetNumber, and NEVER claim the call has already started—explicitly state that user permission/confirmation is required first.
  - If the user asks to test or simulate incoming call screening, set commandType="SCREEN_CALL".
  - If the user asks to view call logs/history, set commandType="OPEN_HISTORY".
  - If the user asks to open settings, voice selection, or permissions, set commandType="OPEN_SETTINGS".
  - Otherwise set commandType="NONE".`;

      const prompt = conversationContext
        ? `Previous conversation:\n${conversationContext}\n\nLatest user message: ${message}`
        : message;

      const response = await generateChatWithRetry(ai, prompt, {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            replyText: { type: Type.STRING, description: "Natural spoken reply in Bengali or English." },
            language: { type: Type.STRING, description: "Primary language of reply: bn or en." },
            commandType: {
              type: Type.STRING,
              description: "One of: NONE, MAKE_CALL, SCREEN_CALL, OPEN_HISTORY, OPEN_SETTINGS",
            },
            targetName: { type: Type.STRING, description: "Contact name if MAKE_CALL, else empty string." },
            targetNumber: { type: Type.STRING, description: "Phone number if provided, else empty string." },
            suggestedFollowUps: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Up to 2 short follow-up suggestions.",
            },
          },
          required: ["replyText", "language", "commandType", "targetName", "targetNumber", "suggestedFollowUps"],
        },
      });

      const parsed = JSON.parse((response.text ?? "{}").trim());
      res.json(parsed);
    } catch (err) {
      console.error("Chat API error:", err);
      const parsed = parseGeminiError(err);
      res.status(parsed.status).json({ error: parsed.message });
    }
  });

  // Bengali Female Text-to-Speech via Gemini 3.8 TTS
  app.post("/api/tts", async (req: Request, res: Response) => {
    const ai = getAiClient();
    if (!ai) {
      res.status(503).json({
        error: "GEMINI_API_KEY is not configured. Please add it in Settings > Secrets.",
      });
      return;
    }

    try {
      const { text, voiceName = "Kore", style = "Warm, natural, polite Bengali female voice assistant" } = req.body as {
        text?: string;
        voiceName?: string;
        style?: string;
      };

      if (!text || !text.trim()) {
        res.status(400).json({ error: "Text is required for speech synthesis." });
        return;
      }

      const allowedVoices = new Set(["Kore", "Zephyr", "Puck", "Charon", "Fenrir"]);
      const selectedVoice = allowedVoices.has(voiceName) ? voiceName : "Kore";

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash-lite-tts",
        contents: [
          {
            role: "user",
            parts: [
              {
                text: text.slice(0, 1200),
                speechMetadata: {
                  style,
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ["AUDIO"],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName: selectedVoice,
              },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) {
        res.status(502).json({ error: "TTS model returned no audio output." });
        return;
      }

      res.json({
        audioBase64: base64Audio,
        mimeType: "audio/wav",
      });
    } catch (err) {
      console.error("TTS API error:", err);
      const parsed = parseGeminiError(err);
      res.status(parsed.status).json({ error: parsed.message });
    }
  });

  // Audio Transcription (Bengali & English) via Gemini 3.5 Transcribe
  app.post("/api/transcribe", async (req: Request, res: Response) => {
    const ai = getAiClient();
    if (!ai) {
      res.status(503).json({
        error: "GEMINI_API_KEY is not configured. Please add it in Settings > Secrets.",
      });
      return;
    }

    try {
      const { audioBase64, mimeType = "audio/webm" } = req.body as {
        audioBase64?: string;
        mimeType?: string;
      };

      if (!audioBase64) {
        res.status(400).json({ error: "Audio payload is required." });
        return;
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.5-transcribe",
        contents: {
          parts: [
            {
              inlineData: {
                mimeType,
                data: audioBase64,
              },
            },
            {
              text: "Transcribe this audio accurately. The speaker may use Bengali (বাংলা script), English, or mixed Bengali-English. Output only the exact spoken transcription with no extra commentary.",
            },
          ],
        },
      });

      res.json({ text: (response.text ?? "").trim() });
    } catch (err) {
      console.error("Transcribe API error:", err);
      const parsed = parseGeminiError(err);
      res.status(parsed.status).json({ error: parsed.message });
    }
  });

  // Incoming Call Screening Dialogue Handler
  app.post("/api/call-screen", async (req: Request, res: Response) => {
    const ai = getAiClient();
    if (!ai) {
      res.status(503).json({
        error: "GEMINI_API_KEY is not configured. Please add it in Settings > Secrets.",
      });
      return;
    }

    try {
      const {
        callerName,
        callerNumber,
        callerUtterance,
        transcript = [],
        userName = "User",
        customGreetingBn = "",
      } = req.body as {
        callerName?: string;
        callerNumber?: string;
        callerUtterance?: string;
        transcript?: Array<{ speaker: string; text: string }>;
        userName?: string;
        customGreetingBn?: string;
      };

      const historyBlock = transcript
        .map((t) => `${t.speaker}: ${t.text}`)
        .join("\n");

      const systemInstruction = `You are DBT LAB AI Call Assistant, acting as an authorized incoming call screener for ${userName}.
Rules:
1. Always clearly introduce yourself as "DBT LAB AI Call Assistant" when starting or clarifying your role.
2. Speak politely as a Bengali female assistant in Bengali (or switch to English if the caller speaks English).
3. If a custom greeting is provided ("${customGreetingBn}"), respect its tone.
4. Ask for the caller's name, purpose of the call, and urgency concisely.
5. Detect spam, marketing, urgent delivery, bank/OTP, medical, or personal calls.
6. Set shouldEndCall=true once you have gathered enough details and politely told the caller you will pass the summary to ${userName}.`;

      const prompt = transcript.length === 0 && !callerUtterance
        ? `An incoming call from ${callerName || "Unknown Caller"} (${callerNumber || "Hidden"}) was just approved for AI screening. Generate your opening Bengali introduction greeting.`
        : `Incoming Call from ${callerName || "Unknown"} (${callerNumber || ""}).\nTranscript so far:\n${historyBlock}\n\nLatest caller message: ${callerUtterance}`;

      const response = await generateChatWithRetry(ai, prompt, {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            assistantReply: { type: Type.STRING },
            shouldEndCall: { type: Type.BOOLEAN },
            callerIntent: { type: Type.STRING },
            urgency: { type: Type.STRING, description: "Low, Normal, High, or Spam" },
            suggestedAction: { type: Type.STRING },
          },
          required: ["assistantReply", "shouldEndCall", "callerIntent", "urgency", "suggestedAction"],
        },
      });

      const parsed = JSON.parse((response.text ?? "{}").trim());
      res.json(parsed);
    } catch (err) {
      console.error("Call Screen API error:", err);
      const parsed = parseGeminiError(err);
      res.status(parsed.status).json({ error: parsed.message });
    }
  });

  // Post-Call Summary Generator
  app.post("/api/call-summary", async (req: Request, res: Response) => {
    const ai = getAiClient();
    if (!ai) {
      res.status(503).json({
        error: "GEMINI_API_KEY is not configured. Please add it in Settings > Secrets.",
      });
      return;
    }

    try {
      const { callerName, callerNumber, transcript = [] } = req.body as {
        callerName?: string;
        callerNumber?: string;
        transcript?: Array<{ speaker: string; text: string }>;
      };

      const formatted = transcript.map((t) => `${t.speaker}: ${t.text}`).join("\n");

      const response = await generateChatWithRetry(
        ai,
        `Summarize this call handled by DBT LAB AI Call Assistant.\nCaller: ${callerName || "Unknown"} (${callerNumber || ""})\nTranscript:\n${formatted}`,
        {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summaryBn: { type: Type.STRING, description: "Concise 1-2 sentence summary in Bengali." },
              summaryEn: { type: Type.STRING, description: "Concise 1-2 sentence summary in English." },
              category: { type: Type.STRING, description: "e.g., Delivery, Personal, Work, Bank, Potential Spam" },
              actionItems: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              urgency: { type: Type.STRING },
            },
            required: ["summaryBn", "summaryEn", "category", "actionItems", "urgency"],
          },
        }
      );

      const parsed = JSON.parse((response.text ?? "{}").trim());
      res.json(parsed);
    } catch (err) {
      console.error("Call Summary API error:", err);
      const parsed = parseGeminiError(err);
      res.status(parsed.status).json({ error: parsed.message });
    }
  });

  // Outgoing Call Live Co-Pilot Suggestions
  app.post("/api/outgoing-copilot", async (req: Request, res: Response) => {
    const ai = getAiClient();
    if (!ai) {
      res.status(503).json({
        error: "GEMINI_API_KEY is not configured. Please add it in Settings > Secrets.",
      });
      return;
    }

    try {
      const { contactName, callTopic, contextNote } = req.body as {
        contactName?: string;
        callTopic?: string;
        contextNote?: string;
      };

      const response = await generateChatWithRetry(
        ai,
        `User is on an approved outgoing call with ${contactName || "recipient"}. Topic: ${callTopic || "General conversation"}. Context: ${contextNote || "None"}. Provide 3 concise Bengali/English talking points or polite phrasing suggestions the user can say right now.`,
        {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              suggestions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    label: { type: Type.STRING },
                    phraseBn: { type: Type.STRING },
                    phraseEn: { type: Type.STRING },
                  },
                  required: ["label", "phraseBn", "phraseEn"],
                },
              },
            },
            required: ["suggestions"],
          },
        }
      );

      const parsed = JSON.parse((response.text ?? "{}").trim());
      res.json(parsed);
    } catch (err) {
      console.error("Outgoing Copilot error:", err);
      const parsed = parseGeminiError(err);
      res.status(parsed.status).json({ error: parsed.message });
    }
  });

  // Export complete Native Android Studio Project as a standard .ZIP archive
  app.get("/api/export-android-project", (_req: Request, res: Response) => {
    try {
      const androidRoot = path.resolve(__dirname, "android");
      if (!fs.existsSync(androidRoot)) {
        res.status(404).json({ error: "Android project directory not found." });
        return;
      }

      const skipDirs = new Set(["build", ".gradle", ".idea", ".cxx"]);
      const files: Array<{ archivePath: string; data: Buffer }> = [];

      const walk = (dir: string, relPrefix: string) => {
        const entries = fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) =>
          a.name.localeCompare(b.name)
        );
        for (const entry of entries) {
          if (skipDirs.has(entry.name) || entry.name === "local.properties") continue;
          const fullPath = path.join(dir, entry.name);
          const relPath = relPrefix ? `${relPrefix}/${entry.name}` : entry.name;
          if (entry.isDirectory()) {
            walk(fullPath, relPath);
          } else if (entry.isFile()) {
            files.push({
              archivePath: `DbtLabAiCallAssistant-Android/${relPath}`,
              data: fs.readFileSync(fullPath),
            });
          }
        }
      };

      walk(androidRoot, "");

      const localParts: Buffer[] = [];
      const centralParts: Buffer[] = [];
      let offset = 0;

      for (const file of files) {
        const nameBuf = Buffer.from(file.archivePath, "utf8");
        const crc = zlib.crc32(file.data) >>> 0;
        const compressed = zlib.deflateRawSync(file.data);

        const localHeader = Buffer.alloc(30);
        localHeader.writeUInt32LE(0x04034b50, 0);
        localHeader.writeUInt16LE(20, 4);
        localHeader.writeUInt16LE(0x0800, 6);
        localHeader.writeUInt16LE(8, 8);
        localHeader.writeUInt16LE(0, 10);
        localHeader.writeUInt16LE(0, 12);
        localHeader.writeUInt32LE(crc, 14);
        localHeader.writeUInt32LE(compressed.length, 18);
        localHeader.writeUInt32LE(file.data.length, 22);
        localHeader.writeUInt16LE(nameBuf.length, 26);
        localHeader.writeUInt16LE(0, 28);

        localParts.push(localHeader, nameBuf, compressed);

        const centralHeader = Buffer.alloc(46);
        centralHeader.writeUInt32LE(0x02014b50, 0);
        centralHeader.writeUInt16LE(20, 4);
        centralHeader.writeUInt16LE(20, 6);
        centralHeader.writeUInt16LE(0x0800, 8);
        centralHeader.writeUInt16LE(8, 10);
        centralHeader.writeUInt16LE(0, 12);
        centralHeader.writeUInt16LE(0, 14);
        centralHeader.writeUInt32LE(crc, 16);
        centralHeader.writeUInt32LE(compressed.length, 20);
        centralHeader.writeUInt32LE(file.data.length, 24);
        centralHeader.writeUInt16LE(nameBuf.length, 28);
        centralHeader.writeUInt16LE(0, 30);
        centralHeader.writeUInt16LE(0, 32);
        centralHeader.writeUInt16LE(0, 34);
        centralHeader.writeUInt16LE(0, 36);
        centralHeader.writeUInt32LE(0, 38);
        centralHeader.writeUInt32LE(offset, 42);

        centralParts.push(centralHeader, nameBuf);
        offset += localHeader.length + nameBuf.length + compressed.length;
      }

      const centralDir = Buffer.concat(centralParts);
      const endRecord = Buffer.alloc(22);
      endRecord.writeUInt32LE(0x06054b50, 0);
      endRecord.writeUInt16LE(0, 4);
      endRecord.writeUInt16LE(0, 6);
      endRecord.writeUInt16LE(files.length, 8);
      endRecord.writeUInt16LE(files.length, 10);
      endRecord.writeUInt32LE(centralDir.length, 12);
      endRecord.writeUInt32LE(offset, 16);
      endRecord.writeUInt16LE(0, 20);

      const zipBuffer = Buffer.concat([...localParts, centralDir, endRecord]);
      res.setHeader("Content-Type", "application/zip");
      res.setHeader(
        "Content-Disposition",
        'attachment; filename="DbtLabAiCallAssistant-AndroidStudio.zip"'
      );
      res.setHeader("Content-Length", String(zipBuffer.length));
      res.send(zipBuffer);
    } catch (err) {
      console.error("Android project export error:", err);
      res.status(500).json({ error: "Failed to export Android Studio project ZIP." });
    }
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get("/{*path}", (_req: Request, res: Response) => {
        res.sendFile(path.join(distPath, "index.html"));
      });
    }
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`DBT LAB AI Call Assistant server running on http://0.0.0.0:${PORT}`);
  });
}

createServer();
